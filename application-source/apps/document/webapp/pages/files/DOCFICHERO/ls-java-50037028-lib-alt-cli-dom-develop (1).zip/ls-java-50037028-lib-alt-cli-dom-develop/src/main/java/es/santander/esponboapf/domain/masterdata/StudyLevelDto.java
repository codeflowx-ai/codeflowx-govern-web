package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class LevelStudy. Entidad donde se registra los niveles de estudio
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Study Level", 
example = "{\"studyLevelCode\":6,\"studyLevelName\":\"Superiores\"}")
public class StudyLevelDto implements Serializable{

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -7221639277783566715L;

    /**
     * The study level code.
     *
     * E.g.: 6
     */
    @Schema(description = "Identification study level", example = "6")
    private Integer studyLevelCode;

    /**
     * The label name.
     *
     * E.g.: 'Higher studies'
     */
    @Schema(maxLength = 50, description = "Description of the study level", example = "Superiores")
    private String studyLevelName;
}
