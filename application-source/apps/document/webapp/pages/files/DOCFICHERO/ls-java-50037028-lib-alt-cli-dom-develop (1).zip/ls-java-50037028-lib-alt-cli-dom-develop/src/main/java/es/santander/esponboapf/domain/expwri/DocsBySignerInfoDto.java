package es.santander.esponboapf.domain.expwri;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SignedDocsDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocsBySignerInfoDto {

    /** The codgdoc. */
    private String codgdoc;

    /** The person number doc. */
    private String personNumberDoc;

    /** The status. */
    private String status;

    /** The type doc. */
    private String typeDoc;

    /** The gn id. */
    private String gnId;

    /** The result. */
    private String signed;

    /** The add sign exp. */
    private Boolean addSignExp;

    /** The add sign exp read. */
    private Boolean addSignExpRead;

}
