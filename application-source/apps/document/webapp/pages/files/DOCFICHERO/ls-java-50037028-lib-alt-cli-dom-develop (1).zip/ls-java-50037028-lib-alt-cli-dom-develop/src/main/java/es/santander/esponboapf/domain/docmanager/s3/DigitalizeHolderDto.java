package es.santander.esponboapf.domain.docmanager.s3;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Digitalize holder dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalizeHolderDto {

    /**
     * The Holder code.
     */
    // HolderCode
    private Long holderCode;

    /**
     * The Person code.
     */
    // PersonCode
    private String personCode;

}
