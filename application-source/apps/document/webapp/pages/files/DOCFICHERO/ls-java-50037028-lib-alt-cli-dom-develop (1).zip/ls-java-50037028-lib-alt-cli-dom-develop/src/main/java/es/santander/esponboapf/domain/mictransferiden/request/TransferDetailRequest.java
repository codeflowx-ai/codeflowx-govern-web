package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TransferDetailRequest
 *
 * The type transfer detail request.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferDetailRequest {

    /** The Reference transfer. */
    private String referenceTransfer;

    /** The Application code. */
    private String applicationCode;

}
