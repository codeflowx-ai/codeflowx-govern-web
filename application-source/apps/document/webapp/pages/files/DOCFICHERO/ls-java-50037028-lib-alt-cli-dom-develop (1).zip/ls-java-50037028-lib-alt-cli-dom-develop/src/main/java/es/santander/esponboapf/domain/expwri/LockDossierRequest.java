package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class LockDossierRequest.
 *
 * Request dto with information to code dossier
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Request dto with information to code dossier", example = "{\"dossierCode\":9}")
public class LockDossierRequest {

    /**
     * The dossier code.
     *
     * Dossier code. Eg: 9
     */
    // Identificador interno del expediente necesario para el área de Back Office.
    // Un identificador único de Expediente tiene asociado un código de dossier en
    // Base de Datos.
    @Schema(description = "Dossier code", example = "9")
    @Min(1)
    @NotNull
    private Integer dossierCode;
}
