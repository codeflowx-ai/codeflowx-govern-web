package es.santander.esponboapf.domain.expread;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new dossier data header dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information to display in the header of the dossier.", 
example = "{\"dossierId\":\"1abe4f7c-d843-477d-b1c8-d181410c1a47\", "
        + "\"dossierIdExternal\":\"a451215b-946f-4ccf-a12f-5da8a2a48182\",\"signexpId\":1,"
        + "\"holders\": {\"holderId\":\"1abe4f7c-d843-477d-b1c8-d181410c1a47\","
        + "\"fullName\":\"Nombre Apellido1 Apellido2\","
        + "\"identityTypeCode\":1,\"identiyTypeName\":\"DNI\",\"identityNumber\":\"53000153B\","
        + "\"email\":\"manuel1r223@gmail.com\",\"movil\":\"34-686124154\",\"addressCompleted\":true,"
        + "\"identificationCompleted\":false}}")
// DossierDataDto
public class DossierDataDto {

    /**
     * The Dossier id.
     */
    // Dossier id
    @Schema(description = "UUID identifying a dossier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String dossierId;

    /** The dossier id external. */
    // Dossier id external
    @Schema(description = "UUID identifying a dossier", example = "a451215b-946f-4ccf-a12f-5da8a2a48182")
    private String dossierIdExternal;

    /** The sign exp id. */
    // Signexp id
    @Schema(description = "Signature dossier identifier", example = "1")
    private Long signexpId;

    /** The holders. */
    // Holders
    @Schema(description = "Signature dossier identifier", example = "1")
    private List<DataHolderDto> holders;

}
