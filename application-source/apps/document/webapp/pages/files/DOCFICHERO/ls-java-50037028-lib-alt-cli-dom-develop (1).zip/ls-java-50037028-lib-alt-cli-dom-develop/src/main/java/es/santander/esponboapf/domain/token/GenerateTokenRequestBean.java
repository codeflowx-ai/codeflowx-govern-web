package es.santander.esponboapf.domain.token;

import java.util.List;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

/**
 * The Class GenerateTokenRequestBean.
 */
@Getter
@Builder
@EqualsAndHashCode
public class GenerateTokenRequestBean {

    /** The keyalias. */
    private String keyalias;

    /** The payload. */
    private GenerateTokenRequestPayloadBean payload;

    /** The audience. */
    private List<String> audience;

    /** The expiration. */
    private String expiration;

}
