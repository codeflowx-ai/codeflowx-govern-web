package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;


/**
 * The Class TransferDto.
 */
@Data
@AllArgsConstructor

/**
 * Instantiates a new transfer dto.
 */
@NoArgsConstructor
@Builder
public class TransferDto {


    /** The dossier code. */
    @Schema(description = "Dossier code", example = "505")
    private Long dossierCode;

    /** The iban. */
    @Schema(description = "iban account indicator", example = "ES2600492594602515000446")
    private String iban;

    /** The person code. */
    @Schema(description = "person code indicator", example = "124661240")
    private String personCode;

    /** The name. */
    @Schema(description = "Person name", example = "Juan")
    private String name;

    /** The surname 1. */
    @Schema(description = "Person surname 1", example = "Alonso")
    private String surname1;

    /** The surname 2. */
    @Schema(description = "Person surname 2", example = "Martinez")
    private String surname2;

    /** The transfer code. */
    @Schema(description = "Transfer code", example = "505")
    private Long transferCode;

    @Schema(description = "Transfer state code", example = "E")
    private String transferStateCode;

    /** The payer name. */
    @Schema(description = "Payer name", example = "Jorge Sanz")
    private String payerName;

    /** The payer iban. */
    @Schema(description = "Payer iban", example = "ES1600495525542210029639")
    private String payerIban;

    /** The payer country. */
    @Schema(description = "Payer country", example = "ES")
    private String payerCountry;

    /** The origin country payment. */
    @Schema(description = "Origin country payment", example = "ES")
    private String originCountryPayment;

    /** The payment date. */
    @Schema(description = "Payment date", example = "2023-09-06")
    private LocalDate paymentDate;

    /** The transfer amount. */
    @Schema(description = "Transfer amount", example = "0.10")
    private BigDecimal transferAmount;

    /** The currency. */
    @Schema(description = "Transfer amount", example = "EUR")
    private String currency;

}
