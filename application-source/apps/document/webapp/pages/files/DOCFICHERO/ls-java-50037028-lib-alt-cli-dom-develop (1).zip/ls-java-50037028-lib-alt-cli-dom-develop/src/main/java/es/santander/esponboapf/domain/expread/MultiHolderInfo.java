package es.santander.esponboapf.domain.expread;

import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.validation.groups.HolderDetailsGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MultiHolderInfo.
 */

/**
 * Instantiates a new multi holder info.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MultiHolderInfo {

    /**
     * The Holder id.
     */
    // Holder id
    @Schema( description = "UUID identifying an holder",
            example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    @NotNull
    private String holderId;

    /**
     * The Holder code.
     */
    // Holder code
    @Schema( description = "Number identifying an holder", example = "341")
    @NotNull
    private Long holderCode;

    /**
     * The Priority.
     */
    // Priority
    @Schema( description = "Number identifying the priority", example = "1")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    private String priority;

    /**
     * The Email.
     */
    // Email
    @Schema( description = "Email", example = "manuel1r223@gmail.com")
    @NotNull()
    private String email;

    /** The holder type. */
    @Schema( description = "Number identifying the holder type", example = "3")
    @NotNull()
    private Integer holderType;

    /**
     * The Name.
     */
    // Name
    @Schema( description = "Name of the holder", example = "Jorge")
    @NotNull()
    private String name;

    /**
     * The Surname 1.
     */
    // Surname 1
    @Schema( description = "Surname1 of the holder", example = "Garcia")
    @NotNull()
    private String surname1;

    /**
     * The Surname 2.
     */
    // Surname 2
    @Schema( description = "Surname2 of the holder", example = "Ramirez")
    @NotNull()
    private String surname2;

    /** The contract CMC. */
    @Schema( description = "The CMC contract identifier", example = "004932987452369236")
    @NotNull()
    private String contractCMC;

    /** The state code CMC. */
    @Schema( description = "The CMC state code", example = "C")
    @NotNull
    private String stateCodeCMC;

    /** The person type. */
    @Schema(description = "The person type BDP", example = "F")
    private String personType;

    /** The person code. */
    @Schema(description = "The person code BPD", example = "12345678")
    private String personCode;

    /** The risk fioc. */
    @Schema(description = "Risk fios", example = "A2")
    private String riskFioc;

}
