package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new profile dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "User profile to access from application",
example = "{\"profileCode\":1,\"profileName\":\"Administrador\",\"userId\":\"N1224\","
        + "\"centerCode\",\"3215\",\"officeType\":\"2,SR,26\"}")
// Profile data object
public class ProfileDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 9147482859329438869L;

    /** The profile code. */
    @Schema(description = "Unique identifier of the profile", example = "1")
    private int profileCode;

    /** The profile name. */
    @Schema(description = "Descriptive name of the profile", example = "Administrador")
    private String profileName;

    /** The user id. */
    @Schema(description = "Users with administrator profile", example = "N1224,N3456")
    private String userId;

    /** The center code. */
    @Schema(description = "Center codes for bboo and contact center profiles", example = "3215,3658")
    private String centerCode;

    /** The office type. */
    @Schema(description = "Office identifiers for offices profile", example = "2,SR,26")
    private String officeType;

}
