package es.santander.esponboapf.domain.clientreg;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activation debit card request.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Input object activation debit card request")
public class ActivationDebitCardRequest {

    /** The productTypeCard. */
    // Product type card
    @NotNull
    @XssValid
    @Schema(description = "product type card indicator", example = "506")
    private String productTypeCard;

    /** The subTypeCard. */
    // Subtype card
    @NotNull
    @XssValid
    @Schema(description = "sub type card indicator", example = "634")
    private String subTypeCard;

    /** The referenceProduct. */
    // Reference product
    @NotNull
    @XssValid
    @Schema(description = "reference product indicator", example = "001")
    private String referenceProduct;

    /** The employeeNumber. */
    // Employee number
    @NotNull
    @XssValid
    @Schema(description = "employee number indicator", example = "31156")
    private String employeeNumber;

    /** The markCard. */
    // Mark card
    @NotNull
    @XssValid
    @Schema(description = "mark card indicator", example = "01")
    private String markCard;

    /** The typeCard. */
    // Type card
    @NotNull
    @XssValid
    @Schema(description = "type card indicator", example = "66")
    private String typeCard;

    /** The stampCodeCard. */
    // Stamp code card
    @NotNull
    @XssValid
    @Schema(description = "stamp code card indicator", example = "796")
    private String stampCodeCard;

    /** The accountBranch. */
    // Account branch
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "account branch indicator", example = "2548")
    private String accountBranch;

    /** The partenonProduct. */
    // Partenon product
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "partenon product indicator", example = "300")
    private String partenonProduct;

    /** The partenonAccount. */
    // Partenon account
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "partenon account indicator", example = "0500667")
    private String partenonAccount;

    /** The oldFormatProduct. */
    // Old format product
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "old format product indicator", example = "211")
    private String oldFormatProduct;

    /** The oldFormatAccount. */
    // Old format account
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "old format account indicator", example = "0000287")
    private String oldFormatAccount;

    /** The holders. */
    @Valid
    @NotEmpty
    @Schema(description = "Holders' information list", example = "[]")
    private List<ActivationDebitCardHolderRequest> holders;

    /** The dossier code. */
    @Schema(description = "Dossier code", example = "505")
    private Long dossierCode;

    /**
     * Gets the main holder.
     *
     * @return the main holder
     */
    public Optional<ActivationDebitCardHolderRequest> getMainHolder() {
        return Optional.ofNullable(this.holders).orElse(new ArrayList<>()).stream()
                .filter(adchr -> "1".equals(adchr.getPriority())).findFirst();
    }

    /**
     * Gets the secondary holders.
     *
     * @return the secondary holders
     */
    public List<ActivationDebitCardHolderRequest> getSecondaryHolders() {
        return Optional.ofNullable(this.holders).orElse(new ArrayList<>()).stream()
                .filter(adchr -> !"1".equals(adchr.getPriority()))
                .sorted(Comparator.comparing(ActivationDebitCardHolderRequest::getPriority))
                .collect(Collectors.toList());
    }

}
