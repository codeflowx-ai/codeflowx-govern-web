package es.santander.esponboapf.domain.expread.search;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier state filter dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// State filter
public class DossierFilterStateDto {

    /**
     * The State code.
     */
    // State code
    @Schema(description = "State code", example = "2")
    private Integer stateCode;

    /**
     * The Sub states.
     */
    // Applied substates
    @Schema(description = "List of substates to find, empty for all", example = "{1,2,3,4}")
    private List<Integer> subStates;

}
