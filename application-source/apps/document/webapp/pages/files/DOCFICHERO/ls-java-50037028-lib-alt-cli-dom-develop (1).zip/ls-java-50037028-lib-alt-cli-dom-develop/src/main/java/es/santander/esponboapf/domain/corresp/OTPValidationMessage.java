package es.santander.esponboapf.domain.corresp;

import javax.validation.constraints.Min;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class OTPValidationMessage.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information about a failed OTP key validation.",
        example = "{\"code\":\"LN001\",\"description\":\"No otp for this holder or has expired.\"}")
// OTP validation message
public class OTPValidationMessage {

    /** The code. */
    @Schema(description = "Error code", allowableValues = { "LN001", "LN002", "LN003", "LN004" },
            example = "LN001")
    private String code;

    /** The description. */
    @Schema(description = "Error description", allowableValues = { "No otp for this holder or has expired.",
            "Wrong code, you have exceeded the number or retries.", "Wrong code, only (number) retries remain" },
            example = "No otp for this holder or has expired.")
    private String description;

    // the retries after the validation OTP key
    // the maximum is 3.
    /** The retries. */
    @Schema(description = "Number of retries left after this error", example = "1")
    @Min(0)
    private byte retries;
}
