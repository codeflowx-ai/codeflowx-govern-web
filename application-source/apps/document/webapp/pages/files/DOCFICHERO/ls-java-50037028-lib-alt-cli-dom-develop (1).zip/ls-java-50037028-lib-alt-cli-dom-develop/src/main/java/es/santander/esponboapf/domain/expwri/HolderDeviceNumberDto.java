package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderDeviceNumberDto.
 */
//The class HolderDeviceNumberDto
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class HolderDeviceNumberDto {

    /** The holder id. */
    // The holder id
    private UUID holderId;

    /** The num dispositivo. */
    // The num dispositivo
    @NotNull
    private String numDispositivo;

}
