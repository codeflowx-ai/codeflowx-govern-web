package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer history occurs response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferHistoryOccursResponse {

    /** The Single reference operation. */
    private String singleReferenceOperation;

    /** The Payment date. */
    private String paymentDate;

    /** The Amount. */
    private Double amount;

    /** The Currency. */
    private String currency;

    /** The Payer data. */
    private TransferHistoryPayerDataResponse payerData;

    /** The Payment concept. */
    private String paymentConcept;

    /** The Transfer type. */
    private String transferType;

    /** The Application code. */
    private String applicationCode;

}
