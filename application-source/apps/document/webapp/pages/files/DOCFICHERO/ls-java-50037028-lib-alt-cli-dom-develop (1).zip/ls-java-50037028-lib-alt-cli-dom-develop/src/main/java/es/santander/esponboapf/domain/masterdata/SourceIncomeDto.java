package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SourceIncomeDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "source of income for the completion of tax information", 
example = "{\"sourceIncomeCode\":1,\"sourceIncomeName\":\"Salario de Trabajo\",\"isOther\":true}")
public class SourceIncomeDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -3953115702562167204L;

    /**
     * The source income code.
     *
     * E.g.: 1
     */
    @Schema(description = "number identifying a source of income", example = "1")
    private Integer sourceIncomeCode;

    /**
     * The source income name.
     *
     * E.g.: 'Work Salary'
     */
    @Schema(maxLength = 50, description = "source of income description", example = "Salario de Trabajo")
    private String sourceIncomeName;

    /**
     * The is other.
     *
     * E.g.: true
     */
    @Schema(description = "It will be true if 'other description' is required for the screen", example = "true")
    private Boolean isOther;

}
