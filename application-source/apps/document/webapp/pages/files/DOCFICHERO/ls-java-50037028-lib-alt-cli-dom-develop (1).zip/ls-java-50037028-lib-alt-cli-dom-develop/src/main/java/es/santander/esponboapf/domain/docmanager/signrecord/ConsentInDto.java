package es.santander.esponboapf.domain.docmanager.signrecord;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new consent in dto.
 */
// Constructors
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Natural person performing the digital onboarding", 
    example = "{\"consentIndicator\":true}")
// Consent in
public class ConsentInDto extends ConsentDto {

    /** The consent indicator. */
    // Consent indicator
    @Schema( description = "Flag to indicate the consent has been accepted", example = "true")
    private Boolean consentIndicator;

}
