package es.santander.esponboapf.domain.corresp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * The type Send email response.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Send communication response object
public class SendCommunicationResponse {

    /**
     * The Uuid.
     */
    private UUID uuid;

    /**
     * The Channel.
     */
    private String channel;

    /**
     * The Message.
     */
    private String message;

    /**
     * The Action code.
     */
    private Integer actionCode;

}
