package es.santander.esponboapf.domain.fraud;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Consult request response dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsultRequestResponseDto {

    /**
     * The Fecha mensaje.
     */
    private String fechaMensaje;

    /**
     * The Hora mensaje.
     */
    private String horaMensaje;

    /**
     * The Tipo solicitud.
     */
    private String tipoSolicitud;

    /**
     * The Estado.
     */
    private String estado;

    /**
     * The Des corta estado.
     */
    private String desCortaEstado;

    /**
     * The Descrip estado.
     */
    private String descripEstado;

    /**
     * The Id tipo cta.
     */
    private String idTipoCta;

    /**
     * The Den titu cta.
     */
    private String denTituCta;

    /**
     * The Iban part sol.
     */
    private String ibanPartSol;

    /**
     * The Bic part dir sol conf.
     */
    private String bicPartDirSolConf;

    /**
     * The Bic dest sol.
     */
    private String bicDestSol;

    /**
     * The Fecha respuesta.
     */
    private String fechaRespuesta;

    /**
     * The Cod respuesta.
     */
    private String codRespuesta;

    /**
     * The Motivo rechazo.
     */
    private String motivoRechazo;

    /**
     * The Des corta rechazo.
     */
    private String desCortaRechazo;

    /**
     * The Descrip rechazo.
     */
    private String descripRechazo;

    /**
     * The Retor ws.
     */
    private String retorWS;

    /**
     * The Des corta retor ws.
     */
    private String desCortaRetorWS;

    /**
     * The Descrip retor ws.
     */
    private String descripRetorWS;

    /**
     * The Ret rsn.
     */
    private String retRsn;

    /**
     * The Des corta ret rsn.
     */
    private String desCortaRetRsn;

    /**
     * The Descrip lar ret rsn.
     */
    private String descripLarRetRsn;

    /**
     * The Result info.
     */
    private ConsultRequestResultInfoDto resultInfo;

}
