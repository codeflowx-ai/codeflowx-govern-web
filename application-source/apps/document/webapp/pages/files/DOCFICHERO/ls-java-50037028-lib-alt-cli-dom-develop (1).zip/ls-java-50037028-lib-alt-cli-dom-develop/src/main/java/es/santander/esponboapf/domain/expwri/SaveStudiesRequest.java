package es.santander.esponboapf.domain.expwri;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class SaveStudiesRequest.
 *
 * Request class to save the holder's study level.
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Required information to save the level of studies of a holder",
example = "{\"holderStudies\":{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"studyLevelCode\":1,\"finishedStudies\":true,\"universityCode\":1058}}")
// Save studies request
public class SaveStudiesRequest extends DossierParentDto {

    /**
     * The holder studies.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     */
    @Schema(description = "Information about the level of education of a holder.",
            example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
                    + "\"studyLevelCode\":1,\"finishedStudies\":true,\"universityCode\":1058}")
    @Valid
    @NotNull
    private SaveStudiesHolderDto holderStudies;

}
