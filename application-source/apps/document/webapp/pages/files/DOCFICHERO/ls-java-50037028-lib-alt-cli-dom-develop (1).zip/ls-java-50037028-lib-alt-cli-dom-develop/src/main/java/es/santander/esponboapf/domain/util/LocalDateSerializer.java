package es.santander.esponboapf.domain.util;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * The Class LocalDateSerializer.
 */
public class LocalDateSerializer extends JsonSerializer<LocalDate> {

    /**
     * Serialize.
     *
     * @param arg0 the arg 0
     * @param arg1 the arg 1
     * @param arg2 the arg 2
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Override
    public void serialize(LocalDate arg0, JsonGenerator arg1, SerializerProvider arg2) throws IOException {
        arg1.writeString(arg0.format(DateTimeFormatter.ofPattern(HagcliUtils.DATE_FORMAT)));
    }
}
