package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new province dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information about provinces in Spain", 
example = "{\"provinceCode\":\"28\",\"provinceName\":\"MADRID\"}")
public class ProvinceDto {

    /**
     * The province code.
     *
     * E.g.: '28'
     */
    @Schema(maxLength = 2, description = "Province code", example = "28")
    private String provinceCode;

    /**
     * The province name.
     *
     * E.g.:'MADRID'
     */
    @Schema(maxLength = 50, description = "Province name", example = "MADRID")
    private String provinceName;
}
