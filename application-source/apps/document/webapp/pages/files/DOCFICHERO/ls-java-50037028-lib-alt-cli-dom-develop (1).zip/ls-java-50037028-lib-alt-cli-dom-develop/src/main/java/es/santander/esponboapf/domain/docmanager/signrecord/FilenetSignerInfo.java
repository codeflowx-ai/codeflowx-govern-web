package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FilenetSignerInfo.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class FilenetSignerInfo {

    /** The person number. */
    private String personNumber;

    /** The interv type. */
    private String intervType;

    /** The identity document. */
    private String identityDocument;

    /** The full name. */
    private String fullName;
}
