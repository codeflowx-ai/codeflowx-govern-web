package es.santander.esponboapf.domain.expwri;

import java.util.Objects;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Universal dossier holder.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Basic structure to be used by onboarding and backoffice services",
        example = "{\"dossierId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"dossierCode\":1}")
@SuperBuilder
public class UniversalDossierHolder {

    /**
     * The dossier id.
     * <p>
     * Unique dossier identifier. Used by onboarding services. Null otherwise.
     * E.g.: '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(description = "Unique dossier identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID dossierId;

    /**
     * The dossier code.
     * <p>
     * Internal dossier code. Used by backoffice services. Null otherwise.
     * E.g.: 1
     */
    @Schema(description = "Internal dossier code. Used by backoffice services. Null otherwise.",
            example = "1")
    private Long dossierCode;

    /**
     * The holder id.
     * <p>
     * Unique holder identifier. Used by onboarding services. Null otherwise.
     * E.g.: '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(description = "Unique holder identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /**
     * The holder code.
     * <p>
     * Internal holder code. Used by backoffice services. Null otherwise.
     * E.g.: 1
     */
    @Schema(description = "Internal holder code. Used by backoffice services. Null otherwise.",
            example = "1")
    private Long holderCode;

    /**
     * Is filled boolean.
     *
     * @return the boolean
     */
    public boolean isFilled() {
        // If everything empty, it's not filled.
        return !(Objects.isNull(dossierCode)
                && Objects.isNull(dossierId)
                && Objects.isNull(holderCode)
                && Objects.isNull(holderId));
    }

}
