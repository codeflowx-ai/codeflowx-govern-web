package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * The type Branch locator office multi.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchLocatorOfficeMulti {

    /** The Multi. */
    private Map<String, String> multi;

    /** The Code. */
    private String code;

    /**
     * Gets default.
     *
     * @return the default
     */
    public String getDefault() {
        return multi.get("default");
    }

}
