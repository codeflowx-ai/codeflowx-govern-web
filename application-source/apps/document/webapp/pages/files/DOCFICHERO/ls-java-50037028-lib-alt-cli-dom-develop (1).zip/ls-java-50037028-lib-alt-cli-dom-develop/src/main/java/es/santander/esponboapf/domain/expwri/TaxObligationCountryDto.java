package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new tax obligation country dto.
 */

@NoArgsConstructor
@Data
@Schema(description = "Tax obligations of the holder outside Spain.",
example = "{\"countryCode\":\"FR\",\"taxReasonCode\":\"R\","
        + "\"tin\":\"1234 1234 1234 12345674820\"}")
public class TaxObligationCountryDto {

    /**
     * The country code.
     *
     * The tax country code. E.g.: 'ES'
     */
    @Schema(maxLength = 2, description = "Code for the representation of names of countries", example = "FR")
    @Size(max = 2)
    private String countryCode;

    /**
     * The tax reason code.
     *
     * The tax reason code. 'R' - 'Residence', 'C' - 'Citizenship','A' - 'Both'
     */
    @Schema(maxLength = 1, description = "Code for the tax reason", example = "R")
    @Size(max = 1)
    private String taxReasonCode;

    /**
     * The tin.
     *
     * The tin number. E.g.: 1234 1234 1234 12345674820
     */
    @Schema(maxLength = 40, description = "Represents the nominal interest", example = "1234 1234 1234 12345674820")
    @XssValid
    @Size(max = 40)
    private String tin;
}
