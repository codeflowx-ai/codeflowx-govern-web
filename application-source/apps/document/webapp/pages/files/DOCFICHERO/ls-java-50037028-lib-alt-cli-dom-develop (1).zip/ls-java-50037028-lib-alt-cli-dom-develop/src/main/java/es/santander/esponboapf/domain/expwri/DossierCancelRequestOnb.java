package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class DossierCancelRequestOnb.
 */
//Constructors
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Required information to cancel the dossier on the Onboarding Orq.",
        example = "{\"codeValidation\":\"CSV001\"}")
@SuperBuilder
//Dossier Cancel request Onb object
public class DossierCancelRequestOnb extends UniversalDossier {

    /** The code validation. */
    @Schema( description = "Code validation identifier.", example = "CSV001")
    @Pattern(regexp = "[A-Z0-9]{6}")
    // The code validation
    private String codeValidation;

}
