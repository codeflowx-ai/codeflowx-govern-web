package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class LanguageDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Lenguage information.",
example  = "{\"languageCode\":\"ES\",\"languageName\":\"Español\",\"order\":1}")
public class LanguageDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -1031193609771606636L;

    /** The language code. */
    @Schema(description = "Language code.", example = "ES")
    private String languageCode;


    /** The language name. */
    @Schema(description = "Language name", example = "Español")
    private String languageName;

    /** The order. */
    @Schema(description = "Order", example = "1")
    private Integer order;
}
