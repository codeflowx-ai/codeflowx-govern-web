package es.santander.esponboapf.domain.fraud;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MulerosStatusResponse.
 *
 * MulerosStatusResponse.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MulerosStatusResponse {

    /** The info. */
    private String info;

}
