package es.santander.esponboapf.domain.docmanager.pdf;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * PdfRequest class
 *
 */
//The class PdfRequest
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PdfRequest {

    /** templateCode */
    private String templateCode;

    /** data */
    private Map<String, FieldData> data;
}
