package es.santander.esponboapf.domain.gesdoc;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class ReadDocParamRequest.
 */
//The class ReadDocParamRequest
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ReadDocParamRequest {

    /** The below signer. */
    private int belowSigner;

    /** The position. */
    private String position;

    /** The priority holder. */
    private String priorityHolder;

}
