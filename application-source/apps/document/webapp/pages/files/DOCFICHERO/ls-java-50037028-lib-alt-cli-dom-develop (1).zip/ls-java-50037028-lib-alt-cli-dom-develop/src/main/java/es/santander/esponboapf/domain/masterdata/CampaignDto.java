package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.LocalDateTimeDeserializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new campaign dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder(toBuilder = true)
@Schema(description = "Campaign chosen in the onboarding process")
public class CampaignDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -3672647246991027353L;

    /**
     * The campaign code.
     * <p>
     * E.g.: 221, ...
     */
    @Schema( description = "Number identifying an campaign", example = "221")
    @Size(max = 10)
    @NotNull
    private Integer campaignCode;

    /**
     * The activity name.
     * <p>
     * E.g.: 'Cuenta Online Santander'
     */
    @Schema( maxLength = 75, description = "Description of the campaign",
            example = "Cuenta Online Santander")
    @NotNull
    private String campaignName;

    /**
     * The start date.
     * <p>
     * E.g.: '30/07/2021'
     */
    @Schema( description = "Start date of the campaign (dd/MM/yyyy)", example = "30/07/2021")
    @NotNull
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy", shape = JsonFormat.Shape.STRING)
    private LocalDateTime startDate;

    /**
     * The finish date.
     * <p>
     * E.g.: '31/12/2099'
     */
    @Schema( description = "End date of the campaign (dd/MM/yyyy)", example = "31/12/2099")
    @NotNull
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy", shape = JsonFormat.Shape.STRING)
    private LocalDateTime finishDate;

    /**
     * The Type office.
     */
    @Schema(description = "Office type of the campaign", example = "VIRTUAL")
    private String typeOffice;

    /**
     * The Office code.
     */
    @Schema(description = "Code of the office, should be filled only in VIRTUAL type", example = "5525")
    private String officeCode;

    /** The assisted. */
    @Schema(description = "Boolean that indicates if the campaing is assisted or not", example = "false")
    private Boolean assisted;

    /** The hasMultiHolderAllowed. */
    @Schema(description = "Boolean that indicates if the campaing can be multiholder or not", example = "false")
    private Boolean hasMultiHolderAllowed;

    /** The bbooRegistration. */
    @Schema(description = "Boolean that indicates if the campaing is being registered by a back office",
            example = "false")
    private Boolean isBBOORegistration;

    /** The external app. */
    @Schema(description = "Boolean that indicates if the campaing has external processes",
            example = "false")
    private Boolean externalApp;

    /** The url cmb. */
    @Schema(description = "Call me back URL, can be null",
            example = "http://www.callmeback.com/example")
    private String urlCmb;

    /**
     * The Accounts.
     */
    @Schema(description = "List of accounts for this campaign with the current filter")
    private List<CampaignAccountDto> accounts;

    /**
     * The Metric.
     */
    @Schema(description = "Metric data of this campaign/account")
    private CampaignMetricDto metric;

}
