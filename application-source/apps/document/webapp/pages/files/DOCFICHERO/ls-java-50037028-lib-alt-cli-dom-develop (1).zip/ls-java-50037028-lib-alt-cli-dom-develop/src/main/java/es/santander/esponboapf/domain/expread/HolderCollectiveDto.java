package es.santander.esponboapf.domain.expread;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderCollective.
 */
//The class HolderCollectiveDto
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class HolderCollectiveDto {

    /** The collective code. */
    //collectiveCode
    @NotBlank
    @Pattern(regexp = "^[0-9]{0,4}$")
    private String collectiveCode;

    /** The subtype. */
    @NotBlank
    @Pattern(regexp = "^[0-9]{0,4}$")
    private String subtype;
}
