package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StateDocumentDto.
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "States of a document", 
example = "{\"stateDocumentCode\":\"RNE\","
        + "\"stateDocumentName\":\"Requerido no entregado\"}")
// State document dto
public class StateDocumentDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -7404120017236719441L;

    /**
     * The state document code.
     *
     * E.g.: 'RNE'
     */
    // State document code
    @Schema(maxLength = 5, description = "State document code",
            example = "RNE")
    private String stateDocumentCode;

    /**
     * The state document name.
     *
     * E.g.: 'Requerido No Entregado'
     */
    // State document name
    @Schema(maxLength = 2, description = "State document name",
            example = "Requerido no entregado")
    private String stateDocumentName;

}
