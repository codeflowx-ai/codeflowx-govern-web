package es.santander.esponboapf.domain.common;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ResponseResultBody.
 *
 * @param <T> the generic type
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Response from a service.", example = "{\"result\":true,\"info\":{}}")
public class ResponseResultBody<T> {

    /** The user. */
    // The user
    @Schema(description = "Result status. True or false.", example = "false")
    private boolean result;

    /** The body. */
    @Schema(description = "Additional information to the result", example = "{}")
    private T info;

}
