package es.santander.esponboapf.domain.expread.transfer;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * The type Holder iberpay dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HolderIberpayDto {

    /**
     * The Holder code.
     */
    @Schema(description = "Holder code", example = "1")
    private Long holderCode;

    /**
     * The Beneficiary iban.
     */
    @Schema(description = "Beneficiary iban", example = "ES2114650100722030876293")
    private String beneficiaryIban;

    /**
     * The Beneficiary bban.
     */
    @Schema(description = "Beneficiary iban", example = "14650100722030876293")
    private String beneficiaryBban;

    /**
     * The Owner date.
     */
    @Schema(description = "Owner date", example = "2019-01-21T05:47:08.644")
    private LocalDateTime ownerDate;

    /**
     * The Owner state code.
     */
    @Schema(description = "Holder code", example = "1")
    private String ownerStateCode;

    /**
     * The Owner state desc.
     */
    @Schema(description = "Holder code", example = "AC")
    private String ownerStateDesc;

    /**
     * The Referer.
     */
    @Schema(description = "Holder code", example = "1123123AAASDF")
    private String referer;

}
