package es.santander.esponboapf.domain.expread;

import java.util.List;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierMultiHolderInfo.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Response with multi holder info from dossier")
public class DossierMultiHolderInfo {

    /** The dossier code. */
    // Dossier code
    @NotNull
    @Schema(
            description = "Uuid of the dossier, it will be identified with the dossier in the services.",
            example = "505")
    private Long dossierCode;

    /** The is multi holder. */
    // Is multi holder
    @Schema( description = "Indicate if the dossier is multiholder.", example = "true")
    private Boolean isMultiHolder;

    /** The account name. */
    // nombre descriptivo del tipo de cuenta
    @Schema( description = "The name of account type.", example = "Cuenta Online Santander")
    private String accountName;

    /** The multi holder info. */
    private List<MultiHolderInfo> multiHolderInfo;

    /** The is BBOO registration. */
    @Schema(description = "Indicates whether the dossier has been created by BBOO.", example = "true")
    private Boolean isBBOORegistration;

    /** The dossier state code. */
    @Schema(description = "Dossier state code.", example = "1")
    private Integer dossierStateCode;

    /** The campaign code. */
    @Schema(description = "Dossier campaign code.", example = "219")
    private Integer campaignCode;

}
