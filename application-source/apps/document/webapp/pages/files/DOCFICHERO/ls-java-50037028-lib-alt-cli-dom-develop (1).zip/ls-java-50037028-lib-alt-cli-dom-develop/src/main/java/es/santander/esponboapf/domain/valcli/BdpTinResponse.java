package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpTinResponse.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BdpTinResponse {

    /** The code. */
    private String code;

    /** The description. */
    private String description;

}
