package es.santander.esponboapf.domain.mictransferiden.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.StringTrimmerDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TransferDetailPayerAccountResponse
 *
 * The type Transfer detail payer account response.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferDetailPayerAccountResponse {

    /** The Payer iban. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String payerIban;

    /** The Origin country payment. */
    private String originCountryPayment;

}
