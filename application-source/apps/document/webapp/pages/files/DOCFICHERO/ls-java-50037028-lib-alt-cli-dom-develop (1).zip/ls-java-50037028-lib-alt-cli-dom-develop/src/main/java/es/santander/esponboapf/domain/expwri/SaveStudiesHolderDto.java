/*
 *
 */
package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SaveStudiesHolderDto.
 *
 * Information related to a holder who is on the process of the digital
 * onboarding.
 */
@NoArgsConstructor
@Data
@Schema(description = "Information about the level of education of a holder.", 
        example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
                + "\"studyLevelCode\":1,\"finishedStudies\":true,\"universityCode\":1058}")
public class SaveStudiesHolderDto {

    /**
     * The holder id.
     *
     * The holder's identifier.
     */
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /**
     * The study level code.
     *
     * The holder's study level code: 1 – Master/PhD, 2 - Secondary, 3 - Primary,
     * 4 - Uneducated, 6 - Higher studies
     */
    @Schema( description = "Study level code",
            allowableValues = { "1 – Master/PhD", "2 - Secondary", "3 - Primary", "4 - Uneducated",
                    "6 - Higher studies" },
            example = "1")
    @Min(1)
    private int studyLevelCode;

    /**
     * The finished studies.
     *
     * If the holder has finished his studies.
     */
    @Schema(
            description = "Flag to indicate wether the holder has already completed his studies or not .",
            example = "true")
    private boolean finishedStudies;

    /**
     * The university code.
     *
     * In case the holder chose 'studyLevelCode' '1' or '6', this might not be
     * empty.
     */
    @Schema( description = "Code correspondening to a university.",
            example = "1058")
    private Integer universityCode;
}
