package es.santander.esponboapf.domain.expread;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Multiholder ids.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
// MultiholderIds
public class MultiholderIds {

    /**
     * The Holders.
     */
    // Holders
    private List<String> holders;

}
