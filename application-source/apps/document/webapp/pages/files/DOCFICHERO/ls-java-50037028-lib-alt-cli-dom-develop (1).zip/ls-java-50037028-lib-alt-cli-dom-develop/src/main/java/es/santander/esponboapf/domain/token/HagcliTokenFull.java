package es.santander.esponboapf.domain.token;

import java.util.Optional;
import java.util.UUID;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import lombok.EqualsAndHashCode;

/**
 * The Class HagcliTokenFull.
 * Builder.
 * All type constructor.
 */
@JsonDeserialize(builder = HagcliTokenFull.HagcliTokenFullBuilder.class)
@EqualsAndHashCode(callSuper = true)
//The class HagcliTokenFull
public final class HagcliTokenFull extends TokenBasic {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 2089634405236103775L;

    /** The hd ident. */
    private HagcliTokenIdAndExternal hdIdent;


    /**
     * Instantiates a new hagcli token full.
     *
     * @param builder the builder
     */
    private HagcliTokenFull(HagcliTokenFullBuilder builder) {
        this.hdIdent = HagcliTokenIdAndExternal.builder().dossierId(builder.dossierId).holderId(builder.holderId)
                .externalDossierId(builder.externalDossierId).campaignCode(builder.campaignCode).build();
        super.setExpiration(builder.expiration);
    }

    /**
     * Gets the dossier id.
     *
     * @return the dossier id
     */
    public UUID getDossierId() {
        return Optional.ofNullable(hdIdent).map(HagcliTokenIdAndExternal::getDossierId).orElse(null);
    }

    /**
     * Gets the holder id.
     *
     * @return the holder id
     */
    public UUID getHolderId() {
        return Optional.ofNullable(hdIdent).map(HagcliTokenIdAndExternal::getHolderId).orElse(null);
    }

    /**
     * Gets the external dossier id.
     *
     * @return the external dossier id
     */
    public UUID getExternalDossierId() {
        return Optional.ofNullable(hdIdent).map(HagcliTokenIdAndExternal::getExternalDossierId).orElse(null);
    }

    /**
     * Gets the campaign code.
     *
     * @return the campaign code
     */
    public Integer getCampaignCode() {
        return Optional.ofNullable(hdIdent).map(HagcliTokenIdAndExternal::getCampaignCode).orElse(null);
    }

    /**
     * Builder.
     *
     * @return the hagcli token full builder
     */
    public static HagcliTokenFullBuilder builder() {
        return new HagcliTokenFullBuilder();
    }

    /**
     * Builder from.
     *
     * @param hagcliTokenFull the hagcli token full
     * @return the hagcli token full builder
     */
    public static HagcliTokenFullBuilder builderFrom(HagcliTokenFull hagcliTokenFull) {
        return new HagcliTokenFullBuilder(hagcliTokenFull);
    }

    /**
     * The Class HagcliTokenFullBuilder.
     */
    @JsonPOJOBuilder(withPrefix = "")
    public static final class HagcliTokenFullBuilder extends TokenBasicBuilder {

        /** The dossier id. */
        private UUID dossierId;

        /** The holder id. */
        private UUID holderId;

        /** The external dossier id. */
        private UUID externalDossierId;

        /** The campaign code. */
        private Integer campaignCode;

        /** The expiration. */
        private Long expiration;

        /**
         * Instantiates a new hagcli token full builder.
         */
        private HagcliTokenFullBuilder() {
        }

        /**
         * Instantiates a new hagcli token full builder.
         *
         * @param hagcliTokenFull the hagcli token full
         */
        private HagcliTokenFullBuilder(HagcliTokenFull hagcliTokenFull) {
            this.dossierId = Optional.ofNullable(hagcliTokenFull.hdIdent).map(HagcliTokenIdAndExternal::getDossierId)
                    .orElse(null);
            this.holderId = Optional.ofNullable(hagcliTokenFull.hdIdent).map(HagcliTokenIdAndExternal::getHolderId)
                    .orElse(null);
            this.externalDossierId = Optional.ofNullable(hagcliTokenFull.hdIdent)
                    .map(HagcliTokenIdAndExternal::getExternalDossierId).orElse(null);
            this.campaignCode = Optional.ofNullable(hagcliTokenFull.hdIdent)
                    .map(HagcliTokenIdAndExternal::getCampaignCode).orElse(null);
            this.expiration = hagcliTokenFull.getExpiration();
        }

        /**
         * Dossier id.
         *
         * @param dossierId the dossier id
         * @return the hagcli token full builder
         */
        public HagcliTokenFullBuilder dossierId(UUID dossierId) {
            this.dossierId = dossierId;
            return this;
        }

        /**
         * Holder id.
         *
         * @param holderId the holder id
         * @return the hagcli token full builder
         */
        public HagcliTokenFullBuilder holderId(UUID holderId) {
            this.holderId = holderId;
            return this;
        }

        /**
         * External dossier id.
         *
         * @param externalDossierId the external dossier id
         * @return the hagcli token full builder
         */
        public HagcliTokenFullBuilder externalDossierId(UUID externalDossierId) {
            this.externalDossierId = externalDossierId;
            return this;
        }

        /**
         * Campaign code.
         *
         * @param campaignCode the campaign code
         * @return the hagcli token full builder
         */
        public HagcliTokenFullBuilder campaignCode(Integer campaignCode) {
            this.campaignCode = campaignCode;
            return this;
        }

        /**
         * Expiration.
         *
         * @param expiration the expiration
         * @return the hagcli token full builder
         */
        @Override
        public HagcliTokenFullBuilder expiration(Long expiration) {
            this.expiration = expiration;
            return this;
        }

        /**
         * Builds the.
         *
         * @return the hagcli token full
         */
        @Override
        public HagcliTokenFull build() {
            return new HagcliTokenFull(this);
        }

        /**
         * Self.
         *
         * @return the token basic builder
         */
        @Override
        protected TokenBasicBuilder self() {
            return this;
        }

    }

}
