package es.santander.esponboapf.domain.expread;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.LocalDateTimeDeserializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder basic data dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Basic holder data.")
public class HolderBasicDataDto {

    /**
     * The Dossier code.
     */
    // Dossier code
    @Schema(description = "Number identifying a dossier", example = "629")
    private Long dossierCode;

    /**
     * The Dossier id.
     */
    // Dossier id
    @Schema(description = "UUID identifying a dossier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String dossierId;

    /**
     * The Holder code.
     */
    // Holder code
    @Schema(description = "Number identifying an holder", example = "341")
    private Long holderCode;

    /**
     * The Holder id.
     */
    // Holder id
    @Schema(description = "UUID identifying an holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /**
     * The Priority.
     */
    // Priority
    @Schema(description = "Number identifying the priority", example = "1")
    private String priority;

    /**
     * The Name.
     */
    // Name
    @Schema(description = "Name of the holder", example = "Jorge")
    private String name;

    /**
     * The Surname 1.
     */
    // Surname1
    @Schema(description = "Surname1 of the holder", example = "Garcia")
    private String surname1;

    /**
     * The Surname 2.
     */
    // Surname2
    @Schema(description = "Surname2 of the holder", example = "Ramirez")
    private String surname2;

    /**
     * The Identity type code.
     */
    // IdentityTypeCode
    @Schema(description = "Number identifying type of code", example = "1")
    private Integer identityTypeCode;

    /**
     * The Number identity.
     */
    // IdentityNumber
    @Schema(description = "Document identity number", example = "38268686K")
    private String identityNumber;

    /**
     * The prefix.
     */
    // Prefix
    @Schema(description = "Phone prefix number", example = "34")
    private String prefix;

    /**
     * The Movil.
     */
    @Schema(description = "Phone number", example = "686124154")
    private String movil;

    /**
     * The Email.
     */
    // Email
    @Schema(description = "Email", example = "manuel1r223@gmail.com")
    private String email;

    /** The birth date. */
    // Birth date
    @Schema( description = "Holder's birthdate (dd/MM/yyyy)", example = "07/07/1975")
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDateTime birthDate;

    /** The occupation type code. */
    // Occupation type code
    @Schema(description = "Occupation type code", example = "2")
    private Integer occupationTypeCode;

    /** The purpose account code. */
    // Purpose account code
    @Schema(description = "purpose account code", example = "1")
    private Integer purposeAccountCode;

    /** The external dossier id. */
    // External dossier id
    @Schema(description = "UUID identifying a dossier in external applications",
            example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String externalDossierId;

    /** The person type. */
    // Person type
    @Schema(description = "Type of person", example = "F")
    private String personType;

    /** The person code. */
    // Person type
    @Schema(description = "Person code", example = "56236987")
    private String personCode;

    /** The state step access code. */
    // State step access code
    @Schema(description = "State step access code", example = "R")
    private String stateStepAccessCode;
}
