package es.santander.esponboapf.domain.docmanager;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The type Document lopd base 64.
 */
public class DocumentBase64 extends DownloadExternalDocumentResponse {

    /**
     * Gets base 64.
     *
     * @return the base 64
     */
    @JsonProperty("documentBase64")
    @Override
    public String getBase64() {
        return super.getBase64();
    }

    /**
     * Sets base 64.
     *
     * @param base64 the base 64
     */
    @JsonProperty("base64")
    @Override
    public void setBase64(String base64) {
        super.setBase64(base64);
    }

}
