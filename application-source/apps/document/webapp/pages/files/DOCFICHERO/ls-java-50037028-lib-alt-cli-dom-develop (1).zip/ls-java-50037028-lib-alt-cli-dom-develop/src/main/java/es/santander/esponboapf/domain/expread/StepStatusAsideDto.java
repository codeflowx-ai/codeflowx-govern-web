package es.santander.esponboapf.domain.expread;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StepStatusAsideDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Step status aside dto.", 
example = "{\"stepCode\":\"1\",\"asideName\":\"Datos personales\",\"order\":1,\"isCompleted\":true}")
// StepStatusAsideDto
public class StepStatusAsideDto implements Serializable {


    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2314352274354667679L;

    /** The step code. */
    // Step code
    @Schema(description = "Holder's step code", example = "2")
    private Integer stepCode;
    
    /** The aside name. */
    // Aside name
    @Schema(description = "Aside name",
            example = "Datos personales")
    private String asideName;

    /** The order. */
    // Order
    @Schema(description = "Order of the aside",
            example = "1")
    private Integer order;
    
    /** The is completed. */
    // Is completed
    @Schema(description = "If the step is completed.",
            example = "true")
    private Boolean isCompleted;
 
}
