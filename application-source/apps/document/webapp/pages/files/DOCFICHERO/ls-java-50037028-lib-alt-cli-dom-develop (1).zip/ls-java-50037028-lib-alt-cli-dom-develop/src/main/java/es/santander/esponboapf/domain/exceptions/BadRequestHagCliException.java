package es.santander.esponboapf.domain.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Class BadRequestHagCliException.
 */
@AllArgsConstructor
@Getter
public class BadRequestHagCliException extends RuntimeException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1629289475559826351L;
    /** The error name. */
    private final String errorName;

}
