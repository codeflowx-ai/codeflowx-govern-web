package es.santander.esponboapf.domain.expwri;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.validation.annotations.PersonalInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class SavePersonalInfoRequest.
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Required information to save the current holder personal information.")
@PersonalInfo
// Save personal info request
public class SavePersonalInfoRequest extends DossierParentDto {

    // datos personales asociados al titular
    // que realiza el onboarding digital

    /**
     * The holder personal info.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     */
    @Schema(description = "Holder personal information.")
    @Valid
    @NotNull
    private SavePersonalInfoHolderDto holderPersonalInfo;

}
