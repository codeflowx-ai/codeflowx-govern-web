package es.santander.esponboapf.domain.docmanager.uploaddoc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Upload document multipart.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadDocumentMultipart {

    /**
     * The Filename.
     */
    private String filename;

    /**
     * The Extension.
     */
    private String extension;

    /**
     * The Content.
     */
    private byte[] content;

}
