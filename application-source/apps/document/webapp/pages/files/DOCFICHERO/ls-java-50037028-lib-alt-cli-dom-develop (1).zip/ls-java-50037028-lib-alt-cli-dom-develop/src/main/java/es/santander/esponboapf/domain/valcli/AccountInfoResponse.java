package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccountInfoResponse.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountInfoResponse {

    /** The account code. */
    // AccountCode
    @Schema(maxLength = 10, description = "Account code", example = "4")
    private Long accountCode;

    /** The product data. */
    // ProductData
    @Schema(maxLength = 3, description = "Product identifier", example = "300")
    private String productData;

    /** The sub product data. */
    // SubProductData
    @Schema(maxLength = 3, description = "Subproduct identifier", example = "402")
    private String subProductData;

    /** The num max contractable. */
    // NumMaxContractable
    @Schema(maxLength = 2,
            description = "Maximum number allowed for one account holder to open this type of account", example = "2")
    private Integer numMaxContractable;

}
