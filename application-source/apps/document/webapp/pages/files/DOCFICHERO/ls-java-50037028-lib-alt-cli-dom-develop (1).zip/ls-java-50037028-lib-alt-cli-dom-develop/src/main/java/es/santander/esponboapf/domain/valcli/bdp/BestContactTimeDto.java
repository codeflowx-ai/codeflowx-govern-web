package es.santander.esponboapf.domain.valcli.bdp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new best contact time dto.
 */
@NoArgsConstructor
/**
 * Instantiates a new best contact time dto.
 *
 * @param fromDateTime the from date time
 * @param toDateTime   the to date time
 */
@AllArgsConstructor
@Data
@Builder
public class BestContactTimeDto {

    /** The from date time. */
    private String fromDateTime;

    /** The to date time. */
    private String toDateTime;
}
