package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * The Class StepChangeWithPriorityRequest.
 *
 * Request class to save information about a step of a dossier for the holder
 * matching the priority.
 */
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Required information to save only the current step, checking holder priority too.",
        example = "{\"priority\":\"1\"}")
// Step change with priority request
public class StepChangeWithPriorityRequest extends StepChangeRequest {

    /**
     * The priority.
     *
     * Holder's priority. '1' for main. Other numbers for subsequent ones.
     */
    // Priority
    @Schema(maxLength = 1, description = "Order of holders, e.g '1' is the main holder, '2' is the second holder",
            example = "1")
    @NotBlank
    @Size(max = 1)
    @Pattern(regexp = "[0-9]{1}")
    private String priority;

}
