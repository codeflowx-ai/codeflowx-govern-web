package es.santander.esponboapf.domain.fraud;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FraudOpinionResponse.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FraudOpinionResponse {

    /** The guid. */
    @Schema(description = "Guid.", example = "cd4604a3-2030-481a-a306-9067e2777da3")
    private String guid;

    /** The request number. */
    @Schema(description = "Dossier identifier.", example = "8627")
    private String requestNumber;

    /** The processing date. */
    @Schema(description = "Processing date.", example = "2023-08-14T14:39:32.958+02:00")
    private String processingDate;

    /** The success. */
    @Schema(description = "Result close case.", example = "false")
    private String success;

    /** The error code. */
    @Schema(description = "Error code.", example = "1103")
    @JsonInclude(Include.NON_NULL)
    private String errorCode;

    /** The error message. */
    @JsonInclude(Include.NON_NULL)
    @Schema(description = "Error message.", example = "El usuario no tiene permisos")
    private String errorMessage;
}
