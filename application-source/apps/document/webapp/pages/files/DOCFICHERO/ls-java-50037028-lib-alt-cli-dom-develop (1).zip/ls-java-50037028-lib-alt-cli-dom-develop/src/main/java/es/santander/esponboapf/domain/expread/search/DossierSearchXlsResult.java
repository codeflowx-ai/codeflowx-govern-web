package es.santander.esponboapf.domain.expread.search;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier search xls result.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DossierSearchXlsResult {

    /**
     * The Content.
     */
    private String content;

    /**
     * The Content type.
     */
    private String contentType;

    /**
     * The Name.
     */
    private String name;

    /**
     * The Page info.
     */
    private DossierSearchPageInfoDto pageInfo;

}
