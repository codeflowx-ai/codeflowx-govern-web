package es.santander.esponboapf.domain.docmanager.signrecord;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The Class CancelSignRecordResponse.
 */
// Constructors
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
@JsonTypeName("idExps")
// Cancel sign record response
public class CancelSignRecordResponse {

    /** The id exp sec. */
    // ID Exp sec
    private long idExpSec;

    /** The cancel docs. */
    // Cancel documents list
    private List<CancelSignDoc> cancelDocs;

}
