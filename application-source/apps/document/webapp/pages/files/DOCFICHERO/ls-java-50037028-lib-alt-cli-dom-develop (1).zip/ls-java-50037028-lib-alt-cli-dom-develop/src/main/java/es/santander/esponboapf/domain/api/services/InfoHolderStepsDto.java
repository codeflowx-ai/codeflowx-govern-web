package es.santander.esponboapf.domain.api.services;

import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class InfoHolderStepsDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InfoHolderStepsDto {

    /** The holder code. */
    private Long holderCode;

    /** The holder id. */
    private UUID holderId;

    /** The steps. */
    private List<InfoStepsDto> steps;

}
