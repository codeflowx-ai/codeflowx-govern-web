package es.santander.esponboapf.domain.docmanager.s3;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Document s 3 download request.
 */
//The class DocumentS3DownloadRequest
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentS3DownloadRequest {

    /**
     * The Folder.
     */
    //Folder
    @Schema(description = "Request folder", example = "629/TEST")
    @Pattern(regexp = "[\\w/]+")
    private String folder;

    /**
     * The Filename.
     */
    // The Filename
    @Schema(description = "File name", example = "file.jpg")
    @Pattern(regexp = "[\\w.]+")
    private String filename;

}
