package es.santander.esponboapf.domain.office;

import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder office data dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderOfficeDataDto {

    /** The Holder code. */
    private Long holderCode;

    /** The Holder id. */
    private UUID holderId;

    /** The Priority. */
    private String priority;

    /** The Name. */
    private String name;

    /** The Surname 1. */
    private String surname1;

    /** The Surname 2. */
    private String surname2;

    /** The Identity type code. */
    private Integer identityTypeCode;

    /** The identity number. */
    private String identityNumber;

    /** The Person type. */
    private String personType;

    /** The Person code. */
    private String personCode;

    /** The code cmc. */
    private String codeCmc;

    /** The name cmc. */
    private String nameCmc;

    /** The type client. */
    private Integer typeClient;

    /** The Prefix. */
    private String prefix;

    /** The Phone number. */
    private String phoneNumber;

    /** The country code. */
    private String countryCode;

    /** The Email. */
    private String email;

    /** The Steps. */
    private List<StepHolderOfficeDto> steps;

    /** The Processes. */
    private List<ControlProcessHolderOfficeDto> processes;

    /** The otp validated. */
    private boolean otpValidated;

}
