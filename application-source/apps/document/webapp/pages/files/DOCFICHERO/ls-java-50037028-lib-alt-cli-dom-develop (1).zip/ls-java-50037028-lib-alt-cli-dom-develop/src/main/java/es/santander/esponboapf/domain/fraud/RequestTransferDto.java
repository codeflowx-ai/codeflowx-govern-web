package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new request transfer dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Request data for a quick transfer.",
        example = "{\"beneficiaryIban\":\"ES1821007837171300060477\",\"identityNumber\":\"76776778T\","
                + "\"fullNameHolder\":\"Pruebas Onboarding test\",\"\"pendingTransfer\":\"true\","
                + "\"\"oldOtpKey\":\"F456F123\"}")
// Transfer data object
public class RequestTransferDto {

    /** The beneficiary iban. */
    // beneficiary Iban
    @Schema( description = "holder's IBAN account.", example = "ES1821007837171300060477")
    private String beneficiaryIban;

    /** The identity number. */
    // identity Number
    @Schema( description = "Holder's indentity number.", example = "76776778T")
    private String identityNumber;

    /** The full name holder. */
    // full Name Holder
    @Schema( description = "Holder's full name.", example = "Pruebas Onboarding test")
    private String fullNameHolder;

    @Schema( description = "pending transfer indicator.", example = "true")
    private Boolean pendingTransfer;

    @Schema( description = "old OTP's holder for transfering.", example = "F456F123")
    private String oldOtpKey;

}
