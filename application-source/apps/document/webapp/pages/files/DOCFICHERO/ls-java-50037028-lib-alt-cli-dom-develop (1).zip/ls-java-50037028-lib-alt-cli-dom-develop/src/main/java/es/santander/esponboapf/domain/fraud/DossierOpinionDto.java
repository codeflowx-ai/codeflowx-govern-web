package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierOpinionDto.
 *
 * Dossier opinion dto with status code.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DossierOpinionDto {

    /** The request number. */
    // The request number
    @Schema(description = "Statu.", example = "APST3")
    private String statusCode;

}
