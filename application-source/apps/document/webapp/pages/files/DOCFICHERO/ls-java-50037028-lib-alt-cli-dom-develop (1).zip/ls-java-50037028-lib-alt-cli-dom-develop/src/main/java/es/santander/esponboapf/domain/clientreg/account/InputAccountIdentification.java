package es.santander.esponboapf.domain.clientreg.account;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class InputAccountIdentification.
 *
 * class data input account identification
 */
//The class InputAccountIdentification
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Schema(description = "Output object account identification response",
        example = "\"accountIdType\":\"TXT\", \"accountId\":\"004912342410000619\"")
public class InputAccountIdentification {

    /**
     * accountIdType
     */
    // The account id type indicator
    @Schema(description = "account id type indicator", example = "TXT")
    private String accountIdType;
    /**
     * accountId
     */
    // The account id indicator
    @Schema(description = "account id indicator", example = "004912342410000619")
    private String accountId;

}
