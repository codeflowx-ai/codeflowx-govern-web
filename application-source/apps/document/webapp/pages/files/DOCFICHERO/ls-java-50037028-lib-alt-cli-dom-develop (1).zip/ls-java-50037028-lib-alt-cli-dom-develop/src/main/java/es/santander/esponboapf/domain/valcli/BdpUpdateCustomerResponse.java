package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new bdp update customer response.
 */
//The class BdpUpdateCustomerResponse
@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class BdpUpdateCustomerResponse {

    /** The result. */
    // The result
    private boolean result;

}
