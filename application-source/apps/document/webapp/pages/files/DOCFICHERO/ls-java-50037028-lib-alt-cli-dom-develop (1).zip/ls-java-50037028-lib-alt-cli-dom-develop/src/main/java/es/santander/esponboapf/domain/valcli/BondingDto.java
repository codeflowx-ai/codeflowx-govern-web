package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BondingDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class BondingDto {

    /**
     * The bonding code.
     *
     * E.g.: '8'
     */
    private String bondingCode;

    /**
     * The bonding desc.
     *
     * E.g.: 'SIN CLASIFICAR'
     */
    private String bondingDesc;
}
