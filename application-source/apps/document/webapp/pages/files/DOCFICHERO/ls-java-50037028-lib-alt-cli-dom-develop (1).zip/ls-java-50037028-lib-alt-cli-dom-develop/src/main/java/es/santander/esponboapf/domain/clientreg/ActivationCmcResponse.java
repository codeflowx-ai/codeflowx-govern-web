package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activation cmc response.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Output object activation CMC response", 
        example = "{ \"contract\":\"004969023390129159\","
                + " \"channelProduct\":\"123\","
                + " \"password\":\"12345\","
                + " \"signature\":\"2222222\","
                + " \"activationData\":\"2021-12-10\","
                + " \"signDate\":\"9999-12-31\"}")
//The class ActivationCmcResponse
public class ActivationCmcResponse {

	/** The contractCmc. */
    @Schema(description = "multichannel contract",example="004969023390129159")
    private String contract;
    
	/** The channelProduct. */
    @Schema(description = " channel product",example="123")
    private String  channelProduct; 
    
	/** The password. */
    @Schema(description = "password",example="14725836")
    private String password; 
    
	/** The signature. */
    @Schema(description = "signature",example="22222222")
    private String signature; 
    
	/** The activationDate. */
    @Schema(description = "activation date",example="2021-12-10")
    private String activationDate ; 
    
	/** The signDate. */
    @Schema(description ="Signature date",example="9999-12-31")
    private String signDate; 

}
