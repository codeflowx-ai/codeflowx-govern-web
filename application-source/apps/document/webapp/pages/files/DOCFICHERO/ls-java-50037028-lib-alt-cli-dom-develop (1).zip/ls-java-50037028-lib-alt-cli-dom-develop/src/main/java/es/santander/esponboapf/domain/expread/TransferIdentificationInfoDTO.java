package es.santander.esponboapf.domain.expread;

import es.santander.esponboapf.domain.validation.annotations.IdDocumentNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * The Class TransferIdentificationInfoDTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Transfer Identification Info DTO
public class TransferIdentificationInfoDTO {

    /** -----------------------DOSSIER_ACCOUNT INFORMATION------------------------------. */

    /** The iban. */
    @Schema(description = "Account number in IBAN format", example = "ES0700492594682815000250")
    @Pattern(regexp = "^[A-Z]{2}[0-9]{22}$")
    private String iban;

    /** The bban. */
    @Schema(description = "Account number in BBAN format", example = "00492594682815000250")
    @Pattern(regexp = "^[0-9]{20}$")
    private String bban;

    /** -----------------------HOLDER INFORMATION------------------------------. */

    /** The NAME. */
    // nombre del titular
    @Schema(description = "The holder name", example = "Beatriz")
    @Pattern(regexp = "[a-zA-ZÀ-ÿ]*")
    private String name;

    /** The SURNAME1. */
    // primer apellido del titular
    @Schema(description = "The holder surname 1", example = "Pascual")
    @Pattern(regexp = "[a-zA-ZÀ-ÿ]*")
    private String surname1;

    /** The SURNAME2. */
    // segundo apellido del titular
    @Schema(description = "The holder surname 2", example = "Prueba")
    @Pattern(regexp = "[a-zA-ZÀ-ÿ]*")
    private String surname2;

    /** The IDENTITYNUMBER. */
    // numero de documento de identificacion
    @Schema(description = "The holder identification document number", example = "78714975M")
    @IdDocumentNumber
    private String identityNumber;

    /** The identityType. */
    // tipo de identificación seleccionado por el titular
    @Schema(description = "Type of identification selected by the holder", example = "1")
    private Integer identityType;

    /** The prefix code. */
    // el prefijo en numero según el pais
    @Schema(description = "The prefix in number according to the country", example = "1")
    @Pattern(regexp = "[0-9]*")
    private String prefixCode;

    /** The MOVIL. */
    // telefono movil del titular
    @Schema(description = "The holder telephone number", example = "606696483")
    @Pattern(regexp = "[0-9]{9}")
    private String movil;

    /** The EMAIL. */
    // email del titular
    @Schema(description = "The holder email", example = "test@test.com")
    @Pattern(regexp = "^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$")
    @Size(max = 100)
    private String email;

    /** -----------------------HOLDER_BDP INFORMATION------------------------------. */

    /** The person type. */
    // person type
    @Schema(description = "person type indicator", example = "F")
    @Pattern(regexp = "[F]")
    private String personType;

    /** The person code. */
    // person code
    @Schema(description = "person code indicator", example = "12896587")
    @Pattern(regexp = "^[0-9]{1,20}$")
    private String personCode;

    /** -----------------------HOLDER_TRANSFER INFORMATION------------------------------. */

    /** The no transfer. */
    // si puede realizar más transferencias
    @Schema(description = "The holder name", example = "true")
    private Boolean noTransfer;

    /** The no retries. */
    // si tiene más reintentos
    @Schema(description = "The holder name", example = "false")
    private Boolean noRetries;

    /** The last beneficiary iban. */
    @Schema(description = "Last iban used to identificate the holder", example = "ES0700492594682815000250")
    @Pattern(regexp = "^[A-Z]{2}[0-9]{22}$")
    private String lastBeneficiaryIban;

    /** The pending transfer. */
    @Schema(description = "Is last transfer pending?", example = "true")
    private Boolean pendingTransfer;

    /** The old otp key. */
    @Schema(description = "Last transfer OTP. Only available if transfer is pending",
            example = "F456F123")
    @Pattern(regexp = "^([A-Z][0-9]{3}){2}$")
    private String oldOtpKey;

    /** -----------------------HOLDER_TRANSFER INFORMATION------------------------------. */

    @Schema( description = "Last iberpay reference", example = "TIC00499020202205250000000000000001NN")
    @Pattern(regexp = "^(?=.{3,16}$)(([A-Z0-9]*)(\\s*))$")
    private String iberpayRef;

    /** The transfer state code. */
    // Código del estado de la transferencia
    @Schema(description = "Transfer state code", example = "RC")
    @Pattern(regexp = "^[A-Z]{2}$")
    private String transferStateCode;

}
