package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class DossierStateSubstateChangeDto.
 *
 * Information to change a dossier state and/or substate.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Information to change a dossier state and or substate.",
        example = "{\"stateCode\":1,\"substateCode\":1}")
public class DossierStateSubstateChangeDto extends UniversalDossier {

    /**
     * The state code.
     *
     * Code of the state which will be updated to.
     * E.g.: 1
     */
    @Schema(description = "Code of the state which will be updated to.", example = "1")
    @NotNull
    private Integer stateCode;

    /**
     * The substate code.
     *
     * Code of the substate which will be updated to.
     * E.g.: 1
     */
    @Schema(description = "Code of the substate which will be updated to.", example = "1")
    private Integer substateCode;
}
