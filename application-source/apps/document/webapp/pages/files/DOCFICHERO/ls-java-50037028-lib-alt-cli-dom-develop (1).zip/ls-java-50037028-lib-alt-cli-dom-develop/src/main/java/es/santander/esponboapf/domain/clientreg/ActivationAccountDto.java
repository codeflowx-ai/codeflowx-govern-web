package es.santander.esponboapf.domain.clientreg;

import java.util.List;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activation account dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information necessary to activate the account.")
public class ActivationAccountDto {

    /** The dossier code. */
    @Schema(description = "Dossier code", example = "505")
    private Long dossierCode;

    @Schema(description = "UUID identifying a dossier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private UUID dossierId;

    /** The account entity. */
    @Schema(description = "Associated Account Company", example = "0049")
    private String accountEntity;

    /** The account branch. */
    @Schema(description = "Associated Account Office", example = "6902")
    private String accountBranch;

    /** The account cd. */
    @Schema(description = "account control digit.", example = "00")
    private String accountCd;

    /** The partenon product. */
    @Schema(description = "Account product in CCC format", example = "221")
    private String partenonProduct;

    /** The partenon account. */
    @Schema(description = "Account number", example = "1234567")
    private String partenonAccount;

    /** The product type. */
    @Schema(description = "Product type of the Partenon associated account.", example = "222")
    private String productType;

    /** The sub type. */
    @Schema(description = "Partenon Associated Account Product Subtype", example = "222")
    private String subType;

    /** The old format product. */
    @Schema(description = "Old format product", example = "string")
    private String oldFormatProduct;

    /** The old format account. */
    @Schema(description = "Old format account", example = "0000325")
    private String oldFormatAccount;

    /** The standard of reference. */
    @Schema(description = "Standar of reference", example = "00001")
    private String standardOfReference;

    /** The card info. */
    @Schema(description = "Card info", example = "{}")
    private CardDto cardInfo;

    /** The holders. */
    @Schema(description = "Holder list with your information", example = "[]")
    private List<HolderActivationDto> holders;

    /** The is BBOO registration. */
    @Schema(description = "Indicates whether the dossier has been created by BBOO.", example = "true")
    private Boolean isBBOORegistration;

    @Schema(description = "Account number in international format.", example = "ES2100495525562010030971")
    private String iban;

    /** The external app. */
    @Schema(description = "Indicates whether the dossier campaign is external or not.", example = "true")
    private Boolean externalApp;

    /** The dossier id external. */
    @Schema(description = "External UUID identifying a dossier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private UUID dossierIdExternal;

    /** The send welcome email. */
    @Schema(description = "Flag to allow the app to send the welcome email", example = "true")
    private boolean sendWelcomeEmail;

    /** The full partenon. */
    @Schema(description = "Full partenon account number returned by account activation", example = "004955253000002807")
    private String fullPartenon;

    /** The full local account. */
    @Schema(description = "Full local account number returned by account activation", example = "004955252910030181")
    private String fullLocalAccount;

    /** The state dossier. */
    @Schema(description = "Dossier state", example = "3")
    private Integer stateDossier;

    /** The substate dossier. */
    @Schema(description = "Dossier substate", example = "4")
    private Integer substateDossier;

    /** The campaign code. */
    @Schema(description = "Campaign code", example = "219")
    private Integer campaignCode;
}
