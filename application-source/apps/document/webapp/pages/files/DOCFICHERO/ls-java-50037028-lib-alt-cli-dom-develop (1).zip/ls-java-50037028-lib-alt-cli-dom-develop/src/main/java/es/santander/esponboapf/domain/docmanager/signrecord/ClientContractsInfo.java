package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ClientContractsInfo.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@Data
public class ClientContractsInfo {

    /** The contract code. */
    private int contractCode;

    /** The gnid. */
    private String gnid;

    /** The print gnid. */
    private String printGnid;

    /** The in sign exp. */
    private boolean inSignExp;

    /** The signed. */
    private boolean signed;

}
