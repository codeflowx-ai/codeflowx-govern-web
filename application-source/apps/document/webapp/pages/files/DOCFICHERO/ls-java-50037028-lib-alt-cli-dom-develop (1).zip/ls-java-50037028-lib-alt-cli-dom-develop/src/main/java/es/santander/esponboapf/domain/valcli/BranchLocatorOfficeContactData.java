package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Branch locator office contact data.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchLocatorOfficeContactData {

    /** The Phone number. */
    private String phoneNumber;

    /** The Fax. */
    private String fax;

    /** The Email. */
    private String email;

    /** The Customer phone. */
    private String customerPhone;

}
