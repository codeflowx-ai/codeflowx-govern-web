package es.santander.esponboapf.domain.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Pair.
 *
 * @param <T> the generic type
 * @param <V> the value type
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Pair<T, V> {

    /** The left. */
    private T left;

    /** The right. */
    private V right;

    /**
     * Of.
     *
     * @param <T>   the generic type
     * @param <V>   the value type
     * @param left  the left
     * @param right the right
     * @return the pair
     */
    public static <T, V> Pair<T, V> of(T left, V right) {
        return new Pair<>(left, right);
    }

}
