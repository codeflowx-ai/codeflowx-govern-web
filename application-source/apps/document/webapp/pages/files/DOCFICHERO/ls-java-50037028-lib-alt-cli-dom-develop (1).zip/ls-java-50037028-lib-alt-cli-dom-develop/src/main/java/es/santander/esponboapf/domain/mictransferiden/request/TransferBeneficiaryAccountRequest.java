package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * TransferBeneficiaryAccountRequest
 *
 * The type Transfer beneficiary account request.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferBeneficiaryAccountRequest {

    /** The Beneficiary account type. */
    private String beneficiaryAccountType;

    /** The Iban beneficiary account. */
    private String ibanBeneficiaryAccount;

}
