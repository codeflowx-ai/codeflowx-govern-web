package es.santander.esponboapf.domain.gesdoc;

import java.io.File;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

/**
 * The Class TextPrintingRequest.
 */
//Class TextPrintingRequest
@Data
@Builder
@Schema(description = "File and information to be embedded in it.")
public class TextPrintingRequest {

    /** The content. */
    @Schema(description = "File content")
    private File content;

    /** The info. */
    @Schema(description = "Info about the file")
    private String info;

}
