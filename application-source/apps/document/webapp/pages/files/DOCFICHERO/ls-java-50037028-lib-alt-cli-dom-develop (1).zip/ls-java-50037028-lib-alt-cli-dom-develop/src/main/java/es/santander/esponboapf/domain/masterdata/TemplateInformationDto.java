package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Template information dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Template information dto
public class TemplateInformationDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 9183853215175197584L;

    /**
     * The Template name.
     */
    @Schema(description = "The template file name", example = "name")
    private String templateName;

    /**
     * The Template path.
     */
    @Schema(description = "The template file path", example = "/path")
    private String templatePath;

    /** The template url. */
    @Schema(description = "Url from which the file can be downloaded.", example = ":/algo/alsdfo")
    private String templateUrl;

}
