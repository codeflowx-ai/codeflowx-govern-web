package es.santander.esponboapf.domain.expread;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class TransferInfoDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransferInfoDto {

    /** The bban. */
    // The bban
    @Schema(description = "BBAN number", example = "00495525532110000452")
    private String bban;

    /** The transfer details. */
    // The transfer details
    @Schema(description = "Transfer details", example = "[]")
    private List<TransferDetailsDto> transferDetails;

}
