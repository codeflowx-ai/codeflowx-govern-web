package es.santander.esponboapf.domain.expwri;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BooleanResult.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class BooleanResult {

    // it's true when the validation is OK
    /**
     * The result.
     *
     * This value is an indicator for validation results.
     */
    private boolean result;
}
