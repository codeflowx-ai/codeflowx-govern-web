package es.santander.esponboapf.domain.expread.recovery;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Recovery info account dto.
 */
//The class RecoveryInfoAccountDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecoveryInfoAccountDto {

    /**
     * The Account code.
     */
    @Schema(description = "Code of the account", example = "221")
    private Long accountCode;

    /**
     * The Account name.
     */
    @Schema(description = "Name of the account", example = "Cuenta online")
    private String accountName;

}
