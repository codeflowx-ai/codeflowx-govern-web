package es.santander.esponboapf.domain.fraud;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StatusDto.
 *
 * StatusDto.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StatusDto {

    /** The status code. */
    private String statusCode;

    /** The status description. */
    private String statusDescription;

}
