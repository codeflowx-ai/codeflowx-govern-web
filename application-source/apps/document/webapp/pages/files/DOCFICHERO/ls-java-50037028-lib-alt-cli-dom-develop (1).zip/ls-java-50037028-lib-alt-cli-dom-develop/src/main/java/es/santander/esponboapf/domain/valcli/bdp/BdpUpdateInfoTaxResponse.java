package es.santander.esponboapf.domain.valcli.bdp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpUpdateInfoTaxResponse.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class BdpUpdateInfoTaxResponse {

    /** The country code. */
    private String countryCode;

    /** The tin. */
    private String tin;

    /** The tax reason code. */
    private String taxReasonCode;

}
