package es.santander.esponboapf.domain.ocr;

import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new ocr out dto.
 */

@NoArgsConstructor
@Data
public class OcrOutDto {

    /** The holder id. */
    @Schema(maxLength = 100, description = "Unique holder identifier. The first time is null.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /** The is expired document. */
    @Schema(description = "indicates that if the document is expired", example = "false")
    private boolean isExpiredDocument;

    /** The surname 1. */
    @Schema(maxLength = 20, description = "holder's name", example = "MARIA DE LA PAZ")
    private String name;

    /** The surname 1. */
    @Schema(maxLength = 20, description = "holder's last name", example = "CAMPOS")
    private String surname1;

    /** The surname 2. */
    @Schema(maxLength = 20, description = "holder's second last name", example = "TRIGO")
    private String surname2;

    /** The identity type code. */
    @Schema(description = "indicates holder's indentity document. E.g 1 means DNI", example = "1")
    private Integer identityTypeCode;

    /** The Identity Type Name. */
    @Schema(maxLength = 6,
            description = "Description of the type of identification and the data to be displayed on the screen",
            example = "DNI")
    private String identityTypeName;

    /** The identity number. */
    @Schema(maxLength = 9, description = "holder's identity number", example = "11111111A")
    private String identityNumber;

    /** The birth date. */
    @Schema(maxLength = 6, description = "holder´s birthdate", example = "07/07/1975")
    private String birthDate;

    /** The sex. */
    @Schema(maxLength = 1, description = "holder's gender", example = "F")
    private String sex;

    /** The birth country. */
    @Schema(maxLength = 2, description = "holder's birth country", example = "ES")
    private String birthCountry;

    /** The birth country name. */
    @Schema(maxLength = 250, description = "Name of the country of birth", example = "ESPAÑA")
    private String birthCountryName;

    /** The birth province. */
    @Schema(maxLength = 48, description = "holder's birth region. This could be empty for foreigners",
            example = "MADRID")
    private String birthProvince;

    /** The birth province code. */
    @Schema(description = "holder's birth province code", example = "28")
    private String birthProvinceCode;

    /** The birth city. */
    @Schema(maxLength = 48, description = "holder's birth city.", example = "MADRID")
    private String birthCity;

    /** The nationality. */
    @Schema(maxLength = 2, description = "holder's nationality.", example = "ES")
    private String nationality;

    /** The nationality description. */
    @Schema(maxLength = 250, description = "Name of the country of citizenship", example = "ESPAÑA")
    private String nationalityDescription;

    /** The address. */
    @Schema(description = "holder's residential address.", example = "CALLE ME FALTA UN TORNILLO")
    private String address;

    /** The province. */
    @Schema(description = "province or region of residence of the holder.", example = "MADRID")
    private String province;

    /** The province code. */
    @Schema(description = "holder's province code", example = "28")
    private String provinceCode;

    /** The city. */
    @Schema(description = "city of residence of the holder.", example = "MADRID")
    private String city;

}
