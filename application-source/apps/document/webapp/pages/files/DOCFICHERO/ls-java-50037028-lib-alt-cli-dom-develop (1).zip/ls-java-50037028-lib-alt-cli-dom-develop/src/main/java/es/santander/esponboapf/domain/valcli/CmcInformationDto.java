package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CmcInformationDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information indicating the degree of bonding of a client")
public class CmcInformationDto {

    /** The contract cmc. */
    // ContractCmc
    @Schema(description = "The contract cmc", example = "---------")
    private String contractCmc;

    /** The state code cmc. */
    // StateCodeCmc
    @Schema(description = "The state code cmc", example = "----------")
    private String stateCodeCmc;

    /** The state desc cmc. */
    // StateDescCmc
    @Schema(description = "The state description cmc", example = "-----------")
    private String stateDescCmc;

    /** The ind password. */
    // IndPassword
    @Schema(description = "The ind password", example = "--------")
    private String indPassword;

}
