package es.santander.esponboapf.domain.onboarding.api;

import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.api.services.SignerDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class GetIdSignRequest.
 */

/**
 * To string.
 *
 * @return the java.lang. string
 */
@Data

/**
 * To string.
 *
 * @return the java.lang. string
 */
@Builder

/**
 * Instantiates a new gets the id sign request.
 */
@NoArgsConstructor

/**
 * Instantiates a new gets the id sign request.
 *
 * @param idExpSec       the id exp sec
 * @param signer         the signer
 * @param signerFullName the signer full name
 * @param documentNumber the document number
 * @param https          the https
 * @param summary        the summary
 * @param domain         the domain
 * @param signChannel    the sign channel
 * @param language       the language
 * @param country        the country
 */
@AllArgsConstructor
// GetIdSignRequest
public class GetIdSignRequest {

    /** The id exp sec. */
    // Id exp
    @NotNull
    @Schema(description = "Sign Expedient's identifier.", example = "16")
    private Integer idExpSec;

    /** The signer. */
    // Signer
    @Schema(description = "Signer identifier.", example = "F124649583")
    private SignerDto signer;
    
    /** The signer full name. */
    @Schema(description = "Signer full name.", example = "QAF OLC JOSEFA")
    private String signerFullName;
    
    /** The document number. */
    @Schema(description = "Document number.", example = "65537253A")
    private String documentNumber;
    
    /** The https. */
    @Schema(description = "If 'S' the URL will have the value https else http ", example = "S")
    private String https;
    
    /** The summary. */
    @Schema(description = "Summary. This fiels is optional, if not reported, displays the generic"
            + " message with the reported parameters, if reported, overwrites the generic message.",
            example = "D./Dña. QAF OLC JOSEFA, con documento 65537253A, declara...")
    private String summary;
    
    /** The domain. */
    @Schema(description = "Domain.", example = "santander.isban.dev.corp")
    private String domain;
    
    /** The sign channel. */
    @Schema(description = "Sign channel.", example = "OFI")
    private String signChannel;
    
    /** The language. */
    @Schema(description = "Language.", example = "es")
    private String language;
    
    /** The country. */
    @Schema(description = "Country.", example = "ES")
    private String country;
}
