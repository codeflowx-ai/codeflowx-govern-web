package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

/**
 * The Class CancelSignContract.
 */
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
// Cancel sign contract
public class CancelSignContract extends CancelSignRecordRequest {

    /** The contract. */
    // Contract
    private String contract;

    /** The type reference. */
    // Type reference
    private String typeReference;
}
