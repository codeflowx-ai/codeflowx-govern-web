package es.santander.esponboapf.domain.corresp;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class OtpCache.
 */
@NoArgsConstructor
@Data
public class OTPCache implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -6104971633678327986L;

    /** The holder id. */
    private UUID holderId;

    /** The phone number. */
    private String phoneNumber;

    /** The otp skel. */
    private String otpSkel;

    /** The retries. */
    private byte retries;

    /** The expiration. */
    private LocalDateTime expiration;
}
