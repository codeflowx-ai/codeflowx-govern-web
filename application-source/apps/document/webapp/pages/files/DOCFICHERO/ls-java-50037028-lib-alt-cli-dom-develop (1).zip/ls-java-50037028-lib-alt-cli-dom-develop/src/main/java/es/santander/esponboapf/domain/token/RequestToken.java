package es.santander.esponboapf.domain.token;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RequestToken.
 */
@NoArgsConstructor
@Data
public class RequestToken {

    /** The audiences. */
    private String audiences;

    /** The credential type. */
    private List<String> credentialType;

    /** The id attributes. */
    private Atributes idAttributes;

    /** The password. */
    private String password;

    /** The realm. */
    private String realm;
}
