package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.validation.annotations.IdDocumentNumber;
import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder video identification request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Holder video identification data request
public class ValidateIdentificationRequest {

    /**
     * The Holder Identity Number.
     */
    // Identity number
    @Schema(description = "Holder indentity number", example = "29617347V")
    @NotNull
    @IdDocumentNumber
    private String docIdentidad;

    /**
     * The Dossier code.
     */
    // Dossier code
    @Schema(description = "Dossier code number", example = "643")
    @NotNull
    private String expedienteId;

    /**
     * The process result.
     */
    // Result
    @Schema(description = "Indicate if the result is KO or OK", example = "OK")
    @NotNull
    private String estadoVC;
    
    /**
     * The image front base 64.
     * String rendering the FRONT image in base64.
     */
    @Schema(description = "String rendering the FRONT image in base64",
            example = "/8j/4AAQS8ZJRgAB3gAAAQABAAF")
    @XssValid
    private String anverso;

    /**
     * The image back base 64.
     * String rendering the BACK image in base64
     */
    @Schema(description = "String rendering the BACK image in base64",
            example = "/9j/4AAQSkZJRgABAgAAAQABAAD")
    @XssValid
    private String reverso;

}
