package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Office data dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OfficeDataDto {

    /** The Id. */
    private String id;

    /** The Code. */
    private String code;

    /** The Entity code. */
    private String entityCode;

    /** The Name. */
    private String name;

    /** The Poi status. */
    private String poiStatus;

    /** The Address. */
    private String address;

    /** The Zipcode. */
    private String zipCode;

    /** The City. */
    private String city;

}
