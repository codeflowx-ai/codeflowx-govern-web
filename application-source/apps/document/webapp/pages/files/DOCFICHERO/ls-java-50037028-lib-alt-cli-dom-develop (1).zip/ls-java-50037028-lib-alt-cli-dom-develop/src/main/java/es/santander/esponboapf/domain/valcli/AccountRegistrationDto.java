package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccountRegistrationDto.
 */
@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class AccountRegistrationDto {

    /**
     * The branch account.
     *
     * brach account code. Eg: 0001
     */
    @Schema(maxLength = 4, description = "Office", example = "0001")
    private String branchAccount;

    /**
     * The product data.
     *
     * product for the account to be opened. Eg: 300
     */
    @Schema(maxLength = 3, description = "Product account", example = "300")
    private String productData;

    /**
     * The subproduct data.
     *
     * subproduct for the account to be opened. Eg: 402
     *
     */
    @Schema(maxLength = 3, description = "Sub-Product account", example = "402")
    private String subproductData;
}
