package es.santander.esponboapf.domain.corresp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Send email data request.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
// Send communication data request object
public class SendCommunicationDataRequest {

    /**
     * The Subject.
     */
    // Subject
    private String subject;

    /**
     * The Message.
     */
    // Message
    private String message;

}
