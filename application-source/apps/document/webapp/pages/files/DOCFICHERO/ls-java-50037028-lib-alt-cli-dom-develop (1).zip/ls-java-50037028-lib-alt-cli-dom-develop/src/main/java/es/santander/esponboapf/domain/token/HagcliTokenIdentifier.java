package es.santander.esponboapf.domain.token;

import java.io.Serializable;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Hagcli token identifier.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
public class HagcliTokenIdentifier implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 3559290583975931928L;

    /**
     * The dossier id.
     * <p>
     * The dossier identifier
     */
    // Dossier id
    @Schema(maxLength = 100, description = "Unique dossier identifier.",
            example = "70fd7423-5759-447b-a92f-6e88f514cc89")
    private UUID dossierId;

    /**
     * The holder id.
     * <p>
     * The holder identifier
     */
    // Holder identifier
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

}
