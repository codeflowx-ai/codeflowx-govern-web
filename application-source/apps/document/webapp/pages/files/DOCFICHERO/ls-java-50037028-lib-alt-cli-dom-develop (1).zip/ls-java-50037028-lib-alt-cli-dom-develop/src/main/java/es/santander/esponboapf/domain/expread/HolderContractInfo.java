package es.santander.esponboapf.domain.expread;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * The Class HolderAnyContractFileFullInfo.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
@Data
@ToString
public class HolderContractInfo extends HolderInfoDetailsDto {

    /**
     * The Dossier code.
     */
    @Schema(description = "Number identifying a dossier", example = "629")
    private Long dossierCode;

    /**
     * The Dossier id.
     */
    @Schema(description = "UUID identifying a dossier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String dossierId;

    /**
     * The Holder id.
     */
    @Schema(description = "UUID identifying an holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /**
     * The campaignCode.
     */
    @Schema(description = "Campaign code", example = "1")
    private Integer campaignCode;

    /**
     * The account code.
     */
    @Schema(description = "Account code", example = "222")
    private Long accountCode;

    /**
     * The description campaing.
     */
    @Schema(description = "Campaign description", example = "CuentaOnline")
    private String campaignDescription;

    /**
     * The risk fioc.
     */
    @Schema(description = "Indicate if the holder has a risk in fioc", example = "A1")
    private String riskFioc;

    /**
     * The office.
     */
    @Schema(description = "Dossier office code", example = "0049")
    private String office;

    /**
     * The studies.
     */
    @Schema(description = "studies description", example = "Secundarios")
    private String studies;

    /**
     * The obligations abroad.
     */
    @Schema(description = "indicator for obligations abroad", example = "false")
    private Boolean obligationsAbroad;

    /**
     * The citizenship.
     */
    @Schema(description = "Holder Nationality description.", example = "Francia")
    private String citizenship;

    /**
     * The birth country description.
     */
    @Schema(description = "Holder's birth country description.", example = "Francia")
    private String birthCountryDescription;

    /**
     * The account IBAN.
     */
    @Schema(description = "Account number in IBAN format.", example = "ES7800490001582915888832")
    private String accountIBAN;

    /**
     * The countries tax.
     */
    private List<HolderCountryTaxInfo> countriesTax;

    /** The client type. */
    @Schema(description = "Number identifying the holder type", example = "3")
    private Integer clientType;

}
