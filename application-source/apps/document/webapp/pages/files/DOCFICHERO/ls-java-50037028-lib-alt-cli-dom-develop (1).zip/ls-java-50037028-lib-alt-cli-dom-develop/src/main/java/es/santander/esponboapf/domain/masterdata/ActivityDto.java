package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activity dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Activity performed according to occupation", example ="{\"activityCode\":1,"
        + "\"activityName\":\"Te dedicas al comercio de joyas, piedras o materiales preciosos\""
        + "\"order\":1}")
public class ActivityDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = 7030723539209605299L;

    /**
     * The activity code.
     *
     * The code of the activity.
     */
    @Schema(description = "number identifying an activity", example = "1")
    private Integer activityCode;

    /**
     * The activity name.
     *
     * The name of the activity
     */
    @Schema(maxLength = 250, description = "description of the activity",
            example = "Te dedicas al comercio de joyas, piedras o materiales preciosos")
    private String activityName;

    /**
     * The order.
     *
     * The order of the activity
     */
    @Schema(description = "order of activity", example = "1")
    private Integer order;

}
