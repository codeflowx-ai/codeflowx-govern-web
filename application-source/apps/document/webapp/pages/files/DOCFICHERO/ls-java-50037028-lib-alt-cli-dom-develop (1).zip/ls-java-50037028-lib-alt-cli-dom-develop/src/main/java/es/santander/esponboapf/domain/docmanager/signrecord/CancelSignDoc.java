package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CancelSignDoc.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
// Cancel sign doc
public class CancelSignDoc {

    /** The type doc. */
    // Type doc
    private String typeDoc;

    /** The gn id. */
    // GN_ID
    private String gnId;

}
