package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new device number response.
 */
// Constructors
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Final control response for device number", 
    example = " \"numDispositivo\":\"6\"")
@Builder
// Device number response
public class DeviceNumberResponse {

    /** The result. */
    // Num dispositivo
    @Schema(description = "device number indicator", example = "6")
    private String numDispositivo;

}
