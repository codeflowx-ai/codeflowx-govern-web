package es.santander.esponboapf.domain.docmanager.pdf;

import java.io.ByteArrayOutputStream;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * PdfResponse class
 *
 */
//The class PdfResponse
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class PdfResponse {

    /**
     * bos
     */
    private ByteArrayOutputStream bos;

    /**
     * name
     */
    private String name;
}
