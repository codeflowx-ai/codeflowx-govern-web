package es.santander.esponboapf.domain.expread;

import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder open dossier data dto.
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class HolderOpenDossierDataDto {

    /**
     * The Dossier open.
     */
    // DossierOpen
    @Schema(description = "If the dossier is open", example = "true")
    private Boolean dossierOpen;

    /**
     * The Dossier code.
     */
    @Schema(description = "Dossier open identifier", example = "1")
    private Long dossierCode;

    /**
     * The Dossier id.
     */
    @Schema(description = "Dossier open identifier", example = "cfeb56c7-3e99-4d4f-8f57-278daac4b4fe")
    private UUID dossierId;

    /**
     * The Full name.
     */
    // FullName
    @Schema(description = "Full name", example = "Nombre completo")
    private String fullName;

    /** The campaign code. */
    @Schema(description = "Campaign code", example = "221")
    private Integer campaignCode;
}
