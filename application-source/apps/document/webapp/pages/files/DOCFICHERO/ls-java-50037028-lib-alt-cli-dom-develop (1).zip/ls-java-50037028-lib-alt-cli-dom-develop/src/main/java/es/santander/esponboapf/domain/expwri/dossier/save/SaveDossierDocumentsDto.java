package es.santander.esponboapf.domain.expwri.dossier.save;

import es.santander.esponboapf.domain.validation.annotations.SaveDocumentValid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import java.util.List;

/**
 * The type Save dossier documents dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@SaveDocumentValid
// Save dossier documents dto
public class SaveDossierDocumentsDto {

    /**
     * The Confirm fraud rules.
     */
    // Confirm fraud rules
    private Boolean confirmFraudRules;

    /**
     * The Holders.
     */
    // Holder list
    @Valid
    private List<SaveHolderDocumentsDto> holders;

}
