package es.santander.esponboapf.domain.expread.document;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderDocumentInfoDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information about the documents of each of the holders of a dossier.")
// Holder document info
public class HolderDocumentInfoDto {

    /**
     * The holder code.
     */
    // Holder code
    @Schema(description = "Number identifying an holder", example = "341")
    private Long holderCode;

    /**
     * The priority.
     */
    // Priority
    @Schema(description = "Number identifying the priority", example = "1")
    private String priority;

    /**
     * The Identity number.
     */
    // Identity number
    @Schema(description = "Identity document code", example = "59702821L")
    private String identityNumber;

    /**
     * The Person code.
     */
    // Person code
    @Schema(description = "Person code of the holder in bdp", example = "1234567")
    private String personCode;

    /**
     * The identification info.
     */
    // Identification info
    @Schema(description = "Information about the status of the holder's identification.",
            example = "{\"stateCode\":\"O\",\"stateName\":\"Identificación\",\"identificationCode\":1,"
                    + "\"identificationName\":\"Vídeollamada\"}")
    private IdentificationDto identificationInfo;

    /** The signed. */
    @Schema(description = "Are all douments signed?", example = "true")
    private Boolean signed;

    /** The access code completed. */
    @Schema(description = "Does this dossier have its access code sent", example = "true")
    private Boolean accessCodeCompleted;

    /**
     * The documents.
     */
    // Documents
    @Schema(description = "List of documents of each holder indicating their type,"
            + " name, status, reason for rejection.", example = "1")
    private List<DocumentTypeInfoDto> documents;

}
