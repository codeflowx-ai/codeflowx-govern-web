package es.santander.esponboapf.domain.valcli.bdp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new contact indicators dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new contact indicators dto.
 *
 * @param contactType        the contact type
 * @param preferredIndicator the preferred indicator
 * @param purposeCode        the purpose code
 * @param useCode            the use code
 */
@AllArgsConstructor
@Data
public class ContactIndicatorsDto {

    /** The contact type. */
    private String contactType;

    /** The preferred indicator. */
    private String preferredIndicator;

    /** The purpose code. */
    private String purposeCode;

    /** The use code. */
    private String useCode;

}
