package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new bdp update response.
 */
//The class BdpUpdateResponse
@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class BdpUpdateResponse {

    /** The modify data person. */
    private String modifyDataPerson;
}
