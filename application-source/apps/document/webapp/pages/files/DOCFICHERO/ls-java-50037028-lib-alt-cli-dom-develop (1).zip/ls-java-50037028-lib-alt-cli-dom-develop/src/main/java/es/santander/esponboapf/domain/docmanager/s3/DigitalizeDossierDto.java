package es.santander.esponboapf.domain.docmanager.s3;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Digitalize holder dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalizeDossierDto {

    /**
     * The Dossier code.
     */
    // DossierCode
    private Long dossierCode;

    /**
     * The Holders.
     */
    // Holders
    private List<DigitalizeHolderDto> holders;

}
