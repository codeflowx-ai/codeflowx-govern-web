package es.santander.esponboapf.domain.ocr;

import java.util.UUID;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class OcrInDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Information from images obtained from the reading of an identity document",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"priority\":1,"
        + "\"imageFormat\":\"png\",\"imageFrontBase64\":\"/8j/4AAQS8ZJRgAB3gAAAQABAAF\","
        + "\"imageBackBase64\":\"/8j/4AAQS8ZJRgAB3gAAAQABAAF\"}")
public class OcrInDto {

    /**
     * The holder id.
     *
     * Unique holder identifier.
     *
     * E.g.: '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /**
     * The priority.
     *
     * Holder's priority. '1' for main. Other numbers for subsequent ones.
     *
     * E.g.: '2'
     *
     */
    @Schema(maxLength = 1, description = "Order of holders, e.g '1' is the main holder, '2' is the second holder",
            example = "1")
    @NotBlank
    @Size(max = 1)
    @Pattern(regexp = "[0-9]{1}")
    private String priority;

    /**
     * The image format.
     *
     * This represents an allowed image's extension for OCR reading.
     *
     * E.g.: 'png'
     */
    @Schema(description = "Is an allowed image's extension for OCR reading.", example = "png, jpg")
    @XssValid
    @NotBlank
    @Size(min = 3)
    private String imageFormat;

    /**
     * The image front base 64.
     *
     * String rendering the FRONT image in base64.
     */
    @Schema(description = "String rendering the FRONT image in base64",
            example = "/8j/4AAQS8ZJRgAB3gAAAQABAAF")
    @XssValid
    private String imageFrontBase64;

    /**
     * The image back base 64.
     *
     * String rendering the BACK image in base64
     */
    @Schema(description = "String rendering the BACK image in base64",
            example = "/9j/4AAQSkZJRgABAgAAAQABAAD")
    @XssValid
    private String imageBackBase64;
}
