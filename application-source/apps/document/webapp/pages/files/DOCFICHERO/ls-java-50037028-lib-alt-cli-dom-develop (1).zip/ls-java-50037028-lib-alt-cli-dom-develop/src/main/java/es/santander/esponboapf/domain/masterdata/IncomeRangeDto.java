package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class IncomeRangeDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Income range information",
example = "{\"incomeRangeCode\":1,\"incomeRangeName\":\"Up to 30.000\"}")
public class IncomeRangeDto implements Serializable{

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -7753775825978657210L;

    /**
     * The income range code.
     *
     * E.g.: 1
     */
    @Schema(description = "Income range information identifier", example = "1")
    private Integer incomeRangeCode;

    /**
     * The income range name.
     *
     * E.g.: 'Up to 30.000'
     */
    @Schema(maxLength = 200, description = "Income range information text", example = "Up to 30.000")
    private String incomeRangeName;

}
