package es.santander.esponboapf.domain.docmanager.signrecord;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class SignRecordAndHolderInfo.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode
@Builder
// Cancel sign contract
@Schema(description = "Natural person performing the digital onboarding",
        example = "{\"signRecordId\":1234,\"personNumber\":\"F21485\","
                + "\"fullName\":\"Elena Nito Del Bosque\",\"identityDocument\":\"12345678X\"}")
public class SignRecordAndHolderInfo {

    /** The contract. */
    // Contract
    @Schema(description = "Sign record identifier", example = "1234")
    private Long signRecordId;

    /** The type reference. */
    // Type reference
    @Schema(description = "The internal person identifier", example = "F21485")
    private String personNumber;

    /** The full name. */
    @Schema(description = "Holder full name", example = "Elena Nito del Bosque")
    private String fullName;

    /** The identity document. */
    @Schema(description = "Identifier document number", example = "12345678X")
    private String identityDocument;

    /** The full phone number. */
    @Schema(description = "Full phone number (including international prefix) where the sms with the OTP key "
            + "will be sent to. ",
            example = "0034666666666")
    private String fullPhoneNumber;

    /** The holder id. */
    @Schema(description = "Unique uuid identifier of the holder.", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /** The register date. */
    @Schema(description = "Date of registration of the dossier.", example = "01/11/2021")
    private LocalDateTime registerDate;

    /** The type client. */
    @Schema(description = "Holder type client", example = "1")
    private Integer typeClient;

    /** The ip address. */
    @Schema(description = "IP address.", example = "123.876.345.09")
    private String ipAddress;

    /** The full holder address. */
    @Schema(description = "Holder's address", example = "Calle Jaime Vera 7 28011 Madrid")
    private String fullHolderAddress;

    /** The email. */
    @Schema(description = "Holder's e-mail address", example = "example@example.com")
    private String email;

    /** The educational level code. */
    @Schema(description = "Holder's educational level", example = "2")
    private Integer educationalLevelCode;

    /** The occupation code. */
    @Schema(description = "Occupation type code", example = "2")
    private Integer occupationCode;

    /** The already customer. */
    @Schema(description = "Already customer flag", example = "true")
    private Boolean alreadyCustomer;

    /** The precon gn id. */
    @Schema(description = "Identifier of the pre-contractual in filenet associated with the consulted holder.",
            example = "80f9e384a98a4ace908928f2ce415308")
    private String preconGnId;

    /** The precon signed. */
    @Schema(description = "Indicates whether the document has been signed.", example = "true")
    private Boolean preconSigned;

    /** The precon add exp sign. */
    @Schema(description = "Indicates whether the document has been add to sign expedient", example = "true")
    private Boolean preconAddExpSign;

    /** The commissions gn id. */
    @Schema(description = "Identifier of the commissions in filenet associated with the consulted holder.",
            example = "80f9e384a98a4ace908928f2ce415308")
    private String commissionsGnId;

    /** The commissions signed. */
    @Schema(description = "Indicates whether the document has been signed.", example = "true")
    private Boolean commissionsSigned;

    /** The commissions add exp sign. */
    @Schema(description = "Indicates whether the document has been add to sign expedient", example = "true")
    private Boolean commissionsAddExpSign;

    /** The precon add exp read sign. */
    @Schema(description = "Indicates whether the document has been add to sign expedient as read", example = "true")
    private Boolean preconAddExpReadSign;

    /** The commissions add read exp sign. */
    @Schema(description = "Indicates whether the document has been add to sign expedient as read", example = "true")
    private Boolean commissionsAddReadExpSign;

}
