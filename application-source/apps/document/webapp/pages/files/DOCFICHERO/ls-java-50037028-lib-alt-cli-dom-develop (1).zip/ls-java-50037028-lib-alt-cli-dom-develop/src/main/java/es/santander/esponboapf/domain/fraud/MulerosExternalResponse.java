package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MulerosExternalResponse.
 */
@NoArgsConstructor
@Data
public class MulerosExternalResponse {

    /** The alert payments. */
    @Schema(description = "Alert payments.", example = "Ocurrió un error al recuperar PAGOS de Lynx.")
    private String alertPayments;

    /** The id. */
    @Schema(description = "Id.", example = "250923-3")
    private String id;

    /** The event aero. */
    @Schema(description = "Event aero.", example = "No existe ningún evento en AERO.")
    private String eventAero;

    /** The alert no monetary. */
    @Schema(description = "Alert no monetary.", example = "Se encontraron NO MONETARIOS con alertas pero ya existen.")
    private String alertNoMonetary;
}
