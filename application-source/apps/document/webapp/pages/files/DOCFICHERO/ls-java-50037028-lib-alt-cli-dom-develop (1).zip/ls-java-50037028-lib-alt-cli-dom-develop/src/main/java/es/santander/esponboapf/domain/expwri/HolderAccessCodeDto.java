package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class HolderAccessCodeDto.
 */
// Constructors
@NoArgsConstructor
@Data
// Schema information
@Schema(description = "To save the access code for a Holder.", 
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"accessCode\":\"12312312\","
        + "\"accessCodeEncrypted\":\"Q+dKd+o3Io0v3YKmoV8bedvJxG1ln7P7wUmv76KheorTj07EyWrby"
        + "bAG3zVogzGXC5FAHrpWYoRsD5nro26S4OKZZca8mKCbDuIisYwqqKzjatXKqZWqUI+oMypxASHQlprSRdyuE1kqUqHOHX3LMDPwmh"
        + "ja7+cElZEv6P3ptD2XXC3UBk6D36Jxpce2QvFH4wbm61U5BaVYQt8F4logz+m3J8lBKB1OPu3gBm8UT3kzDS3DjapQz2W+xqnYvFNL"
        + "dmXoOy/veuKvjy4Selc51dMgBk1aDqBFZW/+TmYP1cSV6KBbbqr0T2I1nFZHw6OHV2d6Gm0hfZygb0KZQe7s4Q==}")
@SuperBuilder
// Holder access code
public class HolderAccessCodeDto {

    /** The Holder Id. */
    // Holder id
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /** The Access Code. */
    // Access code
    @Schema(maxLength = 8, description = "Access code for a Holder", example = "12312312")
    @Size(max = 8)
    @NotBlank
    private String accessCode;
    
    
    /** The Access Code Encrypted. */
    // Access code encrypted
    @Schema( description = "Access code encrypted", example = "Q+dKd+o3Io0v3YKmoV8bedvJxG1ln7P7wUmv76KheorTj07EyWrby"
    		+ "bAG3zVogzGXC5FAHrpWYoRsD5nro26S4OKZZca8mKCbDuIisYwqqKzjatXKqZWqUI+oMypxASHQlprSRdyuE1kqUqHOHX3LMDPwmh"
    		+ "ja7+cElZEv6P3ptD2XXC3UBk6D36Jxpce2QvFH4wbm61U5BaVYQt8F4logz+m3J8lBKB1OPu3gBm8UT3kzDS3DjapQz2W+xqnYvFNL"
    		+ "dmXoOy/veuKvjy4Selc51dMgBk1aDqBFZW/+TmYP1cSV6KBbbqr0T2I1nFZHw6OHV2d6Gm0hfZygb0KZQe7s4Q==")
    private String accessCodeEncrypted;
}
