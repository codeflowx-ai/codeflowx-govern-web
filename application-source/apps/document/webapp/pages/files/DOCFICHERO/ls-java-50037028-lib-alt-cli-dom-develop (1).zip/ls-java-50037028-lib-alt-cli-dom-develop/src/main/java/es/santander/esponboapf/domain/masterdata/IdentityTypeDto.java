package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class IdentityType.
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Identification type identifier", 
example = "{\"identityTypeCode\":1, \"identityTypeName\":\"DNI\"}")
// Identity Type Dto
public class IdentityTypeDto implements Serializable{

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = 1903682954776146278L;

    /**
     * The Identity Type Code.
     *
     * E.g.: 1, 2
     */
    @Schema(description = "Identification type identifier", example = "1")
    private Integer identityTypeCode;

    /**
     * The Identity Type Name.
     *
     * E.g.: 'DNI', 'NIE'
     */
    @Schema(maxLength = 6,
            description = "Description of the type of identification and the data to be displayed on the screen",
            example = "DNI")
    private String identityTypeName;

}
