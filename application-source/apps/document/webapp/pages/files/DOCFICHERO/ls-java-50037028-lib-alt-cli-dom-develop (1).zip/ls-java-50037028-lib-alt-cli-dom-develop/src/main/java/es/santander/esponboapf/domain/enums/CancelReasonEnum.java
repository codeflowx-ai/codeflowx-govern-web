package es.santander.esponboapf.domain.enums;

import lombok.Getter;

/**
 * The Enum CancelReasonEnum.
 */
@Getter
public enum CancelReasonEnum {

    /** The code validation 001. */
    CODE_VALIDATION_001("CSV001", 5, "Ya tienes expediente en curso"),

    /** The code validation 003. */
    CODE_VALIDATION_003("CSV003" , 2, "Titular menor de edad"),

    /** The holder volunter. */
    HOLDER_VOLUNTER("7" , 7, "Voluntario Cliente"),

    /** The other. */
    OTHER(null , 18, "KO en validaciones de cliente"),
   
    ;

    /** The code validation. */
    private String codeValidation;
    
    /** The cancel reason code. */
    private Integer cancelReasonCode;

    /** The cancel reason text. */
    private String cancelReasonText;

    /**
     * Instantiates a new cancel reason enum.
     *
     * @param codeValidation the code validation
     * @param cancelReasonCode the cancel reason code
     * @param cancelReasonText the cancel reason text
     */
    CancelReasonEnum(String codeValidation, Integer cancelReasonCode, String cancelReasonText) {
        this.codeValidation = codeValidation;
        this.cancelReasonCode = cancelReasonCode;
        this.cancelReasonText = cancelReasonText;
    }

    /**
     * Gets the value.
     *
     * @param codeValidation the code validation
     * @return the value
     */
    public static CancelReasonEnum getValue(String codeValidation) {
        for (CancelReasonEnum type : CancelReasonEnum.values()) {
            if (null != type.getCodeValidation() && type.getCodeValidation().equals(codeValidation)) {
                return type;
            }
        }
        return OTHER;
    }
}
