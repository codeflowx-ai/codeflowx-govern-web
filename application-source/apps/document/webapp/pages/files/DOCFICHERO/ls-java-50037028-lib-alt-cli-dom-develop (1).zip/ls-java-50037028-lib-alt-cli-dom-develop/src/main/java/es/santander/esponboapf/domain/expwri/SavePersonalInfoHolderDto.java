package es.santander.esponboapf.domain.expwri;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import es.santander.esponboapf.domain.util.LocalDateDeserializer;
import es.santander.esponboapf.domain.util.LocalDateSerializer;
import es.santander.esponboapf.domain.validation.annotations.IdDocumentNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.util.UUID;

/**
 * The Class SavePersonalInfoHolderDto.
 * <p>
 * Information related to a holder who is on the process of the digital onboarding.
 */
@NoArgsConstructor
@Data
@Schema(description = "Holder's personal information.")
public class SavePersonalInfoHolderDto {

    // datos personales asociados al titular
    // que realiza el onboarding digital

    /**
     * The holder id.
     * <p>
     * Holder's identifier.
     */
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /**
     * The PRIORITY.
     * <p>
     * Holder's priority. '1' for main. Other numbers for subsequent ones.
     */
    @Schema(maxLength = 1,
            description = "Order of holders, e.g '1' is the main holder, '2' is the second holder",
            example = "1")
    @NotBlank
    @Size(max = 1)
    @Pattern(regexp = "[0-9]{1}")
    private String priority;

    /**
     * The Ocr data changed.
     */
    @Schema(description = "Field to indicate if the OCR data has been changed by the user", example = "true")
    private Boolean ocrDataChanged;

    /**
     * The name.
     * <p>
     * Holder's name.
     */
    @Schema(maxLength = 20, description = "Holder's name",
            example = "Elena")
    @NotBlank
    @Pattern(regexp = "^[a-zA-ZÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðñòóôõöùúûüýÿ\\- ]{2,20}$")
    private String name;

    /**
     * The surname 1.
     * <p>
     * Holder's first surname.
     */
    @Schema(maxLength = 26, description = "Holder's first or only surname",
            example = "Nito")
    @NotBlank
    @Pattern(regexp = "^[a-zA-ZÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðñòóôõöùúûüýÿ\\- ]{2,26}$")
    private String surname1;

    /**
     * The surname 2.
     * <p>
     * Holder's second surname.
     */
    @Schema(maxLength = 26, description = "Holder's second surname",
            example = "Del Bosque")
    @Pattern(regexp = "^[a-zA-ZÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðñòóôõöùúûüýÿ\\- ]{2,26}$|^$")
    private String surname2;

    /**
     * The identity type code.
     * <p>
     * The holder's identity type code. '1' - 'NIF', '2' - 'NIE'
     */
    @Schema(description = "Identifier type code", example = "1",
            allowableValues = { "1 - NIF", "2 - NIE" })
    @NotNull
    @Min(1)
    private Integer identityTypeCode;

    /**
     * The indentity number.
     * <p>
     * The holder's identity number.
     */
    @Schema(maxLength = 9, description = "Holder's identity document number",
            example = "L1234567L")
    @NotBlank
    @IdDocumentNumber
    private String identityNumber;

    /**
     * The birth date.
     * <p>
     * The holder's birth date.
     */
    @Schema(description = "Holder's birthdate (dd/MM/yyyy)", example = "07/07/1975")
    @NotNull
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate birthDate;

    /**
     * The sex.
     * <p>
     * The holder's sex (M/F).
     */
    @Schema(maxLength = 1, description = "Holder's sex", example = "F", allowableValues = { "M", "F" })
    @Size(max = 1)
    @NotBlank
    @Pattern(regexp = "^[MF]$")
    private String sex;

    /**
     * The birth city.
     * <p>
     * The holder's birth city.
     */
    @Schema(maxLength = 60, description = "Holder's city of birth", example = "Cachorrilla")
    @Size(max = 60)
    @NotBlank
    private String birthCity;

    /**
     * The birth province code.
     */
    @Schema(maxLength = 2, description = "Holder's birth province code", example = "28")
    @Size(max = 2)
    private String birthProvinceCode;

    /**
     * The birth province.
     */
    @Schema(maxLength = 2, description = "Holder's birth province name", example = "MADRID")
    private String birthProvince;

    /**
     * The birth country.
     * <p>
     * The holder's birth country code. E.g.: 'ES'.
     */
    @Schema(maxLength = 2, description = "Holder's country of birth code", example = "ES")
    @Size(max = 2)
    @NotBlank
    private String birthCountry;

    /**
     * The nationality.
     * <p>
     * The holder's nationality code. E.g.: 'ES'
     */
    @Schema(maxLength = 2, description = "Holder's nationality code", example = "ES")
    @Size(max = 2)
    @NotBlank
    private String nationality;

    /**
     * The preferred language.
     * <p>
     * The holder's prefered language code. E.g.: 'ES'
     */
    @Schema(maxLength = 2, description = "Holder's preferred language", example = "ES")
    @Size(max = 2)
    private String preferredLanguage;

}
