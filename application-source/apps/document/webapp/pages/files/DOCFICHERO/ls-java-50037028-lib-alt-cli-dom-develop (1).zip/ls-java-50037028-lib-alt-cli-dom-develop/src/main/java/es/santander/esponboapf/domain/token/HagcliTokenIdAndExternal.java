package es.santander.esponboapf.domain.token;

import java.util.Optional;
import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class HagcliTokenIdAndExternal.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class HagcliTokenIdAndExternal extends HagcliTokenIdentifier {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8851510911287260389L;

    /** The external dossier id. */
    // Dossier id
    @Schema(maxLength = 100, description = "External identifier.",
            example = "70fd7423-5759-447b-a92f-6e88f514cc89")
    private UUID externalDossierId;

    /** The campaign code. */
    @Schema(description = "Campaign chosen by the holder to be contracted", example = "221")
    private Integer campaignCode;

    /**
     * Instantiates a new hagcli token id and external.
     *
     * @param dossierId         the dossier id
     * @param holderId          the holder id
     * @param externalDossierId the external dossier id
     * @param campaignCode      the campaign code
     */
    public HagcliTokenIdAndExternal(String dossierId, String holderId, String externalDossierId, Integer campaignCode) {
        super(Optional.ofNullable(dossierId).map(UUID::fromString).orElse(null),
                Optional.ofNullable(holderId).map(UUID::fromString).orElse(null));
        this.externalDossierId = Optional.ofNullable(externalDossierId).map(UUID::fromString).orElse(null);
        this.campaignCode = campaignCode;
    }
}
