package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new step holder response.
 */
// Constructors
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
// Schema info
@Schema(description = "Information about REC documentation from a holder", example = "{\"result\":true}")
// Rec response
public class RecResponse {

    /**
     * The Result.
     */
    // Result
    @Schema(description = "Result of the operation, True: all documents REC, "
            + "False: still some document pending to move REC", example = "true")
    private Boolean result;

}
