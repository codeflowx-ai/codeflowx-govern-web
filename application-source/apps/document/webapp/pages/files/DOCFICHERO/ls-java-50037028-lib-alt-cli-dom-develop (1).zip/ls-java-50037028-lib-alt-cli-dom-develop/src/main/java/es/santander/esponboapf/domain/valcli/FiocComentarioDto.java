package es.santander.esponboapf.domain.valcli;

import javax.validation.constraints.Pattern;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FiocComentarioRequest.
 *
 * Fioc comment information
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Fioc comment information", 
example = "{\"idCom\":\"001\",\"comentario\":\"test\"}")
public class FiocComentarioDto {

    /**
     * The id com.
     *
     * Fioc comment id
     * E.g.: '001'
     */
    @Schema(maxLength = 3, description = "Fioc comment id", example = "001")
    @Pattern(regexp = "^[0-9]{3}$")
    private String idCom;

    /**
     * The comentario.
     *
     * Fioc comment value
     * E.g.: 'test'
     */
    @Schema(maxLength = 200, description = "Fioc comment value", example = "test")
    @XssValid
    private String comentario;

}
