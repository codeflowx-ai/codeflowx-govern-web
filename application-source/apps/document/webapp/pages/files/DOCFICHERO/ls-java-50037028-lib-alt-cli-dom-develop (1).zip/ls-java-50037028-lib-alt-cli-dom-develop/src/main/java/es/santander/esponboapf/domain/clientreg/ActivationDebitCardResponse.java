package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activation debit card response.
 */
// Constructors
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Output object activation debit card response", 
            example = "{\"numTarjeta\": \"5489010000022739\"}")
// Activation debit card response
public class ActivationDebitCardResponse {

    /** The numTarjeta. */
    // Num tarjeta
    @Schema(description = "card number indicator", example = "5489010000022739")
    private String numTarjeta;

}
