package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new bdp customer response dto.
 */
@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
// Bdp customer response dto
public class BdpCustomerResponseDto {

    /** The document type. */
    // Document type
    private String documentType;

    /** The document code. */
    // Document code
    private String documentCode;

}
