package es.santander.esponboapf.domain.expread;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.LocalDateTimeDeserializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class IncomingTransferInfoDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IncomingTransferInfoDto {

    /** The state process account generation. */
    @Schema(description = "Indicates the status of the account generation process.", example = "P")
    private String stateProcessAccountGeneration;

    /** The dossier id. */
    @Schema(description = "Identify dossier", example = "cfeb56c7-3e99-4d4f-8f57-278daac4b4fe")
    private String dossierId;

    /** The dossier code. */
    @Schema(description = "Dossier code", example = "6584")
    private Long dossierCode;

    /** The iban. */
    @Schema(description = "iban account indicator", example = "ES2600492594602515000446")
    private String iban;

    /** The mobile holder. */
    @Schema(description = "Phone number", example = "686124154")
    private String mobileHolder;

    /** The date register dossier. */
    @Schema(description = "The dossier's register date", example = "18/11/2021")
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDateTime dateRegisterDossier;

    /** The state step documentation. */
    @Schema(description = "Status of the identification step", example = "R")
    private String stateStepDocumentation;

    /** The state process account blocking. */
    @Schema(description = "Indicates the status of the account blocking.", example = "P")
    private String stateProcessAccountBlocking;

    /** The substate dossier. */
    @Schema(description = "Substate dossier", example = "8")
    private Integer substateDossier;
}
