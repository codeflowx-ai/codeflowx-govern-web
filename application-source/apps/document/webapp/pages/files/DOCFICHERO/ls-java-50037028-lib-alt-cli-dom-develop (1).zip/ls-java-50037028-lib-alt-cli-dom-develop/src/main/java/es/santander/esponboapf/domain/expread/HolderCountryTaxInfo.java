package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Instantiates a new holder country tax info.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class HolderCountryTaxInfo {

    /**
     * The country tax.
     */
    @Schema(description = "country tax for the curret holder", example = "FR")
    private String countryTax;

    /**
     * The tin.
     */
    @Schema(description = "Represents the nominal interest", example = "1234 1234 1234 12345674820")
    private String tin;

    /**
     * The tax reason.
     */
    @Schema(description = "code for the tax reason", example = "R")
    private String taxReason;

    /**
     * The tax reason description.
     */
    @Schema(description = "description for the tax reason", example = "Residencia")
    private String taxReasonDescription;
}
