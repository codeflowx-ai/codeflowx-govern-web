package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StepAsideDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Campagin aside information", 
example = "{\"stepCode\":\"1\",\"asideName\":\"Datos personales\",\"order\":1}")
public class StepAsideDto implements Serializable {


    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2314352274354667679L;


    /** The step code. */
    // StepCode
    @Schema(description = "Holder's step code", example = "2")
    private Integer stepCode;
    
    /** The aside name. */
    // AsideName
    @Schema(description = "Aside name",
            example = "Datos personales")
    private String asideName;

    /** The order. */
    // Order
    @Schema(description = "Order of the aside",
            example = "1")
    private Integer order;
 
}
