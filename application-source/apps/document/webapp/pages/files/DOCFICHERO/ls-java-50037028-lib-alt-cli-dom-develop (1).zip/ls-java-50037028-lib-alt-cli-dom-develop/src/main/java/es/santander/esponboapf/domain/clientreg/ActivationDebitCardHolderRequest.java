package es.santander.esponboapf.domain.clientreg;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ActivationDebitCardHolderRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Input object activation debit card request with holder information")
public class ActivationDebitCardHolderRequest {

    /** The personType. */
    // Person type
    @NotNull
    @Pattern(regexp = "[a-zA-Z]*")
    @Schema(description = "person type indicator", example = "F")
    private String personType;

    /** The personCode. */
    // Person code
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "person code indicator", example = "12896587")
    private String personCode;

    /** The numDomicilio. */
    // Num domicilio
    @NotNull
    @XssValid
    @Schema(description = "number address indicator", example = "1")
    private String numDomicilio;

    /** The fullNameHolder. */
    // Holder full name
    @NotNull
    @XssValid
    @Schema(description = "full name holder indicator", example = "Beatriz Pascual Marín")
    private String fullNameHolder;

    /** The priority. */
    // The priority
    @NotNull
    @Pattern(regexp = "^[0-9]$")
    @Schema(description = "holder priority", example = "1")
    private String priority;

    /** The numDispositivo. */
    // Num dispositivo
    @NotNull
    @XssValid
    @Schema(description = "number device indicator", example = "3")
    private String numDispositivo;

}
