package es.santander.esponboapf.domain.expwri;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new save tax information holder dto.
 */

@NoArgsConstructor
@Data
@Schema(description = "Tax information for the current holder.")
// Save tax information holder data object
public class SaveTaxInformationHolderDto {

    /** The holder id. */
    // Holder id
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /** The has obligations abroad. */
    // Has obligations abroad flag
    @Schema( description = "Flag to indicate wether the holder has tax obligations outside Spain.",
            example = "true")
    private Boolean hasObligationsAbroad;

    /** The is on own behalf. */
    // Is on own behalf flag
    @Schema( description = "Flag to indicate the holder is acting on his own behalf.", example = "true")
    private Boolean isOnOwnBehalf;

    /** The has public task. */
    @Schema( description = "Flag to indicate the holder has public tasks", example = "true")
    private Boolean hasPublicTask;

    /** The income range id. */
    // Income range id
    @Schema(description = "number that identifies a range of income", example = "1")
    private Integer incomeRangeId;

    /** The foreign civil service. */
    // Foreign civil service
    @Schema(maxLength = 100, description = "description of a public task outside Spain", example = "embajador")
    @XssValid
    @Size(max = 100)
    private String foreignCivilService;

    /** The Spanish civil service. */
    // Spanish civil service
    @Schema(maxLength = 100, description = "description of a public task in Spain", example = "político")
    @XssValid
    @Size(max = 100)
    private String spanishCivilService;

    /** The source wealths. */
    // Source wealth list
    @Schema(description = "List of source wealth codes.", example = "5")
    private List<Integer> sourceWealths;

    /** The other source wealth. */
    // Other source wealth
    @Schema(maxLength = 250, description = "Other source of wealth.", example = "-----")
    @XssValid
    private String otherSourceWealth;

    /** The source incomes. */
    // Source income list
    @Schema(description = "List of source income codes.", example = "4")
    private List<Integer> sourceIncomes;

    /** The other source income. */
    // Other source income
    @Schema(maxLength = 250, description = "Other source of income.", example = "-----")
    @XssValid
    private String otherSourceIncome;

    /** The tax obligations. */
    // Tax obligation list
    @Schema(description = "Information about tax obligations outside Spain.")
    @Valid
    private List<TaxObligationCountryDto> taxObligations;

}
