package es.santander.esponboapf.domain.valcli.bdp;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpDataBasicResponse.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BdpDataBasicResponse {

    /** The fecnacim. */
    private List<String> fecnacim;

    /** The fecdec. */
    private List<String> fecdec;

    /** The estcivil. */
    private List<String> estcivil;

    /** The segment. */
    private List<String> segment;

    /** The codpaisn. */
    private List<String> codpaisn;

    /** The provcod. */
    private List<String> provcod;

    /** The nompla 1. */
    private List<String> nompla1;

    /** The codpaire. */
    private List<String> codpaire;

    /** The idemprpp. */
    private List<String> idemprpp;

    /** The codocu. */
    private List<String> codocu;

    /** The tipodoc. */
    private List<String> tipodoc;

    /** The sexo. */
    private List<String> sexo;

    /** The codidio. */
    private List<String> codidio;

    /** The nombre. */
    private List<String> nombre;

    /** The apelldo 1. */
    private List<String> apelldo1;

    /** The partape 1. */
    private List<String> partape1;

    /** The apelldo 2. */
    private List<String> apelldo2;

    /** The partape 2. */
    private List<String> partape2;

    /** The indnivac. */
    private List<String> indnivac;

    /** The carac 2. */
    private List<String> carac2;

    /** The nivestud. */
    private List<String> nivestud;

    /** The indempl. */
    private List<String> indempl;

    /** The codabre. */
    private List<String> codabre;

    /** The cnae 93. */
    private List<String> cnae93;

    /** The swtrabj. */
    private List<String> swtrabj;

    /** The subtipco. */
    private List<String> subtipco;

    /** The destipo. */
    private List<String> destipo;

    /** The idtiptra. */
    private List<String> idtiptra;

    /** The paisnac. */
    private List<String> paisnac;

    /** The nrodom. */
    private List<Integer> nrodom;

    /** The cno. */
    private List<String> cno;

}
