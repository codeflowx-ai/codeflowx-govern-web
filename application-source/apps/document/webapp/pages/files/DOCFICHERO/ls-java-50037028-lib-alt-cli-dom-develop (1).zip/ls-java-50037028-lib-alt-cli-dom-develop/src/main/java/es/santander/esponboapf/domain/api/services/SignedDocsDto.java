package es.santander.esponboapf.domain.api.services;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SignedDocsDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SignedDocsDto {

    /** The codgdoc. */
    private String codgdoc;

    /** The person number doc. */
    private String personNumberDoc;

    /** The type doc. */
    private String typeDoc;

    /** The status. */
    private String status;

    /** The gn id. */
    private String gnId;

    /** The result. */
    private String result;

    /** The indicadores ordofe. */
    private String indicadoresOrdofe;
}
