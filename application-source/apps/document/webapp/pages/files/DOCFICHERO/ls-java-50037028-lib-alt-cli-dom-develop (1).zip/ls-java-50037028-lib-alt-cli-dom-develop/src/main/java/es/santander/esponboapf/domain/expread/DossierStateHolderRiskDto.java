package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierStateHolderRiskDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Data to report the status of the dossier and indicate if the holder has a risk in fioc.",
example = "{\"dossierCode\":63,\"stateDossier\":2,\"holderCode\":10003,\"riskFioc\":\"A1\"}")
public class DossierStateHolderRiskDto {

    /** The dossier code. */
    @Schema(description = "Dossier code", example = "63")
    private Long dossierCode;

    /** The state dossier. */
    @Schema(description = "State dossier", example = "2")
    private Integer stateDossier;

    /** The holder code. */
    @Schema(description = "Holder code", example = "10003")
    private Long holderCode;

    /** The risk fioc. */
    @Schema(description = "Indicate if the holder has a risk in fioc", example = "A1")
    private String riskFioc;

}
