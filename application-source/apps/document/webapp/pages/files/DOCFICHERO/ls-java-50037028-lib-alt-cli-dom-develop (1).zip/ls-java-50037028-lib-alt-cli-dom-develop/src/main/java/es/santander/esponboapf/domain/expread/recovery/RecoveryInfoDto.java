package es.santander.esponboapf.domain.expread.recovery;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Recovery info dto.
 */
//The class RecoveryInfoDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecoveryInfoDto {

    /**
     * The Dossier.
     */
    private RecoveryInfoDossierDto dossier;

    /**
     * The Holder.
     */
    private List<RecoveryInfoHolderDto> holders;

}
