package es.santander.esponboapf.domain.docmanager.pdf;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * FieldData class
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FieldData {

    /** type */
    private String type;
    /** value */
    private String value;
    /** scalePercentQR */
    private Float scalePercentQR;

}
