package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder update email dto.
 */
@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
// HolderUpdateEmailDto
public class HolderUpdateEmailDto {

    /**
     * The Holder id.
     */
    // Holder id
    @NotNull
    @Schema(description = "The holder identifier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private UUID holderId;

    /**
     * The Email.
     */
    // Email
    @Pattern(regexp = "^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$")
    @NotBlank
    @Schema(description = "The new holder email address", example = "example@mail.com")
    private String email;

}
