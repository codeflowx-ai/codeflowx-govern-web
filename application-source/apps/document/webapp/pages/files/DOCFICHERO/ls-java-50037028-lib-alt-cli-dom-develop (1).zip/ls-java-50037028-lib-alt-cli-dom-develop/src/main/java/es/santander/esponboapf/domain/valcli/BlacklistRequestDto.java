package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Blacklist request dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BlacklistRequestDto {

    /**
     * The Holder name.
     */
    @Schema(description = "Holder name.", example = "Nombre")
    private String holderName;

    /**
     * The Nacionality.
     */
    @Schema(description = "Holder nacionality.", example = "ES")
    private String nacionality;

    /**
     * The Birth date.
     */
    @Schema(description = "Holder birthdate.", example = "dd/MM/yyyy")
    private String birthDate;

    /**
     * The Identity type code.
     */
    @Schema(description = "Holder identity type.", example = "1")
    private String identityTypeCode;

    /**
     * The Identity number.
     */
    @Schema(description = "Holder identity number.", example = "11111111H")
    private String identityNumber;

    /**
     * The Residence.
     */
    @Schema(description = "Holder residence.", example = "ES")
    private String residence;

}
