package es.santander.esponboapf.domain.fraud;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RequestCheckOwnerDto.
 */
//The class CheckOwnerRequestDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CheckOwnerRequestDto {

    /** The holder id. */
    //holderId
    @Schema( description = "Unique holder identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /** The beneficiary iban. */
    //beneficiaryIban
    @Schema(description = "holder's IBAN account.", example = "ES1821007837171300060477")
    @Pattern(regexp = "^ES[0-9]{22}$")
    private String beneficiaryIban;

}
