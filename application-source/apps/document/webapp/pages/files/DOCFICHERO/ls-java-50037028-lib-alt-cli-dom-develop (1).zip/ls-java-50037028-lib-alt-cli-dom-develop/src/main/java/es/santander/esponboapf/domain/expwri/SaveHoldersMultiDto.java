/**
 * Self.
 *
 * @return the save holders multi dto. save holders multi dto builder impl
 */
package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import es.santander.esponboapf.domain.validation.annotations.IdDocumentNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class Dossier.
 */

/**
 * Instantiates a new save holders multi dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new save holders multi dto.
 *
 * @param priority the priority
 * @param identityTypeCode the identity type code
 * @param identityNumber the identity number
 * @param ht the ht
 */
@AllArgsConstructor

/**
 * Builds the.
 *
 * @return the save holders multi dto
 */
@SuperBuilder

/**
 * To string.
 *
 * @return the java.lang. string
 */
@Data

/**
 * Hash code.
 *
 * @return the int
 */
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Basic information about a holder when multi holder dossier",
example = "{\"priority\":\"2\", \"countryCode\":\"ES\", \"cellPhone\":\"666666666\", "
        + "\"email\":\"eddie.the.great@some.com\", \"identityTypeCode\":1,\"identityNumber\":\"66666666T\","
        + "\"holdertype\":1}")
public class SaveHoldersMultiDto extends HolderContactDto {

    /**
     * The priority.
     *
     */
    @Schema(maxLength = 1, description = "Order of holders, e.g '2' is the second holder",
            example = "2")
    @NotBlank
    @Size(max = 1)
    @Pattern(regexp = "[2-5]{1}")
    private String priority;

    /** The identity type code. */
    @Schema( description = "Identifier type code", example = "1",
            allowableValues = { "1 - NIF", "2 - NIE" })
    @NotNull
    @Min(1)
    private Integer identityTypeCode;

    /**
     * The indentity number.
     *
     * The holder's identity number.
     */
    @Schema(maxLength = 9, description = "Holder's identity document number",
            example = "66666666T")
    @NotBlank
    @IdDocumentNumber
    private String identityNumber;

    /** The holder type. */
    @Schema( description = "What kind of client relation has with the entity", example = "1",
            allowableValues = { "1 - No Client", "2 - Inactive", "3 - Active" })
    @NotNull
    @Range(min = 1, max = 3)
    private Integer ht;

}
