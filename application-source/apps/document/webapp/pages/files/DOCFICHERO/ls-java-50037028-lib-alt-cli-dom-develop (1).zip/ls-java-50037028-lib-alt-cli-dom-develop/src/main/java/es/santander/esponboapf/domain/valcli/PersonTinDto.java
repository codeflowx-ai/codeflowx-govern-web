package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PersonTinDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PersonTinDto {

    /** The foreign tax. */
    private ForeignTaxTinDto foreignTax;
}
