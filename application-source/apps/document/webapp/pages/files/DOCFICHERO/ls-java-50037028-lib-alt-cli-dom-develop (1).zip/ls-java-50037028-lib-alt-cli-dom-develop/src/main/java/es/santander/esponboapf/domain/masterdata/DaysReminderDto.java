package es.santander.esponboapf.domain.masterdata;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Days reminder dto.
 */
//The class DaysReminderDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DaysReminderDto {

    /**
     * The Days.
     */
    private Integer days;

    /**
     * The Communication code.
     */
    private Integer communicationCode;

}
