package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The type Holder video identification dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
// Holder video identification data dto
public class ValidateVideoIdentificationDto extends ValidateIdentificationRequest {

    /**
     * The Holder id.
     */
    @Schema(description = "UUID identifying an holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /**
     * The Holder code.
     */
    @Schema(description = "Holder code number", example = "643")
    private Long holderCode;

    /**
     * The Email Type.
     */
    @Schema(description = "Email type for send to holder", example = "4")
    private Integer emailType;

    /**
     * The Doc State Code.
     */
    @Schema(description = "Document State Code", example = "REC")
    private String docStateCode;

    /**
     * The Doc State Code.
     */
    @Schema(description = "Dossier State Code", example = "4")
    private Integer dossierStateCode;

    /**
     * The person type.
     */
    @Schema(description = "The person type", example = "F")
    private String personType;

    /**
     * The person code.
     */
    @Schema(description = "The person code", example = "95875625")
    private String personCode;

    /**
     * The identityType.
     */
    @Schema(description = "The identity type", example = "1")
    private Integer identityType;

    /**
     * The person code.
     */
    @Schema(description = "The files names on S3", example = "DNI_F124668366_A.jpg,DNI_F124668366_R.jpg")
    private String filenameS3;

	/**
	 * Creates the validate video identification dto.
	 *
	 * @param request the request
	 */
    // Constructor
    public void createValidateVideoIdentificationDto(ValidateIdentificationRequest request) {
        this.setDocIdentidad(request.getDocIdentidad());
        this.setExpedienteId(request.getExpedienteId());
        this.setEstadoVC(request.getEstadoVC());
        this.setAnverso(request.getAnverso());
        this.setReverso(request.getReverso());
    }
}
