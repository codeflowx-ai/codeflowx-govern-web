package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ForeignTaxTinDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ForeignTaxTinDto {

    /** The country. */
    private CountryTinDto country;

    /** The document. */
    private DocumentTinDto document;

}
