package es.santander.esponboapf.domain.corresp;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Otp sign request.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@Schema(description = "Mandatory information to be able to generate an sign OTP key.",
        example = "\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\", "
                + "\"fullPhoneNumber\":\"0034666666666\"")
// OTP sign request
// OTP
public class OTPSignRequest extends OTPRequest {

    /**
     * The Holder name.
     */
    // Holder name
    @Schema(description = "Holder name, optional parameter that will be informed in the OTP message if filled",
            example = "Juan")
    @XssValid
    private String holderName;

}
