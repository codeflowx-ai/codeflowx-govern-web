package es.santander.esponboapf.domain.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The Enum HolderStepEnum.
 */
public enum HolderStepEnum {

    /**
     * The personal details.
     * Value 1.
     */
    PERSONAL_DETAILS(1),

    /**
     * The identification.
     * Value 2.
     */
    IDENTIFICATION(2),

    /**
     * The legal and regulatory details.
     * Value 3.
     */
    LEGAL_AND_REGULATORY_DETAILS(3),

    /**
     * The contract signing.
     * Value 4.
     */
    CONTRACT_SIGNING(4),

    /**
     * The access key. Value 5.
     */
    ACCESS_KEY(5),

    /**
     * The document attachment.
     * Value 6.
     */
    DOCUMENT_ATTACHMENT(6),

    /**
     * Adding multiholder holder step.
     */
    ADDING_MULTIHOLDER(7),

    /**
     * Financial analysis holder step.
     */
    FINANCIAL_ANALYSIS(8);;

    /**
     * The Constant BY_VALUE.
     */
    private static final Map<Integer, HolderStepEnum> BY_VALUE = Arrays.stream(values())
            .collect(Collectors
                    .toUnmodifiableMap(e -> e.value, e -> e));

    /**
     * The label.
     */
    public final int value;

    /**
     * Instantiates a new holder step enum.
     *
     * @param value the value
     */
    HolderStepEnum(int value) {
        this.value = value;
    }

    /**
     * From value.
     *
     * @param value the value
     * @return the dossier state enum
     */
    public static HolderStepEnum fromValue(int value) {
        return BY_VALUE.get(value);
    }

}
