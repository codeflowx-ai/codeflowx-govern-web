package es.santander.esponboapf.domain.mictransferiden.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.StringTrimmerDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TransferDetailPayerResponse
 *
 * The type Transfer detail payer response.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferDetailPayerResponse {

    /** The Name. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String name;

    /** The Address. */
    private TransferDetailPayerAddressResponse address;

}
