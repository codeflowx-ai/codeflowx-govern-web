package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Reject reason dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Campaign chosen in the onboarding process", 
example = "{\"rejectReasonCode\":1,\"rejectReasonName\":\"Documento ilegible\"}")
// Reject Reason object
public class RejectReasonDto  implements Serializable{

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -3545472173781452275L;

    /**
     * The reject reason code.
     */
    // Reject reason code
    @Schema(description = "Number identifying a reject reason", example = "1")
    private Integer rejectReasonCode;

    /**
     * The reject reason name.
     */
    // Reject reason name
    @Schema(description = "Reject reason description", example = "Documento ilegible")
    private String rejectReasonName;

}
