package es.santander.esponboapf.domain.valcli.account;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class BalancesAccountDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// BalancesAccountDto
public class BalancesAccountDto {

    /** The amount. */
    // Amount
    @Schema(description = "Amount from an account", example = "123")
    private Long amount;

}
