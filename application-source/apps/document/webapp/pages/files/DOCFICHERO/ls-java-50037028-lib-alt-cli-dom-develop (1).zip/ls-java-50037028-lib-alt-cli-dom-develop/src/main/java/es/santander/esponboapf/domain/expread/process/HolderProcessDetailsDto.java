package es.santander.esponboapf.domain.expread.process;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder process details dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderProcessDetailsDto {

    /**
     * The Holder code.
     */
    private Long holderCode;

    /**
     * The Priority.
     */
    private String priority;

    /**
     * The Identity number.
     */
    private String identityNumber;

    /**
     * The Person code.
     */
    private String personCode;
    
    /** The signed. */
    private Boolean signed;
    
    /** The access code completed. */
    private Boolean accessCodeCompleted;

    /**
     * The Cmc number.
     */
    private String cmcNumber;

    /**
     * The Fioc.
     */
    private String fioc;

    /**
     * The Processes.
     */
    private List<ProcessDetailsDto> processes;

}
