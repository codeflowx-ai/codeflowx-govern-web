package es.santander.esponboapf.domain.expwri;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SaveDataAgentDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SaveDataAgentDto {

    /** The dossier code. */
    private Long dossierCode;

    /** The identity number agent. */
    private String identityNumberAgent;

    /** The full name agent. */
    private String fullNameAgent;

}
