package es.santander.esponboapf.domain.fraud;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RulesDossierResponse.
 *
 * RulesDossierResponse.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RulesDossierResponse {

    /** The description rules. */
    private List<String> descriptionRules;

    /** The status. */
    private List<StatusDto> status;

}
