package es.santander.esponboapf.domain.clientreg;

import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new holder activation dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information about a holder necessary to activate the account.")
public class HolderActivationDto {

    /** The holder id. */
    @Schema(description = "Unique uuid identifier of the holder.",
            example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private UUID holderId;

    /** The holder code. */
    @Schema(description = "Holder code", example = "505")
    private Long holderCode;

    /** The priority. */
    @Schema(description = "Holder order", example = "1")
    private Integer priority;

    /** The person type. */
    @Schema(description = "Holder type person", example = "F")
    private String personType;

    /** The person code. */
    @Schema(description = "Person code of the holder in bdp", example = "1234567")
    private String personCode;

    /** The document type. */
    @Schema(description = "Document type", example = "N")
    private String documentType;

    /** The document code. */
    @Schema(description = "Document code", example = "56985123")
    private String documentCode;

    /** The full name holder. */
    @Schema(description = "Full name holder", example = "Nombre Apellido1 Apellido2")
    private String fullNameHolder;

    /** The num domicilio. */
    @Schema(description = "It is the address number of the client corresponding in BPD to NRODOMI.", example = "01")
    private String numDomicilio;

    /** The mobile phone. */
    @Schema(description = "Number mobile", example = "600123123")
    private String mobilePhone;

    /** The customer bdp exist. */
    @Schema(description = "Indicator customer BDP exist", example = "false")
    private Boolean customerBdpExist;

    /** The access code. */
    @Schema(description = "Holder access code", example = "12345678")
    private String accessCode;

    /** The prefix. */
    @Schema(description = "Prefix", example = "0034")
    private String prefix;

    /** The customer id. */
    @Schema(description = "Customer id", example = "F12345678")
    private String customerId;

    /** The result update BDP. */
    @Schema(description = "Result update bdp", example = "true")
    private boolean resultUpdateBDP;

    @Schema(description = "It is the device number of client", example = "6")
    private String numDispositivo;

    /** The name. */
    @Schema(description = "Name", example = "Luis")
    private String name;

    /** The surname 1. */
    @Schema(description = "First surname", example = "Perez")
    private String surname1;

    /** The surname 2. */
    @Schema(description = "Second surname", example = "Martinez")
    private String surname2;

    /** The email. */
    @Schema(description = "Customer id", example = "email@email.com")
    private String email;

    /** The type client. */
    @Schema(description = "Type client", example = "1")
    private Integer typeClient;

    /** The risk. */
    @Schema(description = "Risk level", example = "A1")
    private String risk;

    /** The state control process block. */
    @Schema(description = "State control process block account", example = "R")
    private String stateControlProcessBlock;

    /** The country code. */
    @Schema(description = "Country code", example = "ES")
    private String countryCode;
}
