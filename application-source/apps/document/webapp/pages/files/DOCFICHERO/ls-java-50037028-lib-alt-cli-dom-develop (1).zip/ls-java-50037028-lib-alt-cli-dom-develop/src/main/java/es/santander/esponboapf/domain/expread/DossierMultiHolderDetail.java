package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class DossierMultiHolderDetail.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Response for service file net data")
public class DossierMultiHolderDetail {

    /** The is multi holder. */
    // IsMultiHolder
    @Schema(description = "Indicate if the dossier is multiholder.", example = "true")
    private Boolean isMultiHolder;

    /** The completed step add holder. */
    // CompletedStepAddHolder
    @Schema(description = "Indicate if the principal holder has completed step add holder.", example = "true")
    private Boolean completedStepAddHolder;

    /** The all holders complete step 1 and 3. */
    // AllHoldersCompletedStep1And3
    @Schema(description = "Indicate if all the holders from a dossier have the steps 1 and 3 completed",
            example = "false")
    private Boolean allHoldersCompleteStep1And3;

}
