package es.santander.esponboapf.domain.expread.search;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * The type Dossier search dto.
 */
@Data
// Dossier result data
public class DossierSearchDto {

    /**
     * The Dossier code.
     */
    @Schema(description = "Dossier unique identifier", example = "10")
    private Long dossierCode;

    /**
     * The Dossier id.
     */
    @Schema(description = "Dossier unique identifier", example = "b3a3c411-da89-4613-b4d8-b9bc8b54b927")
    private String dossierId;

    /**
     * The Campaign name.
     */
    @Schema(description = "The campaign name", example = "Santander One")
    private String campaignName;

    /**
     * The Holder identity number.
     */
    @Schema(description = "The holder's identity number", example = "11111111H")
    private String holderIdentityNumber;

    /**
     * The Holder name.
     */
    @Schema(description = "The holder full name", example = "Jose Perez Perez")
    private String holderName;

    /**
     * The State.
     */
    @Schema(description = "The dossier's state", example = "En Activación")
    private String state;

    /**
     * The Register date.
     */
    @Schema(description = "The dossier's register date", example = "18/11/2021")
    private String registerDate;

    /**
     * The State change date.
     */
    @Schema(description = "The last state change date", example = "18/11/2021")
    private String stateChangeDate;

    /**
     * The Access.
     */
    @Schema(description = "If the user has access to the dossier", example = "true")
    private Boolean access;

}
