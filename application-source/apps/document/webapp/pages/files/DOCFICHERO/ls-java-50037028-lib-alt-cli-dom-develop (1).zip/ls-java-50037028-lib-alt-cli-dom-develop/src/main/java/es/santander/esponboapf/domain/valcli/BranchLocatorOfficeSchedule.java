package es.santander.esponboapf.domain.valcli;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * BranchLocatorOfficeSchedule
 *
 * The type Branch locator office schedule.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchLocatorOfficeSchedule {

    /** The Working day. */
    private Map<String, List<String>> workingDay;

}
