package es.santander.esponboapf.domain.docmanager.s3;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Document s 3 response.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HolderDocumentS3Response {

    /**
     * The Document code.
     */
    // Document code
    @Schema(description = "Document identifier", example = "1")
    private Integer documentCode;

    /**
     * The document base 64
     */
    // Document in base 64
    @Schema(description = "Document data", example = "BASE64 encoded file")
    private String documentBase64;

    /**
     * The Filename.
     */
    // File name
    @Schema(description = "File name", example = "DNI_F12345678_A.jpg")
    private String documentFileName;

    /**
     * The Content type.
     */
    // Content type
    @Schema(description = "Content type of the file", example = "application/jpeg")
    private String documentContentType;

}
