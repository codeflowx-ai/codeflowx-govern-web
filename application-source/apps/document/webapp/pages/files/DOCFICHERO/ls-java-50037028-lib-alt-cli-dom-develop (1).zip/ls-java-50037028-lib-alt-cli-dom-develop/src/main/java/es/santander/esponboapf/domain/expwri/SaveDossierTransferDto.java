package es.santander.esponboapf.domain.expwri;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Save dossier transfer dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SaveDossierTransferDto {

    /**
     * The Dossier code.
     */
    private Long dossierCode;

    /**
     * The Reference.
     */
    private String reference;

    /**
     * The Application code.
     */
    private String applicationCode;

    /**
     * The Transfer state code.
     */
    private String transferStateCode;

    /**
     * The Payer name.
     */
    private String payerName;

    /**
     * The Payer country.
     */
    private String payerCountry;

    /**
     * The Beneficiary name.
     */
    private String beneficiaryName;

    /**
     * The Person code.
     */
    private String personCode;

    /**
     * The Beneficiary account.
     */
    private String beneficiaryAccount;

    /**
     * The Payer iban.
     */
    private String payerIban;

    /**
     * The Origin country payment.
     */
    private String originCountryPayment;

    /**
     * The Payment date.
     */
    private String paymentDate;

    /**
     * The Settlement date.
     */
    private String settlementDate;

    /**
     * The Amount.
     */
    private Double amount;

    /**
     * The Currency.
     */
    private String currency;

    /**
     * The Concept.
     */
    private String concept;

    /**
     * The Transfer status.
     */
    private String transferStatus;

    /**
     * The Result fraud.
     */
    private String resultFraud;

    /**
     * Is valid boolean.
     *
     * @return the boolean
     */
    public boolean isValid() {
        return !(StringUtils.isEmpty(this.getPayerIban()) || StringUtils.isEmpty(this.getPayerName())
                || ObjectUtils.anyNull(this.getAmount(), this.getCurrency(), this.getPaymentDate())
                || !ObjectUtils.anyNotNull(this.getPayerCountry(), this.getOriginCountryPayment()));
    }

}
