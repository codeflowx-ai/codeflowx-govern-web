package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type AccessCodeMessage
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
// Access code messaage
public class AccessCodeMessage {

    /**
     * The Error Code
     */
    // Code
    @Schema(description = "Acces code message", example = "AC001, AC002, AC003")
    private String code;

    /**
     * The Error Description
     */
    // Description
    @Schema(description = "Description access code message", 
            example = "Documentation pending and identification pending.")
    private String description;

    /**
     * The Screen Identification Code
     */
    // Screen code
    @Schema(description = "Screen identification code.", example = "765")
    private Long screenCode;

}
