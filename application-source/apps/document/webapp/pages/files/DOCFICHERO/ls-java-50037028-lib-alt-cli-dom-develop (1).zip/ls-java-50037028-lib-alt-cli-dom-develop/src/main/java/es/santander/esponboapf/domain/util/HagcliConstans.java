package es.santander.esponboapf.domain.util;

/**
 * The Class HagcliConstans.
 */
public final class HagcliConstans {

    /** The Constant DATA_TOKEN_HEADER. */
    public static final String DATA_TOKEN_HEADER = "X-Hagcli-Head";

    /**
     * Instantiates a new hagcli constans.
     */
    private HagcliConstans() {
        super();
    }

}
