package es.santander.esponboapf.domain.token;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class TokenBasic. Builder. All type constructor.
 */
// The class TokenBasic
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
public class TokenBasic implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -1315746024189016188L;
    /** The expiration. */
    private Long expiration;
}
