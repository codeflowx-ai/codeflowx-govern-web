package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MaintenanceOfficeDTO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MaintenanceOfficeDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5114395574548991536L;

    /** The office code. */
    @Schema(description = "The unique office identifier", example = "4918")
    private String officeCode;

    /** The address. */
    @Schema(description = "The office address", example = "4918 - FERROL")
    private String address;

}
