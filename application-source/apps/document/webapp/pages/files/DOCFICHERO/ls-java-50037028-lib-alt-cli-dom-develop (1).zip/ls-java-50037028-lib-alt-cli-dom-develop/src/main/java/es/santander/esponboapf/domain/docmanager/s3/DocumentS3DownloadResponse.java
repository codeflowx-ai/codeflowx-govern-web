package es.santander.esponboapf.domain.docmanager.s3;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Document s 3 download response.
 */
//The class DocumentS3DownloadResponse
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentS3DownloadResponse {

    /**
     * The File data.
     */
    //The file data
    @Schema(description = "Document data encoded in base 64", example="dGVzdGV4YW1wbGU=")
    private String documentBase64;

}
