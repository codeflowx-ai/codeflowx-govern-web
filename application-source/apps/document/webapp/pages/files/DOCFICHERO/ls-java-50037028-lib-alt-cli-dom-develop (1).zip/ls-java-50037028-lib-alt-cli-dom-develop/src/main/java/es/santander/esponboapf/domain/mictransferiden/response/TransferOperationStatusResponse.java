package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TransferOperationStatusResponse
 *
 * The type Transfer operation status response.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferOperationStatusResponse {

    /** The Operation company. */
    private String operationCompany;

    /** The Status. */
    private String status;

}
