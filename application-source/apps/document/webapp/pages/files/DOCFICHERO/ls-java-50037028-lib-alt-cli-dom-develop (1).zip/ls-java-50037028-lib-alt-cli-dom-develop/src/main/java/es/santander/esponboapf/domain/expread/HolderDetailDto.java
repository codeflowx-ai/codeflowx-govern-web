package es.santander.esponboapf.domain.expread;

import java.time.LocalDateTime;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.LocalDateTimeDeserializer;
import es.santander.esponboapf.domain.validation.annotations.IdDocumentNumber;
import es.santander.esponboapf.domain.validation.annotations.XssValid;
import es.santander.esponboapf.domain.validation.groups.HolderDetailsGroup;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Holder detail dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder(toBuilder = true)
@Schema(description = "Details of the holder")
// Holder detail
public class HolderDetailDto {

    /**
     * The Holder code.
     */
    // Holder code
    @Schema( description = "Number identifying an holder", example = "341")
    @NotNull
    private Long holderCode;

    /**
     * The Priority.
     */
    // Priority
    @Schema( description = "Number identifying the priority", example = "1")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[0-9]")
    private String priority;

    /**
     * The Name.
     */
    // Name
    @Schema( description = "Name of the holder", example = "Jorge")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @XssValid
    private String name;

    /**
     * The Surname 1.
     */
    // Surname 1
    @Schema( description = "Surname1 of the holder", example = "Garcia")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @XssValid
    private String surname1;

    /**
     * The Surname 2.
     */
    // Surname 2
    @Schema( description = "Surname2 of the holder", example = "Ramirez")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @XssValid
    private String surname2;

    /**
     * The Identity type code.
     */
    // Identity type code
    @Schema( description = "Number identifying type of code", example = "1")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    private Integer identityTypeCode;

    /**
     * The Number identity.
     */
    // Number identity
    @Schema( description = "Document identity number", example = "38268686K")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @IdDocumentNumber
    private String numberIdentity;

    /**
     * The Person type.
     */
    // Person type
    @Schema( description = "Type of person", example = "F")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[F]")
    private String personType;

    /**
     * The Person code.
     */
    // Person code
    @Schema( description = "Person code", example = "56236987")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "^[0-9]{1,20}$")
    private String personCode;

    /**
     * The Gender.
     */
    // Gender
    @Schema( description = "Gender of the holder", example = "F")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[FM]")
    private String gender;

    /**
     * The Country code.
     */
    // Country code
    @Schema(maxLength = 2, description = "Country code retrived from prefixes service call", example = "ES")
    @NotBlank(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "^[A-Z]{2}$")
    private String countryCode;

    /**
     * The Birth city.
     */
    // Birth city
    @Schema( description = "Birth city of the holder", example = "Madrid")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[a-zA-ZÀ-ÿ0-9\\- ]+")
    private String birthCity;

    /**
     * The birth province code.
     */
    // birth province code
    @Schema(description = "Province code of birth", example = "28")
    private String birthProvinceCode;

    /**
     * The birth province name.
     */
    // birth province name
    @Schema(description = "Province name of birth", example = "MADRID")
    private String birthProvince;

    /**
     * The Birth country.
     */
    // Birth country
    @Schema( description = "Birth country of the holder", example = "ES")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "^[A-Z]{2}$")
    private String birthCountry;

    /**
     * The Nacionality.
     */
    // Nacionality
    @Schema( description = "Nacionality of the holder", example = "ES")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "^[A-Z]{2}$")
    private String nacionality;

    /**
     * The Study level code.
     */
    // Study level code
    @Schema( description = "Study level of the holder", example = "2")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    private Integer studyLevelCode;

    /**
     * The Road type code.
     */
    // Road type code
    @Schema( description = "Road type of the holder", example = "CL")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "^[A-Z]{1,3}$")
    private String roadTypeCode;

    /**
     * The Road name.
     */
    // Road name
    @Schema( description = "Road name of the holder", example = "Manuel Aguirre")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @XssValid
    private String roadName;

    /**
     * The Num.
     */
    // Num
    @Schema( description = "Number of the house of the holder", example = "7")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "^[0-9]{1,4}$")
    private String num;

    /**
     * The Addtional info.
     */
    // Additional info
    @Schema( description = "Additional tax residence information", example = "Portal 3 3A")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @XssValid
    private String additionalInfo;

    /**
     * The Postal code.
     */
    // Postal code
    @Schema( description = "Tax residence postal code", example = "28100")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[0-9]{5}")
    private String postalCode;

    /**
     * The City.
     */
    // City
    @Schema( description = "City of residence", example = "Alcobendas")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[a-zA-ZÀ-ÿ0-9\\- ]+")
    private String city;

    /**
     * The Province code.
     */
    // Province code
    @Schema( description = "Province code of residence", example = "28")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[0-9]{2}")
    private String provinceCode;

    /**
     * The Province name.
     */
    // Province name
    @Schema( description = "Province name of residence", example = "Madrid")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[a-zA-ZÀ-ÿ0-9 ]+")
    private String provinceName;

    /**
     * The Movil.
     */
    // Movil
    @Schema( description = "Phone number", example = "686124154")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[0-9]{9}")
    private String movil;

    /**
     * The Email.
     */
    // Email
    @Schema( description = "Email", example = "manuel1r223@gmail.com")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$")
    @Size(max = 100)
    private String email;

    /**
     * The Occupation code.
     */
    // Occupation code
    @Schema( description = "Occupation type code", example = "2")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    private Integer occupationCode;

    /**
     * The Activity code.
     */
    // Activity code
    @Schema( description = "Activity code", example = "2")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    private Integer activityCode;

    /**
     * The Profession code.
     */
    // Profession code
    @Schema( description = "Profession code", example = "X200")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    private Integer professionCode;

    /**
     * The Profession name.
     */
    // Profession name
    @Schema( description = "Profession name", example = "fontanero")
    @NotNull(groups = { HolderDetailsGroup.Update.class })
    @Pattern(regexp = "[a-zA-ZÀ-ÿ0-9\\- ªº]+")
    private String professionName;

    /** The profession. */
    // Profession
    @Schema( description = "Profession", example = "X200")
    @Pattern(regexp = "[a-zA-Z0-9]+")
    private String profession;

    /**
     * The Sector code.
     */
    // Sector code
    @Schema( description = "Sector code", example = "A")
    @Pattern(regexp = "[a-zA-Z]+")
    private String sectorCode;

    /**
     * The Sector name.
     */
    // Sector name
    @Schema( description = "Sector name", example = "AGRICULTURA,GANADERIA, SILVICULTURA Y PESCA")
    @Pattern(regexp = "[a-zA-ZÀ-ÿ0-9 ]+")
    private String sectorName;

    /** The signed */
    // Signed
    @Schema( description = "Holder signed the dossier", example = "true")
    private Boolean signed;

    /** The birth date. */
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy")
    @Schema(description = "Start date to filter", pattern = "dd/MM/yyyy", example = "18/11/1998")
    private LocalDateTime birthDate;

    /** The type client. */
    // type client: 1 no cliente, 2 inactivo, 3 activo
    @Schema(description = "Client type of the account for this campaign", example = "1")
    private Integer typeClient;

    /** The editable address. */
    @Schema(description = "Indicator to know if the address can be editable. "
            + "When the holder already has an F in the DB, it will not be editable.",
            example = "true")
    private Boolean editableAddress;

    /** The holder id. */
    @Schema(description = "UUID identifying an holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /** The promotional code. */
    @Schema(description = "Promotional code", example = "000232-01-19097702")
    private String promotionalCode;

    /** The company name. */
    @Schema(description = "Company name", example = "Plexus")
    private String companyName;
}
