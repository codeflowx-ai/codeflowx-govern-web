package es.santander.esponboapf.domain.valcli.bdp;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class BdpUpdateInfoResponse.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
public class BdpUpdateInfoBBDDResponse {

    /** The birth date. */
    private LocalDateTime birthDate;

    /** The nationality. */
    private String nationality;

    /** The identity number. */
    private String identityNumber;

    /** The identitytype. */
    private String identitytype;

    /** The study level code. */
    private String studyLevelCode;

    /** The occupation type code. */
    private Integer occupationTypeCode;

    /** The status code. */
    private String statusCode;

    /** The sex. */
    private String sex;

    /** The name. */
    private String name;

    /** The surname 1. */
    private String surname1;

    /** The surname 2. */
    private String surname2;

    /** The birth country. */
    private String birthCountry;

    /** The birth city. */
    private String birthCity;

    /** The contract CMC. */
    private String contractCMC;

    /** The person type. */
    private String personType;

    /** The person code. */
    private String personCode;

    /** The prefix code. */
    private String prefixCode;

    /** The dictionary value. */
    private String dictionaryValue;

    /** The additional info. */
    private String additionalInfo;

    /** The postal code. */
    private String postalCode;

    /** The province code. */
    private String provinceCode;

    /** The province name. */
    private String provinceName;

    /** The num. */
    private String num;

    /** The road name. */
    private String roadName;

    /** The road type code. */
    private String roadTypeCode;

    /** The city. */
    private String city;

    /** The already customer. */
    private Boolean alreadyCustomer;

    /** The movil. */
    private String movil;

    /** The email. */
    private String email;

    /** The occupation type name. */
    private String occupationTypeName;

    /** The profession code. */
    private Integer professionCode;

    /** The birth province code. */
    private String birthProvinceCode;

    /** The birth province. */
    private String birthProvince;

}
