package es.santander.esponboapf.domain.expread;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier account detail dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierAccountDetailDto {

    /** The Iban. */
    private String iban;

    /** The Bban. */
    private String bban;

    /** The Local account. */
    private String localAccount;

    /** The Partenon contract. */
    private String partenonContract;

}
