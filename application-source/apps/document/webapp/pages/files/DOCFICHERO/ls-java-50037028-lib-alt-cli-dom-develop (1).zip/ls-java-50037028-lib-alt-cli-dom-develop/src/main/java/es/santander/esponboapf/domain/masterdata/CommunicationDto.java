package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Communication dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
// Communication data object
public class CommunicationDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -2192353244670075993L;

    /**
     * The Communication code.
     */
    @Schema(description = "Communication code identifier", example = "1")
    private Integer communicationCode;

    /**
     * The Name.
     */
    @Schema(description = "Communication name", example = "Cancel email")
    private String name;

    /**
     * The Application id.
     */
    @Schema(description = "Hubcom applicationId", example = "CONSUMERID-TEST")
    private String applicationId;

    /**
     * The Channel.
     */
    @Schema(description = "Communication channel", example = "EMAIL")
    private String channel;

    /**
     * The Subject.
     */
    @Schema(description = "Communication subject", example = "Example subject")
    private String subject;

    /**
     * The Message.
     */
    @Schema(description = "Communication message", example = "Example message")
    private String message;

    /**
     * The Action code.
     */
    @Schema(description = "Communication audit action code", example = "12")
    private Integer actionCode;

}
