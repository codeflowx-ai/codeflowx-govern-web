package es.santander.esponboapf.domain.exceptions;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Class InternalServerHagCliException.
 */

@AllArgsConstructor
@Getter
public class InternalServerHagCliException extends RuntimeException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4282247220143733713L;

    /** The error name. */
    private final String errorName;

    /** The detailed message. */
    private final String detailedMessage;

    /**
     * Instantiates a new internal server hag cli exception.
     *
     * @param errorName the error name
     */
    public InternalServerHagCliException(String errorName) {
        super();
        this.errorName = errorName;
        this.detailedMessage = null;
    }

}
