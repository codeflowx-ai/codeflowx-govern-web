package es.santander.esponboapf.domain.producttrans;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AttributesUds.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
// Atribute uds
public class AttributesUds {

    /** The san tipo oficina. */
    @JsonProperty("SanTipoOficina")
    private String sanTipoOficina;

    /** The com cod centro. */
    private String comCodCentro;

    /** The full name. */
    private String fullName;

}
