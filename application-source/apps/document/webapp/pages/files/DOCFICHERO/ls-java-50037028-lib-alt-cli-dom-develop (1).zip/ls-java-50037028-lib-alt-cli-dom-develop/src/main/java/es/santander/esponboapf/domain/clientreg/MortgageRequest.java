package es.santander.esponboapf.domain.clientreg;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MortgageRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// MortgageRequest
public class MortgageRequest {

    /** The step. */
    // Step
    @Schema(description = "Indicates the step at which mortgages are informed, "
            + "either at the end of the customer F registration or at account activation.",
            example = "01")
    private String step;

    /** The lst user. */
    // lstUser
    @Schema(description = "List of users with information on person type and BDP person code for each customer.",
            example = """
                      [
                        {
                            "typePerson": "F",
                            "codPerson": 124409622
                        }
                    ]""")
    private List<PersonDto> lstUser;

    /** The iban. */
    // Iban
    @Schema(description = "IBAN of the account created.", example = "ES3200495789481431234567")
    @JsonInclude(Include.NON_NULL)
    private String iban;

}
