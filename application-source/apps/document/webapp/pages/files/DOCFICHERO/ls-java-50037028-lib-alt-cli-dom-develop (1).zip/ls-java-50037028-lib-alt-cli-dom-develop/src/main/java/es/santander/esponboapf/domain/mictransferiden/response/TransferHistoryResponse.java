package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Transfer history response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferHistoryResponse {

    /** The Response date. */
    private String responseDate;

    /** The Occurs. */
    private List<TransferHistoryOccursResponse> occurs;

    /** The Reposition token mis pagos. */
    private String repositionTokenMisPagos;

    /** The Ind moredata. */
    private String indMoredata;

}
