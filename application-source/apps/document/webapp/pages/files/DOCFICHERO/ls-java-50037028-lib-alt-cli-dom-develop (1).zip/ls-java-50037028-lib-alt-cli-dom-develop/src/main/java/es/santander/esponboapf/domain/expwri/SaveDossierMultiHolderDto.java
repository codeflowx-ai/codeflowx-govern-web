/**
 * Self.
 *
 * @return the save dossier multi holder dto. save dossier multi holder dto builder impl
 */
package es.santander.esponboapf.domain.expwri;

import java.util.List;

import javax.validation.Valid;

import es.santander.esponboapf.domain.valcli.bdp.MultiHolderAlreadyClientFullInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SaveDossierMultiHolderDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Basic information needed to create and save the secondary holders when multidossier",
        example = "{\"multiholder\":false, \"notClientList\":[], \"clientList\":[]}")
// SaveDossierMultiHolderDto
public class SaveDossierMultiHolderDto {

    /** The multiholder. */
    // Multiholder
    @Schema(description = "Flag indicating if a dossier is multiholder or not", example = "false")
    private boolean multiholder;

    /** The not client list. */
    @Schema(description = "List of information about the holders who are not yet clients or are not active.",
            example = "[]")
    @Valid
    // Not client list
    private List<SaveHoldersMultiDto> notClientList;

    /** The client list. */
    // Client list
    @Schema(description = "List of information about the holders who are already clients", example = "[]")
    @Valid
    private List<MultiHolderAlreadyClientFullInfo> clientList;
}
