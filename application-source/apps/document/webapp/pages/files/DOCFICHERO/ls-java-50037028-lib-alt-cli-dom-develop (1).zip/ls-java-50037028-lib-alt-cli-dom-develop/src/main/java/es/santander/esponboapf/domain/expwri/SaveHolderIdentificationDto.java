package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Save holder identification dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SaveHolderIdentificationDto {

    /**
     * The Holder id.
     */
    @Schema(description = "Holder identifier", example = "R")
    private String holderId;

    /**
     * The Holder code.
     */
    @Schema(description = "Holder code", example = "1")
    private Long holderCode;

    /**
     * The Identification code.
     */
    @Schema(description = "Identification type code", example = "1")
    private Integer identificationCode;

    /**
     * The Identification state.
     */
    @Schema(description = "Identification state code", example = "R")
    @Pattern(regexp = "[\\w]+")
    private String identificationState;

    /**
     * The Increase rejection.
     */
    @Schema(description = "Increase reject video", example = "true")
    private Boolean increaseRejectVideo;

    /** The Reject reason. */
    // Reject reason
    @Schema(description = "Description of the reject reason.", nullable = true, example = "transferencia ilicita")
    private String rejectReason;

    /** The Pex. */
    @Schema(description = "Pex number of a document", example = "24G6E2TR")
    @Pattern(regexp = "[a-zA-Z0-9-_\\/ ]*")
    @Size(max = 20)
    private String pex;

}
