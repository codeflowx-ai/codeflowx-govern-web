package es.santander.esponboapf.domain.fraud;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReportFraudDto.
 *
 * Information received and processed about the fraud detection process.
 */
@NoArgsConstructor
@Data
@Schema(description = "Information received and processed about the fraud detection process.", 
example = "{\"guid\":\"a4f5121f-0aef-494d-a8e4-b0a9dd8c6070\","
        + "\"requestNumber\":2455,\"decisionResult\":\"01\","
        + "\"cancelDossier\":true,\"rules\":[{\"holderCode\":102,\"ruleCode\":15}],"
        + "\"errorCode\":1303,\"errorMessage\":\"El GUID ya existe en el sistema\"}")
public class ReportFraudDto {

    /**
     * The guid.
     *
     * Fraud detection process unique id.
     * E.g.: 'a4f5121f-0aef-494d-a8e4-b0a9dd8c6070'
     */
    @Schema( description = "Fraud detection process unique id.",
            example = "a4f5121f-0aef-494d-a8e4-b0a9dd8c6070")
    @NotNull
    private UUID guid;

    /**
     * The request number.
     *
     * Matches the dossier code.
     * E.g.: 2455
     */
    @Schema( description = "Report number. Matches the dossier code.", example = "2455")
    @NotNull
    private Integer requestNumber;

    /**
     * The decision result.
     *
     * E.g.: '01'
     */
    @Schema( description = "The decision result.", example = "01")
    @Size(max = 2)
    @Pattern(regexp = "^[0-9]{2}$")
    private String decisionResult;

    /**
     * The cancel dossier.
     *
     * Flag for dossier cancellation
     */
    @Schema(description = "Flag for dossier cancellation.", example = "true")
    private Boolean cancelDossier;

    /**
     * The rules.
     *
     * The list of rules in case the fraud process detected some issue with the
     * holder
     */
    @Schema(description = "The list of rules in case the fraud process detected some issue with the holder.",
            example = "[{\"holderCode\":102,\"ruleCode\":15}]")
    @Valid
    private List<RuleHolderDto> rules;

    /**
     * The error code.
     *
     * Error code in case something went wrong in the fraud process
     * E.g.: 1303
     */
    @Schema(description = "Error code in case something went wrong in the fraud process.", example = "1303")
    private Integer errorCode;

    /**
     * The error message.
     *
     * Error message in case something went wrong in the fraud process
     * E.g.: 'El GUID ya existe en el sistema'
     */
    @Schema(description = "Error message in case something went wrong in the fraud process.",
            example = "El GUID ya existe en el sistema")
    @XssValid
    private String errorMessage;
}
