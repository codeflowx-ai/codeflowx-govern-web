package es.santander.esponboapf.domain.common;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ResponseMessage.
 *
 * Response message with code.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Generic response message", example = "{}")
public class ResponseMessage {

    /** The code. */
    // Code
    @Schema(description = "Message code", example = "TD001")
    private String code;

    /** The description. */
    // Description
    @Schema(description = "Message description", example = "functional error")
    private String description;

}
