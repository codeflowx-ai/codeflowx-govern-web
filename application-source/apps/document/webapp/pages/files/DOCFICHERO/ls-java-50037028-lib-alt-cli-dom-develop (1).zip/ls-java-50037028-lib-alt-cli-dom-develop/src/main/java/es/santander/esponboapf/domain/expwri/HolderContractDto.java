package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderContractDto.
 */
//The class HolderContractDto
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderContractDto {

    /**
     * The gn id.
     */
    // The gn id
    @Schema(description = "Number identifying a gn id", example = "PIOL_BKS0200491117e34047d2b00300")
    private String gnId;

    /** The Contract code. */
    // The Contract code
    @Schema(description = "Number identifying a contract code", example = "2")
    private Integer contractCode;
    
    /** The signed. */
    @Schema(description = "Indicate if the contract is signed in signature expedient.", example = "true")
    private Boolean signed;
    
    /** The add exp sign. */
    @Schema(description = "Indicate if the contract is uploaded to signature expedient.", example = "true")
    private Boolean addExpSign;
    
    /** The add exp sign read. */
    @Schema(description = "Indicate if the contract is uploaded to signature expedient to the reading section.",
            example = "true")
    private Boolean addExpSignRead;
    

}
