package es.santander.esponboapf.domain.expwri.dossier.save;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Holder document compare.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Holder document compare
public class HolderDocumentCompare {

    /**
     * The Holder code.
     */
    // Holder code
    private Long holderCode;

    /**
     * The Actions.
     */
    // Action list
    private List<CompareResult> actions;

}
