package es.santander.esponboapf.domain.expread;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MuleroInfoReportDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MuleroInfoReportDto {

    /** The dossier code. */
    private Long dossierCode;

    /** The identity number. */
    private String identityNumber;

    /** The person code (the F code). */
    private String personCode;

    /** The full name. */
    private String fullName;

    /** The request date. */
    private LocalDateTime requestDate;

    /** The state. */
    private String state;

    /** The identification type. */
    private String identificationType;

}
