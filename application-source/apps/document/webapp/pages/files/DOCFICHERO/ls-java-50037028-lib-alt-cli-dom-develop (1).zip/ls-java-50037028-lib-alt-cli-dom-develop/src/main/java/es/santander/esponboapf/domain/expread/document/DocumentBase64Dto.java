package es.santander.esponboapf.domain.expread.document;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DocumentBase64Dto
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Info about document indicating its code, file, content type and document in base 64.",
example = "{\"documentCode\":\"1\",\"documentFileName\":\"file.pdf\","
        + "\"documentBase64\":\"dGVzdCBzdHJpbmc=\",\"documentContentType\":\"application/pdf\"}")
// Document base 64 dto
public class DocumentBase64Dto {

    /**
     * The Document code.
     */
    // Document code
    @Schema(description = "Document identifier", example = "1")
    private String documentCode;

    /** The document file name */
    // Document file name
    @Schema(description = "Document File Name", example = "file.pdf")
    private String documentFileName;

    /** The document base 64*/
    // Document base 64
    @Schema(description = "Document file in base64", example= "dGVzdCBzdHJpbmc=")
    private String documentBase64;
    
    /** The document content type */
    // Document content type
    @Schema(description = "Document content type", example = "application/pdf")
    private String documentContentType;
}
