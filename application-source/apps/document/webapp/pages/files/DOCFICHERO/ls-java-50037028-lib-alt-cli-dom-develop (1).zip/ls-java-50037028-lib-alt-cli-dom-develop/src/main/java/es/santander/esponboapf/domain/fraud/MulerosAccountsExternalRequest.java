package es.santander.esponboapf.domain.fraud;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MulerosAccountsExternalRequest.
 *
 * MulerosAccountsExternalRequest.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MulerosAccountsExternalRequest {

    /** The account. */
    // The account
    private List<AccountDataDto> account;

}
