package es.santander.esponboapf.domain.valcli.bdp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpContactListRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// BdpContactListRequest
public class BdpContactListRequest {

    /** The customer id. */
    // Customer id
    private String customerId;

    /** The body bdp. */
    // Body bdp
    private BdpContactListDto bodyBdp;

}
