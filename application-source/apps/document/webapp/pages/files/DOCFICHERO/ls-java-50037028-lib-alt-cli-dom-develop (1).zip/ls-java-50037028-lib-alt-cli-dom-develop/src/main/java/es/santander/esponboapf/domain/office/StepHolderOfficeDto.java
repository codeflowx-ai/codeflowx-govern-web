package es.santander.esponboapf.domain.office;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Step holder office dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StepHolderOfficeDto {

    /** The Step code. */
    private Integer stepCode;

    /** The Step name. */
    private String stepName;

    /** The Step state code. */
    private String stepStateCode;

    /** The Step state name. */
    private String stepStateName;

    /** The Order. */
    private Integer order;

}
