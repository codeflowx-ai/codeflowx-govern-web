package es.santander.esponboapf.domain.expwri;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.validation.annotations.SaveBasicMultiHolder;
import es.santander.esponboapf.domain.validation.groups.Others;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SaveDossierIsMonoOrMultiWithHoldersDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information about if a dossier is mono holder or multi holder and its holders",
        example = "{\"dossierId\":\"70fd7423-5759-447b-a92f-6e88f514cc89\",\"isMultiHolder\":false,\"holders\",[]}")
@SaveBasicMultiHolder
// SaveDossierIsMonoOrMultiWithHoldersDto
public class SaveDossierIsMonoOrMultiWithHoldersDto {

    /** The dossier id. */
    // identificador unico de expediente
    @Schema( description = "Unique dossier identifier.",
            example = "70fd7423-5759-447b-a92f-6e88f514cc89")
    @NotNull(groups = Others.class)
    private UUID dossierId;

    /** The is multi holder. */
    // is multi holder
    @Schema( description = "Flag indicating if this dossier is multiholder.", example = "false")
    private Boolean isMultiHolder;

    /** The holders. */
    // Holders
    // SaveHoldersMultiDto
    @Valid
    @Schema( description = "Holder list with elements if the ds is multiholder.",
            example = "[{\"priority\":\"2\", \"countryCode\":\"ES\", \"cellPhone\":\"666666666\", "
                    + "\"email\":\"eddie.the.great@some.com\", \"identityTypeCode\":1,\"identityNumber\":\"66666666T\","
                    + "\"holdertype\":1}]")
    private List<SaveHoldersMultiDto> holders;

}
