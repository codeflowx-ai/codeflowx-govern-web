package es.santander.esponboapf.domain.valcli;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import es.santander.esponboapf.domain.util.LocalDateTimeISO8601Deserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * The type Branch locator office response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchLocatorOfficeResponse {

    /** The Id. */
    private String id;

    /** The Code. */
    private String code;

    /** The Entity code. */
    private String entityCode;

    /** The Name. */
    private String name;

    /** The Poi status. */
    private String poiStatus;

    /** The Object type. */
    private BranchLocatorOfficeMulti objectType;

    /** The Sub type. */
    private BranchLocatorOfficeMulti subType;

    /** The Location. */
    private BranchLocatorOfficeLocation location;

    /** The Distance in km. */
    private String distanceInKm;

    /** The Distance in miles. */
    private String distanceInMiles;

    /** The Contact data. */
    private BranchLocatorOfficeContactData contactData;

    /** The Appointment. */
    private BranchLocatorOfficeAppointment appointment;

    /** The Schedule. */
    private BranchLocatorOfficeSchedule schedule;

    /** The Rich texts. */
    private List<BranchLocatorOfficeMulti> richTexts;

    /** The Store. */
    private String store;

    /** The Url detail page. */
    private String urlDetailPage;

    /** The Updated time. */
    @JsonDeserialize(using = LocalDateTimeISO8601Deserializer.class)
    private LocalDateTime updatedTime;

    /** The Hide url detail. */
    private String hideURLDetail;

    /** The Poicode. */
    private String poicode;

}
