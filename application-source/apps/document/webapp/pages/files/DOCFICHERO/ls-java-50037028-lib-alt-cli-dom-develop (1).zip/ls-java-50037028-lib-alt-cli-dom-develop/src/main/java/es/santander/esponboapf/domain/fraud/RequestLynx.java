package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new request lynx.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// RequestLynx
public class RequestLynx {

    /** The call type. */
    @Schema(description = "Call type", example = " ")
    private String callType;

    /** The customer id. */
    @Schema(description = "Customer BDP reference", example = "F128823248")
    private String customerId;

    /** The fraud id. */
    @Schema(description = "Fraud id", example = " ")
    private String fraudId;

    /** The meta data. */
    @Schema(description = "Values to evaluate",
            example = "{\"COD_EMPRESA\":\"0049\",\"HOST_ID\":\"08\","
                    + "\"CUSTOMER_TYPE\":\"F\",\"CUSTOMER_NUMBER\":\"128217027\",\"AUTN_METHOD\":\"01\","
                    + "\"DEBIT_CREDIT_NONMON_FLAG\":\"0\",\"PROCESS_FLAG\":\"02\",\"MESSAGE_TYPE\":\"NM\","
                    + "\"DATE_TIME\":\"20220707082523\",\"PHONE_NUM\":\"34678600211\","
                    + "\"TRANSACTION_UNIQUE_ID\":\"d704b578-9968-49a1-91b1-9b156382b0af\","
                    + "\"IP_ADDRESS\":\"180.15.161.216\",\"RESPONSE_CODE\":\"000\",\"IOC_UID\":\"HAGCLI\","
                    + "\"CARD_DISCHARGE_DATE\":\"29062022\",\"MARCO_CHANNEL\":\"INT\",\"TRANSACTION_CODE\":\"216\","
                    + "\"BENEFICIARY_ADDRESS\":\"Calle Jaime Vera 7 28011 Madrid\",\"EMAIL\":\"prueba@mail.com\","
                    + "\"EDUCATIONAL_LEVEL\":\"2\",\"OCCUPATION\":\"3\"}")
    private String metaData;

    /** The operation subtype. */
    @Schema(description = "operation type for subtype", example = "BB")
    private String operationSubtype;

    /** The operation type. */
    @Schema(description = "Operation type", example = "100")
    private String operationType;

    /** The reference id. */
    @Schema(description = "Reference Id", example = " ")
    private String referenceId;

    /** The score. */
    @Schema(description = "Score value", example = "0")
    private Integer score;

    /** The status. */
    @Schema(description = "It describes the status of validation", example = "OK")
    private String status;
}
