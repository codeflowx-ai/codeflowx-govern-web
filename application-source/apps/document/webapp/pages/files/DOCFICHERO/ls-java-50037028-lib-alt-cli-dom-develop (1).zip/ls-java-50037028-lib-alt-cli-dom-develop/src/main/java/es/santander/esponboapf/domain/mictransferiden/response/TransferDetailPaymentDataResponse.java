package es.santander.esponboapf.domain.mictransferiden.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import es.santander.esponboapf.domain.util.StringTrimmerDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer detail payment data response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferDetailPaymentDataResponse {

    /** The Payment date. */
    private String paymentDate;

    /** The Settlement date. */
    private String settlementDate;

    /** The Transfer amount. */
    private Double transferAmount;

    /** The Currency. */
    private String currency;

    /** The Payment concept. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String paymentConcept;

    /** The Expense indicator. */
    private String expenseIndicator;

    /** The Urgency indicator. */
    private String urgencyIndicator;

    /** The Transfer status. */
    private String transferStatus;

}
