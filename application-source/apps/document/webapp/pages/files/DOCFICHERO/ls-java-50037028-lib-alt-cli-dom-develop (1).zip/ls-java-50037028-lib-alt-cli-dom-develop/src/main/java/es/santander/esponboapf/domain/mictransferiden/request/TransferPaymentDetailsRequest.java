package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer payment details request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferPaymentDetailsRequest {

    /** The Payment date. */
    private String paymentDate;

    /** The Payment amount. */
    private String paymentAmount;

    /** The Currency. */
    private String currency;

    /** The Counterpart currency. */
    private String counterpartCurrency;

}