package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CompanyDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Company where the holder works", 
example ="{\"companyName\":\"IBERDROLA SA\","
        + "\"companyAddress\":\"AV. CANTABRIA 01, BOADILLA MONTE 28660 M ES\"}")
public class CompanyDto {

    /**
     * The company name.
     *
     * E.g.: 'BANCO SANTANDER, S.A.'
     */
    @Schema(maxLength = 50, description = "Company name", example = "IBERDROLA SA")
    private String companyName;

    /**
     * The company address.
     *
     * E.g.:'AV. CANTABRIA 01, BOADILLA MONTE 28660 M ES'
     */
    @Schema(maxLength = 250, description = "Company address", example = "AV. CANTABRIA 01, BOADILLA MONTE 28660 M ES")
    private String companyAddress;
}
