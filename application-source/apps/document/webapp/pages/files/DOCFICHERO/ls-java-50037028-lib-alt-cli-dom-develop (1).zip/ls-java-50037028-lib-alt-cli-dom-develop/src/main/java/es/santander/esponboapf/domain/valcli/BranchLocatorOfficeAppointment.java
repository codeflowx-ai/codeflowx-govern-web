package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Branch locator office appointment.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchLocatorOfficeAppointment {

    /** The Waiting time teller. */
    private String waitingTimeTeller;

    /** The Waiting time specialist. */
    private String waitingTimeSpecialist;

    /** The Branch appointment. */
    private String branchAppointment;

}
