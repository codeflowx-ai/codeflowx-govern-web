package es.santander.esponboapf.domain.expwri;

import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.valcli.bdp.CollectiveDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class Dossier.
 */

@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Dossier generated after the initiation of an application in digital onboarding",
example = "{\"campaignCode\":221,\"accountCode\":1,\"ipAddress\",\"127.0.0.0\","
        + "\"identityNumberAgent\":\"11111111H\",\"identityTypeAgent\":1,"
        + "\"fullNameAgent\":\"Nombre completo agente\","
        + "\"holder\":{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"priority\":\"1\",\"universityCode\":1}}")
public class DossierDto extends DossierParentDto {

    @Schema(description = "Campaign chosen by the holder to be contracted", example = "221")
    @NotNull
    private Integer campaignCode;

    /**
     * The account code.
     *
     * The account code which the dossier will be based in.
     */
    @Schema(description = "Account chosen by the holder to be contracted", example = "1")
    @NotNull
    private Long accountCode;

    // Es necesario para el proceso de onboarding
    /**
     * the IPADDRESS.
     *
     * The client IP address.
     */
    @Schema(maxLength = 39, description = "Ip of the holder at the time of the request", example = "127.0.0.0")
    @Size(max = 39)
    private String ipAddress;

    /**
     * The identity number agent.
     */
    @Schema(description = "Agent's identity number", example = "11111111H")
    private String identityNumberAgent;

    /**
     * The Identity type agent.
     */
    @Schema(description = "Agent's identity type", example = "1")
    private Integer identityTypeAgent;

    /**
     * The full name agent.
     */
    @Schema(description = "Agent's full name", example = "Nombre completo agente")
    private String fullNameAgent;

    // El titular asociado al expediente
    /**
     * the Holder.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     */
    @Valid
    @Schema(description = "Natural person performing the digital onboarding", 
    example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
            +"\"priority\":\"1\",\"universityCode\":1}")
    @NotNull
    private HolderDto holder;
    
    @Valid
    @Schema(maxLength = 100, description = "Unique dossier identifier in a external application.",
            example = "70fd7423-5759-447b-a92f-6e88f514cc89")
    private UUID dossierIdExternal;

    /**
     * The Collectives.
     */
    @Schema(description = "List of collectives. Ignored for secondary holders.")
    private List<CollectiveDto> collectives;

}
