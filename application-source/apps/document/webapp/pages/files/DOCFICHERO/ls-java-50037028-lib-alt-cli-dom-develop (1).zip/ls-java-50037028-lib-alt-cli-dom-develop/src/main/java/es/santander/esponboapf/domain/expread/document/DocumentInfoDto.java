package es.santander.esponboapf.domain.expread.document;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class DocumentInfoDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Document information indicating its name, status, reason for rejection.")
// Document info
public class DocumentInfoDto extends HolderDocumentDataDto {

    /** The holder doc code. */
    // Holder doc code
    @Schema(description = "Id data holder code", example = "1")
    private Long holderDocCode;

    /** The doc state code. */
    // Doc state code
    @Schema(description = "Document status code.", example = "REI")
    private String docStateCode;

    /** The doc state name. */
    // Doc state name
    @Schema(description = "Description of the status of the document.", example = "Requerido entregado incorrecto")
    private String docStateName;

    /** The reject reason code. */
    // Reject reason code
    @Schema(description = "Document status code.", example = "5")
    private Integer rejectReasonCode;

    /** The reject reason name. */
    // Reject reason name
    @Schema(description = "Description of the reject of the document", example = "Otros - call centre")
    private String rejectReasonName;

    /** The reject reason text. */
    // Reject reason text
    @Schema(description = "Descriptive text of the reason.", example = "Otro motivo")
    private String rejectReasonText;

    /** The filenames. */
    // File names
    @Schema(description = "List of names of documents located in s3.", example = "{filename1.jpg,filename2.jpg}")
    private List<String> filenames;

    /** The mandatory child list. */
    // Mandatory child list
    @Schema(description = "List of documents information indicating its name, status, reason for rejection.")
    private List<DocumentInfoDto> mandatoryChildList;

}
