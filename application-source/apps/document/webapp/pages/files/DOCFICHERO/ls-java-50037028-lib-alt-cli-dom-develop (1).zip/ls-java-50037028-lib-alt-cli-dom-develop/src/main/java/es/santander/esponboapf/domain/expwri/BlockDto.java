package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BlockDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information to lock a dossier", 
example = "{\"dossierCode\":147,\"userCode\":\"x12365\",\"userName\":\"DIEGO CANO CANO\"}")
public class BlockDto {

    /**
     * The dossier code.
     * 
     * Dossier code. Eg: 147
     */
    @Schema( description = "Dossier code", example = "147")
    @NotNull
    private int dossierCode;

    /**
     * The user code.
     * 
     * User Id. Eg: x12345
     */
    @Schema(description = "User id", example = "x12365")
    private String userCode;

    /**
     * The user name.
     * 
     * User's full name. Eg: Diego Cano Cano
     */
    @Schema(description = "User's full name", example = "DIEGO CANO CANO")
    private String userName;
}
