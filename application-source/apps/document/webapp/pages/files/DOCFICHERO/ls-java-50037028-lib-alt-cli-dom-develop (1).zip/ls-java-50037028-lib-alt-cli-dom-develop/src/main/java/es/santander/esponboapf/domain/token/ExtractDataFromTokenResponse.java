package es.santander.esponboapf.domain.token;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ExtractDataFromTokenResponse.
 */
//The class ExtractDataFromTokenResponse
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ExtractDataFromTokenResponse {

    /** The jwt. */
    private String jwt;
}
