package es.santander.esponboapf.domain.sign;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderContractSignDataDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@Schema(description = "Information about holder contracts & if they are already signed.", example = "{}")
public class HolderContractSignDataDto {

    /** The contract code. */
    @Schema(description = "The contract identifier", example = "1")
    public int contractCode;

    /** The contract name. */
    @Schema(description = "The contract description", example = "Condiciones particulares")
    public String contractName;

    /** The block code. */
    @Schema(description = "Block order", example = "2")
    public int blockCode;

    /** The num order. */
    @Schema(description = "Order number inside a block", example = "3")
    public int numOrder;

    /** The signed. */
    @Schema(description = "Flag indicating sign status", example = "true")
    public boolean signed;

}