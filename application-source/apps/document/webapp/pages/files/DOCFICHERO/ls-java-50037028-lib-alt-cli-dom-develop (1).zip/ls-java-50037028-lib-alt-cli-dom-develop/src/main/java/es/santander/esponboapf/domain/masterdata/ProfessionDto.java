package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new profession dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Profession performed according to the occupational sector",
example  = "{\"professionCode\":1,\"professionName\":\"Ingeniero\"}")
public class ProfessionDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 2610762596166476752L;

    /**
     * The sector code.
     *
     * E.g.: 1.
     */
    @Schema(description = "Number identifying a profession", example = "1")
    private Integer professionCode;

    /**
     * The sector name.
     *
     * E.g.: 'Engineer'
     */
    @Schema(description = "Profession description", example = "Ingeniero")
    private String professionName;
}
