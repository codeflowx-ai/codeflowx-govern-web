package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Campaign lopd url.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// CampaignLopdUrl
public class CampaignLopdUrl {

    /**
     * The Url lopd.
     */
    // UrlLOPD
    @Schema(description = "The LOPD document url", example = "http:://example.com/lopd.pdf")
    private String urlLopd;

}
