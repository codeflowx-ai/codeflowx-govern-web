package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new lock dossier response.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information indicating the lock status of the dossier.",
example = "{\"result\":false,\"userCode\":\"x12365\",\"userName\":\"DIEGO CANO CANO\"}")
public class LockDossierResponse {

    /** The result. */
    // Indica si está o no bloqueado
    @Schema( description = "Is blocked or not blocked.", example = "false")
    @NotNull
    private boolean result;

    /** The user code. */
    // Sólo en caso de bloqueo, hay un código de usuario
    @Schema(description = "If the dossier is locked, the user code. If it is not blocked it will be null.",
            example = "x12365")
    private String userCode;

    /** The user name. */
    // Si el expediente está bloqueado, se informa el nombre completo del usuario.
    @Schema(description = "If the dossier is locked, the full username. If it is not blocked it will be null.",
            example = "DIEGO CANO CANO")
    private String userName;

}
