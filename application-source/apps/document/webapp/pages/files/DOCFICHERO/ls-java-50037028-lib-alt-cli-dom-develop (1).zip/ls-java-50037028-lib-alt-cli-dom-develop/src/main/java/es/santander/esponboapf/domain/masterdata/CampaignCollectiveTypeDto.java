package es.santander.esponboapf.domain.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Campaign collective dto.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
// CampaignCollectiveTypeDto
public final class CampaignCollectiveTypeDto {

    /**
     * The Collective type.
     */
    // Collective type
    @Schema( description = "Campaign collective type", example = "004")
    private String collectiveType;

}
