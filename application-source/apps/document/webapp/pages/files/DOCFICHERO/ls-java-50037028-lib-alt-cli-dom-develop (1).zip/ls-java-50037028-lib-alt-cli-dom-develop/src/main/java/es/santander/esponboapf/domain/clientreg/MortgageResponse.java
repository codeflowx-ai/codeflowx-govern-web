package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MortgageResponse.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// MortgageResponse
public class MortgageResponse {

    /** The code. */
    // Code
    @Schema(description = "Service response code.", example = "ONBOARDING_RESPONSE_REQUEST_DNI_KO")
    private String code;

    /** The description. */
    // Description
    @Schema(description = "Description of service response.", example = "ONBOARDING_RESPONSE_REQUEST_DNI_KO_DESC")
    private String description;

    @Override
    public String toString() {
        return "Respuesta [code=" + code + ", description=" + description + "]";
    }

}
