package es.santander.esponboapf.domain.expread;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder document dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderDocumentDto {

    /**
     * The Holder doc code.
     */
    private Long holderDocCode;

    /**
     * The Holder code.
     */
    private Long holderCode;

    /**
     * The Document code.
     */
    private Integer documentCode;

    /**
     * The Doc state code.
     */
    private String docStateCode;

    /**
     * The Type.
     */
    private Integer type;

    /**
     * The Reject code.
     */
    private Integer rejectCode;

    /**
     * The Desc other reason.
     */
    private String descOtherReason;

    /**
     * The Filenames.
     */
    private String filenames;

}
