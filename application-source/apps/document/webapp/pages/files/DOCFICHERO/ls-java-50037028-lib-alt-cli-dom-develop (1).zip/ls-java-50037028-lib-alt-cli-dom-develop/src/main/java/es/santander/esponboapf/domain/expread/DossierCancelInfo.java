package es.santander.esponboapf.domain.expread;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierCancelInfo.
 */
//The class DossierCancelInfo
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Response for service file net data",
example = "{\"s3\":true,\"signExpedientId\":1,\"dossierCode\":1,\"isExernalApp\":true,"
        + "\"dossierIdExt\":\"91186c26-60ce-11ed-9b6a-0242ac120002\",\"stateCodeDossier\":1}")
public class DossierCancelInfo {

    /**
     * The Identity type
     */
    // The Identity type
    @Schema(description = "Indicate if has document to delete in S3", example = "true")
    private Boolean s3;

    /**
     * The Identity number.
     */
    // The Identity number
    @Schema(description = "Identity of sign expedient to cancel", example = "1")
    private Long signExpedientId;

    /** The dossier id. */
    // Dossier id
    @NotNull
    @Schema(description = "Uuid of the dossier, it will be identified with the dossier in the services.",
            example = "1")
    private Long dossierCode;

    /** The is external app. */
    @Schema(description = "Indicate if the dossier is external app.",
            example = "true")
    private Boolean isExternalApp;

    /** The dossier id ext. */
    @Schema(description = "Indicate the dossier id external if exists.",
            example = "91186c26-60ce-11ed-9b6a-0242ac120002")
    private String dossierIdExt;

    /** The state code dossier. */
    @Schema(description = "Indicate the state code of the dossier.",
            example = "1")
    private Integer stateCodeDossier;
}
