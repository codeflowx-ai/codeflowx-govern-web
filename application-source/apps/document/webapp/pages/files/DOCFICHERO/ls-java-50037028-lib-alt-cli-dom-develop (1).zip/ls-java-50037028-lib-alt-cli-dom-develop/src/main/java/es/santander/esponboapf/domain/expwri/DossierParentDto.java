package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import es.santander.esponboapf.domain.validation.groups.Others;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierParentDto.
 *
 * It is associated with an onboarding process.
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
// Dossier parent data object
public class DossierParentDto {

    /** The dossier id. */
    // identificador unico de expediente
    @Schema(maxLength = 100, description = "Unique dossier identifier.",
            example = "70fd7423-5759-447b-a92f-6e88f514cc89")
    @NotNull(groups = Others.class)
    private UUID dossierId;

    /**
     * The step.
     *
     * This value will describe the step which the process is in.
     *
     * It is mandatory due to the need to know where the process was when it was
     * paused and to be able to go back to that same point in case that process is
     * resumed in the future.
     * *
     */
    @Schema(maxLength = 100,
            description = "Step where is located in the screen flow. "
                    + "This field is useful to indicate which actions should be performed each time the continue "
                    + "button is clicked.",
                    example = "ocupación actual titular 1")
    @XssValid
    @Size(max = 100)
    private String step;

}
