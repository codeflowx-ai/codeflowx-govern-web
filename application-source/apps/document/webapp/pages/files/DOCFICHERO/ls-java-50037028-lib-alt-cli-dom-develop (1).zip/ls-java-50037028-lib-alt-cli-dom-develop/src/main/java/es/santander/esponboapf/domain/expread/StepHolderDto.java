package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Instantiates a new step holder dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information about Holder's steps", 
example = "{\"stepCode\":2,\"stepName\":\"Identificación\",\"stepStateCode\":\"R\","
        + "\"stepStateName\":\"realizado\",\"isCompleted\":true,"
        + "\"isRequerired\":true,\"rejectNumber\":1}")
public class StepHolderDto {

    /**
     * The step code.
     *
     * Código identificativo del paso.
     */
    @Schema(description = "Holder's step code", example = "2")
    private Integer stepCode;

    /**
     * The step name.
     *
     * Nombre del paso
     */
    @Schema(description = "Holder's step description", example = "Identificación")
    private String stepName;

    /**
     * The step state code.
     *
     * Identificador del estado del paso.
     */
    @Schema(description = "Holder's step status code", example = "R")
    private String stepStateCode;

    /**
     * The step state name.
     *
     * Nombre del estado en el que se encuentra el paso del titular.
     */
    @Schema(description = "Holder's step status description", example = "realizado")
    private String stepStateName;

    /**
     * The is completed.
     *
     * Indica si el paso se ha completado.
     */
    @Schema(description = "indicator for a Holder's step finished", example = "true")
    private Boolean isCompleted;

    /**
     * The is required.
     *
     * Indica si es requerido.
     */
    @Schema(description = "indicator for a required Holder's step", example = "true")
    private Boolean isRequired;

    /**
     * The reject number.
     *
     * Número de veces que el paso ha sido rechazado.
     */
    @Schema(description = "number of times the step has been rejected", example = "1")
    private Integer rejectNumber;
    
    /** The code flow. */
    @Schema(description = "Indicator with code flow ", example = "PP002")
    private String codeFlow;
    
    /** The order. */
    @Schema(description = "Indicator the order", example = "1")
    private Integer order;
    
    /** The icon. */
    @Schema(description = "Indicator the icon type", example = "pdf")
    private String icon;
    
    /** The subtitle. */
    @Schema(description = "Text of each step depending on the state", 
            example = "Con tu dirección, nivel de estudios y profesión")
    private String subtitle;
    
}
