package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderIdentificationDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Holder identification data.")
public class HolderIdentificationDataDto {

    /**
     * The Holder id.
     */
    @Schema(description = "UUID identifying an holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;


    /** The identification holder. */
    @Schema(description = "Description of the identification choose by the holder", 
            example ="Identificación por Iban")
    private String identificationHolder;

 
    /** The identification state holder. */
    @Schema(description = "Description of the state of the identification choose by the holder", 
            example = "Pendiente de validar OTP")
    private String identificationStateHolder;

    /** The reject number video. */
    @Schema(description = "Rejects numbers of the video-identification", example = "0")
    private Integer rejectNumberVideo;

    /** The retries total otp iban. */
    @Schema(description = "Number of retries to validate OTP of the last transfer", example = "1")
    private Integer retriesTotalOtpIban;

    /** The reject iban. */
    @Schema(description = "Number of rejects ot the IBAN identification", example = "2")
    private Integer rejectIban;

    /** The has exceeded max reject video. */
    @Schema(description = "Indicates if has exceeded the maximum number of video identification rejects",
            example = "true")
    private Boolean hasExceededMaxRejectVideo;

    /** The has exceeded max reject iban. */
    @Schema(description = "Indicates if has exceeded the maximum number of IBAN identification rejects",
            example = "false")
    private Boolean hasExceededMaxRejectIban;

}
