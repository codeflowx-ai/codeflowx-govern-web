package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DocumentTinDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentTinDto {

    /** The document type code. */
    private String documentTypeCode;

    /** The document number. */
    private String documentNumber;
}
