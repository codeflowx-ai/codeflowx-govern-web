package es.santander.esponboapf.domain.masterdata;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CountryEquivalentDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "List of equivalent contries with list ultramar´s country.")
// CountryEquivalentDto
public class CountryEquivalentDto {

    /** The countries. */
    // Countries
    @Schema(description = "The countries", example = """
                        [
              {
                "countryCode": "AU",
                "countryName": "Australia",
                "flagFile": "australia.svg",
                ...
              },
              {
                "countryCode": "BR",
                "countryName": "Brasil",
                "flagFile": "brazil.svg",
                ...
              },
              ...
            ]
                        """)
    private List<CountryDto> countries;

    /** The overseas territories. */
    // Overseas territories
    @Schema(description = "The overseas territories", example = """
                        Mahoré / Mayotte,
            Nueva Caledonia,Polinesia francesa,
            San Pedro y Miguelón, Wallis y Futura,
            Antillas Neerlandesas (Curaçao, Bonaire,
            San Martín, San Eustaquio y Saba) y Aruba
                        """)
    private String overseasTerritories;

}
