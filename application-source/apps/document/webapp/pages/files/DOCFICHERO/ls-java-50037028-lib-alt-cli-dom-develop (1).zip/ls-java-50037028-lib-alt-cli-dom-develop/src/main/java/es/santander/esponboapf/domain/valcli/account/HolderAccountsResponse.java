package es.santander.esponboapf.domain.valcli.account;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class HolderAccountsResponse.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// HolderAccountsResponse
public class HolderAccountsResponse {

    /** The accounts. */
    // Accounts
    @Schema(description = "List of accounts from a holder", example = "")
    private List<AccountsDto> accounts;

}
