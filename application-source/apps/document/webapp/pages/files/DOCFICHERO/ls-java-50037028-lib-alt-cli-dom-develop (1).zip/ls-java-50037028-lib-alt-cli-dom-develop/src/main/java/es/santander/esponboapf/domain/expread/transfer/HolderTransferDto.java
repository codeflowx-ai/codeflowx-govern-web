package es.santander.esponboapf.domain.expread.transfer;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * The Class HolderTransferDto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HolderTransferDto {

    /**
     * The Holder transfer code.
     */
    @Schema(description = "Holder transfer code", example = "1")
    private Long holderTransferCode;

    /**
     * The Holder code.
     */
    @Schema(description = "Holder code", example = "1")
    private Long holderCode;

    /**
     * The Beneficiary iban.
     */
    @Schema(description = "Beneficiary iban", example = "ES2114650100722030876293")
    private String beneficiaryIban;

    /**
     * The Iberpay.
     */
    @Schema(description = "Iberpay data")
    private HolderIberpayDto iberpay;

    /**
     * The Transfer date.
     */
    @Schema(description = "Transfer date", example = "2019-01-21T05:47:08.644")
    private LocalDateTime transferDate;

    /**
     * The Transfer state code.
     */
    @Schema(description = "Transfer state code", example = "1")
    private String transferStateCode;

    /**
     * The Transfer state desc.
     */
    @Schema(description = "Transfer state description", example = "1")
    private String transferStateDesc;

    /**
     * The Otp key.
     */
    @Schema(description = "OTP key", example = "A123A123")
    private String otpKey;

    /**
     * The Otp expiration.
     */
    @Schema(description = "OTP expiration date", example = "2019-01-21T05:47:08.644")
    private LocalDateTime otpExpiration;

    /**
     * The Retries.
     */
    @Schema(description = "Number of retries", example = "1")
    private Integer retries;

    /**
     * The Last operation ref.
     */
    @Schema(description = "Last operation reference", example = "1")
    private String lastOperationRef;

    /**
     * The Liquidation date.
     */
    @Schema(description = "Liquidation date", example = "2019-01-21T05:47:08.644")
    private LocalDateTime liquidationDate;

}
