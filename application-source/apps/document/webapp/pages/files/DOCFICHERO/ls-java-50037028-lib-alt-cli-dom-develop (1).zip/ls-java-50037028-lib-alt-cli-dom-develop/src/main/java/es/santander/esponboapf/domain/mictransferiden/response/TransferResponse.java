package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Transfer response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferResponse {

    /** The Response date. */
    private String responseDate;

    /** The Application issues payment. */
    private String applicationIssuesPayment;

    /** The Operation reference. */
    private String operationReference;

    /** The Operation status. */
    private TransferOperationStatusResponse operationStatus;

    /** The Value date. */
    private String valueDate;

    /** The Transfer amount. */
    private TransferAmountDataResponse transferAmount;

    /** The Order account. */
    private String orderAccount;

    /** The Beneficiary account. */
    private String beneficiaryAccount;

    /** The Beneficiary bic. */
    private String beneficiaryBIC;

    /** The Settlement date. */
    private String settlementDate;

    /** The Method. */
    private String method;

    /** The End to end reference. */
    private String endToEndReference;

    /** The Reference standard. */
    private TransferReferenceStandardResponse referenceStandard;

    /** The Market. */
    private String market;

    /** The Daily general operationsdate. */
    private String dailyGeneralOperationsdate;

    /** The Daily general operations fields. */
    private TransferDailyGeneralOperationsFieldsResponse dailyGeneralOperationsFields;

    /** The Liquidation data. */
    private TransferLiquidationDataResponse liquidationData;

    /** The Settlement concepts. */
    private List<TransferSettlementConceptResponse> settlementConcepts;

}
