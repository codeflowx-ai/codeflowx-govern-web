package es.santander.esponboapf.domain.expread.document;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DocumentInfoDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Document information indicating its type, name, status, reason for rejection.")
// Document type info Dto
public class DocumentTypeInfoDto {

    /** The doc type code. */
    // Doc type code
    @Schema(description = "Document type identifier", example = "1")
    private Integer docTypeCode;

    /** The doc type name. */
    // Doc type name
    @Schema(description = "Document type name", example = "Evidencia de actividad")
    private String docTypeName;

    /** The mandatory list. */
    // Mandotory list
    @Schema(description = "List of mandatory documents", example = "[]")
    private List<DocumentInfoDto> mandatoryList;

    /** The choose one list. */
    // Choose one list
    @Schema(description = "List of documents where holder has to pick one", example = "[]")
    private List<DocumentInfoDto> chooseOneList;

}
