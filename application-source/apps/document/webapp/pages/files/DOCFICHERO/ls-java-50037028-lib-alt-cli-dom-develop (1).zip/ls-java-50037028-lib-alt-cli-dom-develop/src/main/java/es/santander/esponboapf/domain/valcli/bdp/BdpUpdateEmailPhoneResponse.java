package es.santander.esponboapf.domain.valcli.bdp;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpUpdateEmailPhoneResponse.
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
// BdpUpdateEmailPhoneResponse
public class BdpUpdateEmailPhoneResponse {

    /** The codigops. */
    // Codigo ps
    @Schema(description = "Code PS", example = "[\"PS0013\"]")
    private List<String> codigops;

    /** The codperso. */
    // Codperso
    @Schema(description = "Code person", example = "[123456789]")
    private List<Integer> codperso;

    /** The retorno. */
    // Retorno
    @Schema(description = "Trx Retorno", example = "08")
    private String retorno;

    /** The retorno 2. */
    // Retorno 2
    @Schema(description = "Trx Return2 value", example = "[\"08\"]")
    private List<String> retorno2;

    /** The rutina. */
    // Rutina
    @Schema(description = "Validation routine code", example = "[\"ITF00793\"]")
    private List<String> rutina;

    /** The tipperso. */
    // Tipperso
    @Schema(description = "Value corresponding to type of person (f = physical, j = legal)", example = "[\"F\"]")
    private List<String> tipperso;

}
