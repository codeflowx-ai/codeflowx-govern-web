/**
 * Self.
 *
 * @return the holder control change dto. holder control change dto builder impl
 */
package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Instantiates a new holder control change dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@Schema(description = "Information to change a holder control change.",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"holderCode\":341,\"controlProcessCode\":1,\"stepStateCode\":\"P\"}")
public class HolderControlChangeDto {

    /**
     * The dossier id.
     * <p>
     * Unique dossier identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(description = "Unique dossier identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID dossierId;

    /**
     * The dossier code.
     * <p>
     * Internal dossier code. Used by backoffice services. Null otherwise. E.g.: 1
     */
    @Schema(description = "Internal dossier code. Used by backoffice services. Null otherwise.",
            example = "1")
    private Long dossierCode;

    /**
     * The holder id.
     * <p>
     * Unique holder identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(description = "Unique holder identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /**
     * The holder code.
     * <p>
     * Internal holder code. Used by backoffice services. Null otherwise. E.g.: 1
     */
    @Schema(description = "Internal holder code. Used by backoffice services. Null otherwise.",
            example = "1")
    private Long holderCode;

    /**
     * The control process code.
     *
     * E.g: 1
     */
    @Schema( maxLength = 1, description = "Process identifier", example = "1")
    @NotNull
    private Long controlProcessCode;

    /**
     * The step state code.
     *
     * E.g: P
     */
    @Schema( maxLength = 1, description = "Process state identifier", example = "P")
    @NotNull
    private String stepStateCode;
}
