package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpTinRequest.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BdpTinRequest {

    /** The person. */
    private PersonTinDto person;

}