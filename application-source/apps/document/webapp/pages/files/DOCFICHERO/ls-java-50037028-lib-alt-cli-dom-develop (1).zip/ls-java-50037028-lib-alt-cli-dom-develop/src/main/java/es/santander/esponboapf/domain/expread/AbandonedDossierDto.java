package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.UUID;

/**
 * The Class AbandonedDossierDto.
 */
// Constructors
@Data
@AllArgsConstructor
@NoArgsConstructor
// Builder
@Builder
// Abandoned dossier dto
public class AbandonedDossierDto {

    /** The dossier id. */
    // Dossier id
    @NotNull
    @Schema(description = "Uuid of the dossier, it will be identified with the dossier in the services.",
            example = "3f46a7d3-6fe8-4ccf-82e8-8cc9ca211c8c")
    private UUID dossierId;

    /** The holder id. */
    // Holder id
    @NotNull
    @Schema(description = "Unique uuid identifier of the holder.",
            example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private UUID holderId;
}
