package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.UUID;

/**
 * The Class Holder.
 */

/**
 * Instantiates a new audit holder.
 */
@NoArgsConstructor
@Data
@Schema(description = "Dto with information to be saved as audit for a dossier and holder",
        example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\", "
                + "\"dossierId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\"}")
// Holder audit data object
public class HolderAuditDto {

    /**
     * The holder id.
     *
     */
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /**
     * The dossier id.
     *
     * Unique dossier identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     *
     */
    @Schema(description = "Unique dossier identifier. Used by onboarding services.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID dossierId;

}
