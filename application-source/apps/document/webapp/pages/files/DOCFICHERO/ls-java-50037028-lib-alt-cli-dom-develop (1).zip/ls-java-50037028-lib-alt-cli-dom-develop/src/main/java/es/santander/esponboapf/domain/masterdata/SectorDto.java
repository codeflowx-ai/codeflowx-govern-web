package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new sector dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Sector performed according to occupation", 
example = "{\"sectorCode\":\"A\",\"sectorName\":\"Industria Textil\"}")
public class SectorDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4658608548432563996L;

    /**
     * The sector code.
     *
     * E.g.: A
     */
    @Schema(description = "code identifying a sector", example = "A")
    private String sectorCode;

    /**
     * The sector name.
     *
     * E.g.: 'Textile industry'
     */
    @Schema(description = "description of the occupational sector", example = "Industria Textil")
    private String sectorName;

}
