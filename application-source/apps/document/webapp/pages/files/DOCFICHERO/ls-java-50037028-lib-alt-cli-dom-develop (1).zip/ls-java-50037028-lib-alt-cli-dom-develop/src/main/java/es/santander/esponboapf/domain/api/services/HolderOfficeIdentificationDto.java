package es.santander.esponboapf.domain.api.services;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder office identification dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Holder office identification dto
public class HolderOfficeIdentificationDto {

    /**
     * The Codpers.
     */
    // Codpers
    // Withou F
    @Schema(description = "Person code of the holder without its person type", example = "123456789",
            requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank
    @Size(max = 9)
    private String codpers;

    /**
     * The Pex.
     */
    // Pex number
    @Schema(description = "PEX number identifying the office operation", example = "12345678909876543210",
            requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank
    @Size(max = 20)
    private String pex;

}
