package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * BranchLocatorOfficeCoordinates
 *
 * The type Branch locator office coordinates.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchLocatorOfficeCoordinates {

    /** The Latitude. */
    private Double latitude;

    /** The Longitude. */
    private Double longitude;

}
