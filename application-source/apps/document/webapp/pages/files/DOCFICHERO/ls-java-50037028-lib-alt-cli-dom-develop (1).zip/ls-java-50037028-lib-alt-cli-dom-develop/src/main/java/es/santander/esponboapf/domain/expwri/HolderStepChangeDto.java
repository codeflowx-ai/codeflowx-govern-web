package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class HolderStepChangeDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Information to change a holder step state.",
        example = "{\"stepCode\":1,\"stepState\":\"P\",\"increaseRejection\":true,"
                + "\"allDocsRec\":true,\"indOffice\":true}")
@SuperBuilder
public class HolderStepChangeDto extends UniversalHolder {

    /**
     * The step code.
     * <p>
     * Code of the step which will be updated.
     * E.g.: 1
     */
    @Schema(description = "Code of the step which will be updated.", example = "1")
    @NotNull
    private int stepCode;

    /**
     * The step state.
     * <p>
     * New state for the step.
     * E.g.: 'P', 'R', 'V'
     */
    @Schema(description = "New state for the step.", example = "P")
    @Size(max = 1)
    @NotBlank
    private String stepState;

    /**
     * The increase rejection.
     * <p>
     * Flag to increase the number or rejections.
     * E.g.: true
     */
    @Schema(description = "Flag to increase the number or rejections.", example = "true")
    private Boolean increaseRejection;
    
    /**
     * The all documents REC.
     *
     * Flag to indicate if all documents are REC.
     * E.g.: true
     */
    @Schema(description = "Flag to increase the number or rejections.", example = "true")
    private Boolean allDocsRec;

    /**
     * The Ind office.
     */
    @Schema(description = "Flag to indicate if action has been done in office.", example = "true")
    private Boolean indOffice;

}
