package es.santander.esponboapf.domain.expread;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class TransferDetailsDto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransferDetailsDto {

    /** The bban. */
    @Schema(description = "Transfer code", example = "58477")
    private Long transferCode;

    /** The transfer state code. */
    @Schema(description = "Transfer state code", example = "V")
    private String transferStateCode;

    /** The payer name. */
    @Schema(description = "Payer name", example = "Jorge Sanz")
    private String payerName;

    /** The person identifier. */
    @Schema(description = "Person identifier", example = "F12856985")
    private String personIdentifier;

    @Schema(description = "Beneficiary name", example = "Juan Cuesta")
    private String beneficiaryName;

    /** The payer iban. */
    @Schema(description = "Payer iban", example = "ES1600495525542210029639")
    private String payerIban;

    /** The origin country payment. */
    @Schema(description = "Origin country payment", example = "ES")
    private String originCountryPayment;

    /** The origin country payment name. */
    @Schema(description = "Origin country payment name", example = "España")
    private String originCountryPaymentName;

    /** The is country allowed. */
    @Schema(description = "Is country allowed", example = "true")
    private Boolean isCountryAllowed;

    /** The payment date. */
    @Schema(description = "Payment date", example = "2023-09-06")
    private LocalDate paymentDate;

    /** The transfer amount. */
    @Schema(description = "Transfer amount", example = "0.10")
    private Double transferAmount;

    /** The currency. */
    @Schema(description = "Transfer amount", example = "EUR")
    private String currency;

    /** The payment concept. */
    @Schema(description = "Payment concept", example = "6599")
    private String paymentConcept;

    /** The result fraud. */
    @Schema(description = "Result fraud", example = "OK")
    private String resultFraud;

}
