package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RequirementsIncomingTransferDto.
 */
// RequirementsIncomingTransferDto
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RequirementsIncomingTransferDto {

    /** The result. */
    @Schema(description = "Indicates whether the holder meets the requirements for incoming transfer identification.",
            example = "true")
    private boolean result;

    /** The transfer data. */
    private IncomingTransferInfoDto transferData;

}
