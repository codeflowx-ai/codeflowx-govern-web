package es.santander.esponboapf.domain.expread.process;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder process details dto.
 */
//The class HolderProcessDto
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderProcessDto {

    /**
     * The Holder code.
     */
    private Long holderCode;

    /**
     * The Processes.
     */
    private List<ProcessDetailsDto> processes;

}
