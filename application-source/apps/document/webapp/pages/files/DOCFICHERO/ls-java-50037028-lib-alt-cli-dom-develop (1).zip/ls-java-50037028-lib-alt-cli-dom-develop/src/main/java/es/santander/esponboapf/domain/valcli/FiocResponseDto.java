package es.santander.esponboapf.domain.valcli;

import java.util.UUID;

import javax.validation.constraints.Pattern;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FiocResponseDto.
 */
//The class FiocResponseDto
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder(toBuilder = true)
public class FiocResponseDto {

    /** The holder id. */
    private UUID holderId;

    /** The gn id. */
    @XssValid
    private String gnId;
    
    /** The gn id. */
    @XssValid
    private String gnIdImp;

    /** The segmentacion. */
    @Pattern(regexp = "^[A-Z][0-9]$")
    private String segmentacion;
}
