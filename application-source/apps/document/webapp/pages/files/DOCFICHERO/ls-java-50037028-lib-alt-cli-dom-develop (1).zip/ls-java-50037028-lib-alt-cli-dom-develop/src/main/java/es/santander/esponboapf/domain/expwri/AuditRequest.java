package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;
import java.util.UUID;

/**
 * The type Audit request.
 */
@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class AuditRequest {

    /**
     * The holder id.
     * <p>
     * Unique holder identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(description = "Unique holder identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /**
     * The dossier code.
     * <p>
     * Internal dossier code. Used by backoffice services. Null otherwise. E.g.: 1
     */
    @Schema(description = "Internal dossier code. Used by backoffice services. Null otherwise.", example = "1")
    private Long dossierCode;

    /**
     * The dossier id.
     * <p>
     * Unique dossier identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(description = "Unique dossier identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID dossierId;

    /** The holder code. */
    // Holder code
    @Schema(description = "Unique holder code.", example = "345")
    private Long holderCode;


    /** The Action code. */
    // The action code
    @Schema(description = "The action performed.", example = "12")
    private Integer actionCode;

    /** The actor. */
    // Actor
    @Schema(maxLength = 100,
            description = "The name of the user who performed the action on the dossier.", example = "user1")
    @Size(max = 100)
    private String actor;

    /** The field. */
    // Field
    @Schema(maxLength = 50, description = "Field over which the action was performed.", example = "ip")
    @Size(max = 50)
    private String processName;

    // to help the action
    /** The notes. */
    @Schema(maxLength = 2000, description = "Some notes about the action.",
            example = "Se han registrado los datos de ocupacion")
    private String notes;

}
