package es.santander.esponboapf.domain.expread.search;

import com.fasterxml.jackson.annotation.JsonFormat;
import es.santander.esponboapf.domain.util.OwaspValidatorsEnum;
import es.santander.esponboapf.domain.validation.annotations.IdDocumentNumber;
import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;

/**
 * The type Dossier filter dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Class for applying filters for dossier searching
public class DossierFilterDto {

    /**
     * The Dossier code.
     */
    // Dossier code
    @Schema(description = "Dossier reference number", example = "16")
    private Integer dossierCode;

    /**
     * The Holder person code.
     */
    // Holder person code
    @Schema(description = "Holder person code without the letter", example = "12345678")
    @XssValid(pattern = OwaspValidatorsEnum.NUMBER)
    private String holderPersonCode;

    /**
     * The Holder identity number.
     */
    // Holder identity number
    @Schema(description = "Holder identity number", example = "11111111H")
    @IdDocumentNumber
    private String holderIdentityNumber;

    /**
     * The Start date.
     */
    // Start date
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    @Schema(description = "Start date to filter", pattern = "dd/MM/yyyy", example = "18/11/2021")
    private LocalDate startDate;

    /**
     * The End date.
     */
    // End date
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    @Schema(description = "End date to filter", pattern = "dd/MM/yyyy", example = "18/11/2021")
    private LocalDate endDate;

    /**
     * The Campaign.
     */
    // Campaign
    @Schema(description = "Number identifying an campaign", example = "221")
    private Integer campaign;

    /**
     * The Office.
     */
    // Office
    @Schema(description = "Dossier office code", example = "0049")
    @XssValid(pattern = OwaspValidatorsEnum.NUMBER)
    private String office;

    /**
     * The Status.
     */
    // Status list
    @Schema(description = "List of states to find")
    private List<DossierFilterStateDto> state;

    /**
     * The identification code
     */
    // Identification code
    @Schema(description = "Identification of the holders to filter", example = "1")
    private Integer identificationCode;

    /**
     * The identification state code
     */
    // Identification state code
    @Schema(description = "Identification state of the holders to filter", example = "V")
    private String identificationStateCode;

    /**
     * The Page.
     */
    // Page
    @Schema(description = "Page number desired", example = "1")
    private Integer page;

    /**
     * The Size.
     */
    // Size
    @Schema(description = "Size of the page number, the default size is 7", example = "10")
    private Integer size;

    /**
     * The Sort.
     */
    // Sort
    @Schema(description = "Sort type applied")
    @Valid
    private List<DossierFilterSortingDto> sort;

}
