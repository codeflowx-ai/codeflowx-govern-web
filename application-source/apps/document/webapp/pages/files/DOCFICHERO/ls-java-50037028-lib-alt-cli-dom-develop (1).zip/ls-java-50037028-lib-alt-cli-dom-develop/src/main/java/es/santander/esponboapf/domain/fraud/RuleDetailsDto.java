package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Rule details dto.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
// Rule details dto
public class RuleDetailsDto {

    /**
     * The Holder info.
     */
    // Holder information
    @Schema(description = "Information about the holder.", example = "Titular 1 NIF: 12216346346X")
    private String holderInfo;

    /**
     * The Rule info.
     */
    // Rule information
    @Schema(description = "Confirm rules information.",
            example = "GF3_Q400000I: mismo email que una solicitud INCONGRUENTE")
    private String ruleInfo;

    /**
     * The Severity.
     */
    // Severity
    @Schema(description = "Degree of severity of the rule confirms.", example = "Muy alta")
    private String severity;

}
