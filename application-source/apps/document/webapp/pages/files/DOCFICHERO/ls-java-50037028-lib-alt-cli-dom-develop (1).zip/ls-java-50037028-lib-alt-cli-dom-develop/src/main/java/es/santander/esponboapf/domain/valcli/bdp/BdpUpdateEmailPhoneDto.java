package es.santander.esponboapf.domain.valcli.bdp;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpUpdateEmailPhoneDto.
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BdpUpdateEmailPhoneDto {

    /** The company. */
    private String company;

    /** The contact. */
    private List<String> contact;

    /** The contact time from. */
    private List<String> contactTimeFrom;

    /** The contact time until. */
    private List<String> contactTimeUntil;

    /** The origin change auth. */
    private List<String> originChangeAuth;

    /** The preferred indicator. */
    private List<String> preferredIndicator;

    /** The sequential number device. */
    private List<Integer> sequentialNumberDevice;

    /** The type of device. */
    private List<String> typeOfDevice;

}
