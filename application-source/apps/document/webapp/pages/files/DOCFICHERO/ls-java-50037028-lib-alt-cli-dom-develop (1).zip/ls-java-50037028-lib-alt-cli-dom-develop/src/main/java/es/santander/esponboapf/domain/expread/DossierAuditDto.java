package es.santander.esponboapf.domain.expread;

import java.time.LocalDateTime;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier audit dto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder({"auditCode", "registerDate", "username", "action", "holderIdentityNumber", "holder", "channel",
    "notes"})
// Dossier audit dto
public class DossierAuditDto {

    /**
     * The Audit code.
     */
    // Audit code
    private Long auditCode;

    /**
     * The Register date.
     */
    // Register date
    @JsonFormat(pattern = "dd/MM/yyyy HH:mm:ss", shape = JsonFormat.Shape.STRING)
    private LocalDateTime registerDate;

    /**
     * The Username.
     */
    // Username
    private String username;

    /**
     * The Action.
     */
    // Action
    private String action;

    /**
     * The Holder identity number.
     */
    // Holder identity number
    private String holderIdentityNumber;

    /**
     * The Holder.
     */
    // Holder name
    @JsonIgnore
    private String holderName;

    /**
     * The Holder surname 1.
     */
    // Hpñder surname 1
    @JsonIgnore
    private String holderSurname1;

    /**
     * The Holder surname 2.
     */
    // Holder surname 2
    @JsonIgnore
    private String holderSurname2;

    /** The channel. */
    private String channel;

    /**
     * The Notes.
     */
    // Notes
    private String notes;

    /**
     * The Holder.
     */
    // Holder
    private String holder;

    /**
     * The holder
     *
     * @return the holder full name
     */
    @JsonProperty("holder")
    public String getHolderFullName() {

        // If holder is already defined, return it
        if (StringUtils.isNotEmpty(this.holder)) {
            return this.holder;
        }

        // Concat the name and surnames
        String fullName = Stream.of(this.holderName,
                        this.holderSurname1,
                        this.holderSurname2)
                .filter(StringUtils::isNotEmpty)
                .collect(Collectors.joining(" "));
        return StringUtils.isEmpty(fullName)? null : fullName;
    }

}
