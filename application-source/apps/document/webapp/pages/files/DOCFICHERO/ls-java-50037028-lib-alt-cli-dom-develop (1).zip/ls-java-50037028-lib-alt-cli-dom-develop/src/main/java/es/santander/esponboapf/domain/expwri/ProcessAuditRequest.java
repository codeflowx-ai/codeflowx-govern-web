package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class ProcessAuditRequest.
 */
@NoArgsConstructor
@Data
@Schema(description = "Request dto with information to be saved as audit for a process",
        example = "{\"processName\":\"Digitalizacion\"}")
@SuperBuilder
@AllArgsConstructor
// Process Audit request object
public class ProcessAuditRequest {

    /** The process name. */
    //Process name
    @Schema( description = "Name of the process.", example = "AUTOMATIC CANCELLATION DOSSIER")
    @NotEmpty
    private String processName;

    /** The result. */
    // Holder code
    @NotEmpty
    @Schema( description = "Result of the execution of the process", example = "345")
    private String result;

}
