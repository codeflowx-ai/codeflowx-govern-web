package es.santander.esponboapf.domain.util;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.regex.Pattern;

import com.santander.darwin.core.exceptions.BadRequestDarwinException;
import com.santander.darwin.core.exceptions.HttpBaseDarwinException;
import com.santander.darwin.core.exceptions.InternalServerErrorDarwinException;

/**
 * The Class HagcliUtils.
 */
@SuppressWarnings("rawtypes")
public final class HagcliUtils {

    /** The Constant DATE_FORMAT. */
    public static final String DATE_FORMAT = "dd/MM/yyyy";

    // XSS PATTERNS
    /** The Constant XSS_PATTERNS */
    private static final List<Pattern> XSS_PATTERNS = List.of(
            // Avoid script tags
            Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
            // Avoid expressions in the form of src ( ' and " )
            Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // delete a single </script> tag
            Pattern.compile("</script>", Pattern.CASE_INSENSITIVE),
            // delete a single <script ...> tag
            Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // Avoid eval(...) formal expressions
            Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // avoid expression(...) expressions
            Pattern.compile("expression\\((.*?)\\)",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
            // avoid javascript: expressions
            Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
            // avoid vbscript: expressions
            Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
            // Avoid οnlοad = expression
            Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL));

    /**
     * Instantiates a new hagcli utils.
     */
    private HagcliUtils() {
    }

    /**
     * Checks if is string empty.
     *
     * @param input the input
     * @return true, if is string empty
     */
    public static boolean isStringEmpty(String input) {
        return input == null || input.isEmpty();
    }

    /**
     * Checks if is string not empty.
     *
     * @param input the input
     * @return true, if is string not empty
     */
    public static boolean isStringNotEmpty(String input) {
        return input != null && !input.isEmpty();
    }

    /**
     * Checks if is map empty.
     *
     * @param input the input
     * @return true, if is map empty
     */
    public static boolean isMapEmpty(Map input) {
        return input == null || input.isEmpty();
    }

    /**
     * Checks if is map not empty.
     *
     * @param input the input
     * @return true, if is map not empty
     */
    public static boolean isMapNotEmpty(Map input) {
        return input != null && !input.isEmpty();
    }

    /**
     * Checks if is list empty.
     *
     * @param input the input
     * @return true, if is list empty
     */
    public static boolean isListEmpty(List input) {
        return input == null || input.isEmpty();
    }

    /**
     * Checks if is list not empty.
     *
     * @param input the input
     * @return true, if is list not empty
     */
    public static boolean isListNotEmpty(List input) {
        return input != null && !input.isEmpty();
    }

    /**
     * Checks if is sets the empty.
     *
     * @param input the input
     * @return true, if is sets the empty
     */
    public static boolean isSetEmpty(Set input) {
        return input == null || input.isEmpty();
    }

    /**
     * Checks if is sets the not empty.
     *
     * @param input the input
     * @return true, if is sets the not empty
     */
    public static boolean isSetNotEmpty(Set input) {
        return input != null && !input.isEmpty();
    }

    /**
     * Predicate.
     *
     * @return the predicate<? super throwable>
     */
    public static Predicate<Throwable> excPredicate() {
        return err -> err instanceof BadRequestDarwinException || err instanceof InternalServerErrorDarwinException
                || err instanceof HttpBaseDarwinException;
    }

    /**
     * Validate xss.
     *
     * @param value the value
     * @return true, if successful
     */
    public static boolean isXssValid(String value) {
        if (value == null) {
            return true;
        }
        return XSS_PATTERNS.stream().noneMatch(scriptPattern -> scriptPattern.matcher(value).matches());
    }

    /**
     * Clean xss.
     *
     * @param value the value
     * @return the string
     */
    public static String cleanXss(String value) {
        if (value != null) {
            for (Pattern pattern : XSS_PATTERNS) {
                value = pattern.matcher(value).replaceAll("");
            }
        }
        return value;

    }

    /**
     * Gets the file extension.
     *
     * @param fileName the file name
     * @return the file extension
     * @throws IllegalArgumentException the illegal argument exception
     */
    public static String getFileExtension(final String fileName) throws IllegalArgumentException {
        if (fileName == null) {
            return null;
        }

        var tempFileName = fileName.replace('\\', '/');
        final int baseNameIndex = tempFileName.lastIndexOf('/');
        var baseNameAndExt =
                Optional.of(baseNameIndex).filter(ind -> ind != -1).map(ind -> tempFileName.substring(ind + 1))
                        .orElse(tempFileName);
        final int extIndex = baseNameAndExt.lastIndexOf('.');
        return Optional.of(extIndex).filter(ind -> ind != -1).map(ind -> baseNameAndExt.substring(ind + 1))
                .orElse("");

    }

    /**
     * Gets the file basename.
     *
     * @param fileName the file name
     * @return the file basename
     * @throws IllegalArgumentException the illegal argument exception
     */
    public static String getFileBasename(final String fileName) throws IllegalArgumentException {
        if (fileName == null) {
            return null;
        }
        var tempFileName = fileName.replace('\\', '/');
        final int baseNameIndex = tempFileName.lastIndexOf('/');
        var baseNameAndExt =
                Optional.of(baseNameIndex).filter(ind -> ind != -1).map(ind -> tempFileName.substring(ind + 1))
                .orElse(tempFileName);
        final int extIndex = baseNameAndExt.lastIndexOf('.');
        return Optional.of(extIndex).filter(ind -> ind != -1).map(ind -> baseNameAndExt.substring(0, ind))
                .orElse(baseNameAndExt);
    }

}
