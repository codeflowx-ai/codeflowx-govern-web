package es.santander.esponboapf.domain.corresp;

import java.util.UUID;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class OTPValRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@Schema(description = "Mandatory information to validate a holder OTP key.", 
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"key\":\"X666X666\"}")
public class OTPValRequest {

    /**
     * The holder id.
     *
     * The holder's identifier.
     */
    @Schema(maxLength = 100, description = "Unique holder identifier. ",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    // the key should be case sensitive
    // in case of failing, there are retries
    /**
     * The key.
     *
     * The SMS key.
     */
    @Schema(maxLength = 8, description = "OTP key received via SMS", example = "X666X666")
    @XssValid
    @NotBlank
    private String key;

}
