package es.santander.esponboapf.domain.expread.document;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder document type dto.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
// Holder document type
public class HolderDocumentTypeDto {

    /**
     * The Doc type code.
     */
    // Document type code
    @Schema(description = "Document type identifier", example = "1")
    private Integer docTypeCode;

    /**
     * The Doc type name.
     */
    // Document type name
    @Schema(description = "Document type name", example = "Evidencia de actividad")
    private String docTypeName;

    /**
     * The Mandatory list.
     */
    // Mandatory list
    @Schema(description = "List of mandatory documents")
    private List<HolderPendingDocumentDataDto> mandatoryList;

    /**
     * The Choose one list.
     */
    // Choose one list
    @Schema(description = "List of documents where holder has to pick one")
    private List<HolderPendingDocumentDataDto> chooseOneList;

}
