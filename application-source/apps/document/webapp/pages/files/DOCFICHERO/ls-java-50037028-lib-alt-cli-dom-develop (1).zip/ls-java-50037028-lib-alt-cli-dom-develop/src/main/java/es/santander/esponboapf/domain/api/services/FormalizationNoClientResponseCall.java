package es.santander.esponboapf.domain.api.services;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


/**
 * The Class FormalizationNoClientResponseCall.
 */
//Constructors
@NoArgsConstructor
@Data
@Schema(description = "Response from external service for formalization no client from consumpt.",
        example = "{\"returnCodeStatus\": {\"returnCode\": \"01\"}}")
@SuperBuilder
public class FormalizationNoClientResponseCall{
    
    /** The other cancel reason. */
    // ReturnCodeStatus
    @Schema(description = "Return Code Status", example = "01")
    private FormalizationNoClientResponseDto returnCodeStatus;

}
