package es.santander.esponboapf.domain.docmanager.signrecord;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UploadDocumentRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Request for service generate pdf contract.",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"contractCode\":1}")
public class ContractPdfInDto {

    /**
     * The holder id.
     *
     * Unique holder's identifier.
     * E.g.: '1abe4f7c-d843-477d-b1c8-d181410c1a47'
     */
    @Schema(description = "Unique holder's identifier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    @NotNull
    private UUID holderId;

    /**
     * The contract code
     *
     * Number identifying the contract code
     * E.g.: '1'
     */
    @Schema(description = "Number identifying the contract code", example = "1")
    @NotNull
    private Integer contractCode;

   
}
