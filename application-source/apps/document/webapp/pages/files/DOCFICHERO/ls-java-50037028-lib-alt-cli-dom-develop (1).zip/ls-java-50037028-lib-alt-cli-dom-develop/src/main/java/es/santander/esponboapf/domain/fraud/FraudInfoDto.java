package es.santander.esponboapf.domain.fraud;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Fraud info dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Fraud info dto
public class FraudInfoDto {

    /**
     * The Result.
     */
    // Query result
    @Schema(description = "Indicates whether the fraud report has been run before.",
            example = "true")
    private Boolean result;

    /**
     * The Rules details.
     */
    // Rule details
    @Schema(description = "List of confirmation rules of the dossier.", example = "[]")
    private List<RuleDetailsDto> rulesDetails;

    /**
     * The Check confirm.
     */
    // Check confirm
    @Schema(description = "Confirm validation", example = "true")
    private boolean checkConfirm;

    /** The status. */
    @Schema(description = "List of status rules.", example = "[]")
    private List<StatusDto> status;

}
