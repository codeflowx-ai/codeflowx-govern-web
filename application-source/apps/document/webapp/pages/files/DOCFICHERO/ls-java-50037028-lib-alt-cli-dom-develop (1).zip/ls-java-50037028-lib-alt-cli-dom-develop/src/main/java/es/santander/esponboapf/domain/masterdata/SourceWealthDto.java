package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SourceWealthDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "source of wealth for the completion of tax information", 
example = "{\"sourceWealthCode\":1,\"sourceWealthName\":\"Herencia familiar\",\"isOther\":true}")
public class SourceWealthDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -2426116976255370094L;

    /**
     * The source wealth code.
     *
     * E.g.: 1
     */
    @Schema(description = "number identifying a source of wealth", example = "1")
    private Integer sourceWealthCode;

    /**
     * The source wealth name.
     *
     * E.g.: 'Family Inheritance'
     */
    @Schema(maxLength = 50, description = "source of wealth description", example = "Herencia familiar")
    private String sourceWealthName;

    /**
     * The is other.
     *
     * E.g.: true
     */
    @Schema(description = "It will be true if 'other description' is required for the screen", example = "true")
    private Boolean isOther;
}
