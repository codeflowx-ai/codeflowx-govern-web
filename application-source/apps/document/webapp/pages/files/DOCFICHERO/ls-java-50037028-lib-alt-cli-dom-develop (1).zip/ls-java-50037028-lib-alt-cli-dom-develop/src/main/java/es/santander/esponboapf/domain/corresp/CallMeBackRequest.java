package es.santander.esponboapf.domain.corresp;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CallMeBackRequest.
 */
//The class CallMeBackRequest
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information necessary to receive a call from the bank.")
public class CallMeBackRequest {

    /** The phone. */
    //Phone
    @Schema(description = "Telephone number where to receive the call.", example = "612345698")
    @NotNull
    private String phone;

    /** The scheduled time. */
    @Schema(description = "Scheduled time.", example = "2020-02-14 12:47:32")
    @Builder.Default
    private String scheduledTime = "";

    /** The attach data. */
    @Schema(description = "Information attach data.")
    private AttachDataDto attachData;

}
