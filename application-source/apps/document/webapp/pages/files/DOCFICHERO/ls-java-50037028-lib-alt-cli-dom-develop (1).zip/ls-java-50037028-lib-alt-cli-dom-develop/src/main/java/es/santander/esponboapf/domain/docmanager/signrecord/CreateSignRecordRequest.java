package es.santander.esponboapf.domain.docmanager.signrecord;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

import java.util.List;

/**
 * The Class CreateSignExp.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
@JsonTypeName("createSignExp")
// Create sign record request
public class CreateSignRecordRequest {

    /** The company. */
    // Company
    @Builder.Default
    private String company = "0049";

    /** The type reference. */
    // Type reference
    @Builder.Default
    private String typeReference = "APERTURA CUENTA INTERNET";

    /** The type exp. */
    // Type exp
    @Builder.Default
    private String typeExp = "FIRMAS";

    /** The desc exp. */
    // Desc exp
    @Builder.Default
    private String descExp = "FIRMA DIGITAL";

    /** The centre. */
    // Centre
    @Builder.Default
    private String centre = "0282";

    /** The reference. */
    // Reference
    private String reference;

    /** The channel exp. */
    // Channel
    @Builder.Default
    private String channelExp = "INT";

    /** The docs. */
    // Document list
    @Singular
    private List<FilenetDocSign> docs;

}
