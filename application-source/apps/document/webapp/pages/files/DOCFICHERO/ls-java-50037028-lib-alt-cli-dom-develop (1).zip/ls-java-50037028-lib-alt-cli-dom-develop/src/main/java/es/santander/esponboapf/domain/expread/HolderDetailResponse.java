package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Instantiates a new holder detail response.
 */

@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information about holders")
// Holder detail response
public class HolderDetailResponse {

    /**
     * List with the holders of a dossier
     *
     */
    // Holder detail list
    @Schema(description = "List of holders", example = "true")
    private List<HolderDetailDto> listHolderDetail;

    /**
     *  All Complete signature. 
     *  Show if all holders signed the dossier
     * */
    // All completed signature flag
    @Schema(description = "All holders signed the dossier", example = "true")
    private boolean allCompletedSignature;

}
