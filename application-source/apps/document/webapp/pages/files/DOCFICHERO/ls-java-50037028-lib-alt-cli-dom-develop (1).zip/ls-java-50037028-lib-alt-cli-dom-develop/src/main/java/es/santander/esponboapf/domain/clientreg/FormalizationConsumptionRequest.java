package es.santander.esponboapf.domain.clientreg;

import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FormalizationConsumptionRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormalizationConsumptionRequest {

    /** The dossier id external. */
    // DossierIdExternal
    @Schema(description = "UUID identifying a dossier", example = "a451215b-946f-4ccf-a12f-5da8a2a48182")
    private String dossierIdExternal;

    /** The dossier code. */
    // DossierCode
    @Schema(description = "Dossier code", example = "505")
    private Long dossierCode;

    /** The dossier id. */
    @Schema(description = "Dossier id", example = "a451215b-946f-4ccf-a12f-5da8a2a48182")
    private UUID dossierId;

}
