package es.santander.esponboapf.domain.util;

/**
 * The Enum EsapiValidatorsEnum.
 */
public enum OwaspValidatorsEnum {

    /** The no. */
    NO("(.\\n)*"),

    /** The number. */
    NUMBER("^[0-9]+$"),

    /** The decimal. */
    DECIMAL("^[+-]?([0-9]+\\.?[0-9]*|\\.[0-9]+)$"),

    /** The Safe string. */
    SAFESTRING("^[.\\p{Alnum}\\p{Space}]{0,1024}$"),
    /** The Email. */
    EMAIL("^[A-Za-z0-9._%'-]+@[A-Za-z0-9.-]+\\.[a-zA-Z]{2,4}$"),

    /** The IP address. */
    IPADDRESS("^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"),

    /** The url. */
    URL("^(ht|f)tp(s?)\\:\\/\\/[0-9a-zA-Z]([-.\\w]*[0-9a-zA-Z])*(:(0-9)*)*(\\/?)([a-z"
            + "A-Z0-9\\-\\.\\?\\,\\:\\'\\/\\\\\\+=&;%\\$#_]*)?$"),

    /** The Credit card. */
    CREDITCARD("^(\\d{4}[- ]?){3}\\d{4}$"),

    /** The ssn. */
    SSN("^(?!000)([0-6]\\d{2}|7([0-6]\\d|7[012]))([ -]?)(?!00)\\d\\d\\3(?!0000)\\d{4}$"),

    /** The account name. */
    ACCOUNT_NAME("^[a-zA-Z0-9]{3,20}$"),

    /** The system command. */
    SYSTEM_COMMAND("^[a-zA-Z\\-\\/]{1,64}$"),

    /** The rolename. */
    ROLENAME("^[a-z]{1,20}$"),

    /** The redirect. */
    REDIRECT("^\\/test.*$"),

    /** The http scheme. */
    HTTP_SCHEME("^(http|https)$"),

    /** The http servername. */
    HTTP_SERVERNAME("^[a-zA-Z0-9_.\\-]*$"),

    /** The http parametername. */
    HTTP_PARAMETERNAME("^[a-zA-Z0-9_]{1,32}$"),

    /** The http parametervalue. */
    HTTP_PARAMETERVALUE("^[a-zA-Z0-9.\\-\\/+=@_ ]*$"),

    /** The http cookiename. */
    HTTP_COOKIENAME("^[a-zA-Z0-9\\-_]{1,32}$"),

    /** The http cookievalue. */
    HTTP_COOKIEVALUE("^[a-zA-Z0-9\\-\\/+=_ ]*$"),

    /** The http headername. */
    HTTP_HEADERNAME("^[a-zA-Z0-9\\-_]{1,32}$"),

    /** The http headervalue. */
    HTTP_HEADERVALUE("^[a-zA-Z0-9()\\-=\\*\\.\\?;,+\\/:&_ ]*$"),

    /** The http contextpath. */
    HTTP_CONTEXTPATH("^\\/?[a-zA-Z0-9.\\-\\/_]*$"),

    /** The http servletpath. */
    HTTP_SERVLETPATH("^[a-zA-Z0-9.\\-\\/_]*$"),

    /** The http path. */
    HTTP_PATH("^[a-zA-Z0-9.\\-_]*$"),

    /** The http querystring. */
    HTTP_QUERYSTRING("^[a-zA-Z0-9()\\-=\\*\\.\\?;,+\\/:&_ %]*$"),

    /** The http uri. */
    HTTP_URI("^[a-zA-Z0-9()\\-=\\*\\.\\?;,+\\/:&_ ]*$"),

    /** The http url. */
    HTTP_URL("^.*$"),

    /** The http jsessionid. */
    HTTP_JSESSIONID("^[A-Z0-9]{10,30}$"),

    /** The filename. */
    FILENAME("^[a-zA-Z0-9!@#$%^&{}\\[\\]()_+\\-=,.~'` ]{1,255}$"),

    /** The directoryname. */
    DIRECTORYNAME("^[a-zA-Z0-9:/\\\\!@#$%^&{}\\[\\]()_+\\-=,.~'` ]{1,255}$");

    /** The code. */
    private String pattern;

    /**
     * Instantiates a new esapi validators enum.
     *
     * @param pattern the pattern
     */
    OwaspValidatorsEnum(String pattern) {
        this.pattern = pattern;
    }

    /**
     * Gets the pattern.
     *
     * @return the pattern
     */
    public String getPattern() {
        return pattern;
    }

}
