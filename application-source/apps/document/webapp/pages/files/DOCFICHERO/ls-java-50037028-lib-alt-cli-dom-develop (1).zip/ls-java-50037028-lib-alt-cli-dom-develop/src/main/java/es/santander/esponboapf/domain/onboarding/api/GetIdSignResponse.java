package es.santander.esponboapf.domain.onboarding.api;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * GetIdSignResponse
 *
 * The Class GetIdSignResponse.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 * 
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// GetIdSignResponse
public class GetIdSignResponse {

    @Schema(description = "Id petición.", example = "100066655")
    private String idPeticion;

    @Schema(description = "URL.", example = "https://sanfirmas.pru.bsch/front/sign-docs/100066655")
    private String url;
}
