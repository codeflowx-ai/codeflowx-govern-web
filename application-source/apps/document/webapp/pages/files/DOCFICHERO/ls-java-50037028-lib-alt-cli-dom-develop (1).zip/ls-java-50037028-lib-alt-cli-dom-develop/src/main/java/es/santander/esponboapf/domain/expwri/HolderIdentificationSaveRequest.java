package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder identification dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderIdentificationSaveRequest {

    /** The holder id. */
    // The holder id
    @Schema(description = "Holder id", example = "9f0604e6-cd74-4bd0-a0db-24a7d054fd74")
    @NotNull
    private UUID holderId;

    /**
     * The identification code.
     */
    // Identification code
    @Schema(description = "Identification code", example = "1")
    private Integer identificationCode;

    /**
     * The origin.
     */
    // Origin
    @Schema(description = "If the identification is null, indicate the origin of the skip", example = "1")
    private Integer origin;

}
