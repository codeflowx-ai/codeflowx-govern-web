package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FilenetSigner.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
// Filenet signer
public class FilenetSigner {

    /** The location sign. */
    // Location sign
    private String locationSign;

    /** The order. */
    // Order
    @Builder.Default
    private int order = 1;

    /** The signed. */
    // Signed
    private String signed;

    /** The signer. */
    // Signer
    private FilenetSignerInfo signer;

}
