package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.UUID;


/**
 * The Class DossierPromotionalCodeDto.
 */
// Constructors
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DossierPromotionalCodeDto {

    /** The dossier id. */
    // Dossier id
    @NotNull
    @Schema(description = "Uuid of the dossier, it will be identified with the dossier in the services.",
            example = "3f46a7d3-6fe8-4ccf-82e8-8cc9ca211c8c")
    private UUID dossierId;


    /** The promotional code. */
    // PromotionalCode
    @NotNull
    @Schema(description = "Promotional code.",
            example = "536345634563")
    private String promotionalCode;
}
