package es.santander.esponboapf.domain.producttrans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UserDataUdsResponse.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDataUdsResponse {

    /** The uid. */
    private String uid;

    /** The realm. */
    private String realm;

    /** The attributes. */
    private AttributesUds attributes;

}
