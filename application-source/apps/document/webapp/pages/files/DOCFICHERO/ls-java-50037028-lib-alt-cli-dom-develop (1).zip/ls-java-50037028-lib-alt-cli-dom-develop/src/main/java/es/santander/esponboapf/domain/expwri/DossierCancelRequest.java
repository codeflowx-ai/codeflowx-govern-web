package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class DossierCancelRequest.
 */
// Constructors
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Required information to cancel the dossier.", example = "{\"cancelReasonCode\":1}")
@SuperBuilder
// Dossier Cancel request object
public class DossierCancelRequest extends UniversalDossier {

    // the dossier should have this code
    // in case of cancellation.
    /** The cancel reason code. */
    // Cancel reason code
    @Schema( description = "Cancellation reason identifier.", example = "1")
    @NotNull
    @Min(0)
    private Integer cancelReasonCode;

    /** The cancel reason text */
    // Cancel reason text
    @Schema( description = "Other cancel reason text.", example = "Text justifying the cancellation")
    private String cancelReasonText;

    /** The force cancel. */
    // Force cancel
    @Schema(
            description = "Force cancellation ignoring which user has it blocked (not usable by frontend right now)",
            example = "true")
    private Boolean forceCancel;

    /** The profile code */
    // Profile code
    @Schema( description = "Profile code of the user.", example = "1")
    private Integer profileCode;

    /** The send email. */
    @Schema( description = "Indicate if send email to the client", example = "true")
    private Boolean sendEmail;

}
