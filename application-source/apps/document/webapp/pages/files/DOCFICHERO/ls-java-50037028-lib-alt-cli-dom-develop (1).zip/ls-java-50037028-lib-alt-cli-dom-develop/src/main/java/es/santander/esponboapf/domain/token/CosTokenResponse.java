package es.santander.esponboapf.domain.token;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Cos token response.
 */
// CosTokenResponse
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CosTokenResponse {

    /** The jwt. */
    private String jwt;

}
