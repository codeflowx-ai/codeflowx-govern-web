package es.santander.esponboapf.domain.expwri.dossier.save;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * The type Save holder documents dto.
 */
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
// Save holder documents dto
public class SaveHolderDocumentsDto {

    /**
     * The Holder code.
     */
    // Holder code
    @NotNull
    private Long holderCode;

    /**
     * The Documents.
     */
    // Document list
    @Valid
    private List<SaveDocumentDto> documents;

}
