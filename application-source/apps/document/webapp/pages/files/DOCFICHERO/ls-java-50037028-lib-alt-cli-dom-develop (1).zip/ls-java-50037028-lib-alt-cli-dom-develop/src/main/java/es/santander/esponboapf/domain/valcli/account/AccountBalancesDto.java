package es.santander.esponboapf.domain.valcli.account;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class AccountBalancesDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// AccountBalancesDto
public class AccountBalancesDto {

    /** The accounts. */
    // Balance
    @Schema(description = "Balance", example = "")
    private BalancesAccountDto balance;

}
