package es.santander.esponboapf.domain.valcli;

import javax.validation.constraints.Pattern;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FiocSimpleRequest.
 *
 * Fioc simple note information.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Fioc simple note information", 
example = "{\"idSimple\":\"001\",\"valorSimple\":\"test\"}")
public class FiocSimpleDto {

    /**
     * The id simple.
     *
     * Fioc simple note id
     * E.g.: '001'
     */
    @Schema(maxLength = 3, description = "Fioc simple note id", example = "001")
    @Pattern(regexp = "^[0-9]{3}$")
    private String idSimple;

    /**
     * The valor simple.
     *
     * Fioc simple note value.
     * E.g.: 'test'
     */
    @Schema(maxLength = 50, description = "Fioc simple note value", example = "test")
    @XssValid
    private String valorSimple;

}
