package es.santander.esponboapf.domain.api.services;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.LocalDateTimeDeserializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class TransferIncomingResponse.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Information about a transfer incoming")
// TransferIncomingResponse
public class TransferIncomingResponse {

    /** The result. */
    // Result
    @Schema(description = "Result status. True if account activated, false if failed.", example = "true")
    private boolean result;

    /** The message. */
    @Schema(description = "Information about a transfer incoming process", example = """
                    {
              "code": "TD001",
              "description": "account´s activate with functional error"
            }
                    """)
    // Message
    private TransferIncomingMessageDto message;

    /** The iban. */
    // Iban
    @Schema(description = "IBAN", example = "ES26 0049 2594 6025 1500 0446")
    private String iban;

    /** The concept code. */
    // Concept code
    @Schema(description = "The last four digits of the holder's mobile number.", example = "2546")
    private String conceptCode;

    /** The date. */
    // Date
    @Schema(description = "Discharge date of the dossier plus 23 days.", example = "17/05/2023")
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDateTime date;

    /** The pending documentation. */
    // Pending documentation
    @Schema(description = "True if the holder has pending documentation to be attached and false if "
            + "the holder has no pending documentation to be attached.",
            example = "true")
    private boolean pendingDocumentation;

}
