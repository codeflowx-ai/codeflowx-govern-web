package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new holder ip address dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class HolderIpAddressDto {

    /** The holder id. */
    // holder id
    private UUID holderId;

    /** The ip address. */
    // IP address
    private String ipAddress;
}
