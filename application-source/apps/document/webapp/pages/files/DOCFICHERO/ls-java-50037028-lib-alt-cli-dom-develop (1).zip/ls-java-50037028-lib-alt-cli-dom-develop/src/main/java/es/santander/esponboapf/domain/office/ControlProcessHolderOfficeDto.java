package es.santander.esponboapf.domain.office;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Control process holder office dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ControlProcessHolderOfficeDto {

    /** The Process code. */
    private Long processCode;

    /** The Process name. */
    private String processName;

    /** The Status. */
    private Boolean completed;

    /** The num order. */
    private Integer order;

}
