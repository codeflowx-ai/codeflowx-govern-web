package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new address number response.
 */
// Constructors
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Final control response for address number", example = "{ \"numDomicilio\": \"1\"}")
@Builder
// Address number response
public class AddressNumberResponse {

    /** The result. */
    // Num domicilio
    @Schema(description = "address number indicator", example = "1")
    private String numDomicilio;

}
