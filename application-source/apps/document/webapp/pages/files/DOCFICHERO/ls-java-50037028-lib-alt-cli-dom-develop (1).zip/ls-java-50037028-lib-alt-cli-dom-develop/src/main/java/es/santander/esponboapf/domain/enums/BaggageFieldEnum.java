package es.santander.esponboapf.domain.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * The Enum BaggageFieldEnum.
 */
@AllArgsConstructor
@Getter
public enum BaggageFieldEnum {
    /** The profile. */
    PROFILE("x-hc-profile"),

    /** The request info. */
    REQUEST_INFO("x-hc-request-info");

    /** The header name. */
    private String headerName;

}
