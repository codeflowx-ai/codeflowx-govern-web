package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new save BDP info dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Holder's personal information.", 
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"valid\":true,\"notes\":\"Note about the step in the validation\","
        + "\"customerType\":\"F\",\"customerId\":\"56236987\",\"bondingCode\":7,"
        + "\"contractCmc\":\"004932987452369236\",\"stateCodeCmc\":\"A\",\"stateDescCmc\":\"Activo\","
        + "\"indPassword\":\"A\",\"alreadyCostumer\":true}")
public class SaveBDPInfoDto {
    /**
     * The holder id.
     *
     * Holder's identifier.
     */
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /**
     * The valid.
     *
     * If holder's information is valid.
     */
    @Schema(description = "If holder's information is valid.", example = "true")
    private boolean valid;

    /**
     * The notes.
     *
     * Information about every step in the validation process a holder goes through.
     */
    @Schema(description = "Information about every step in the validation process a holder goes through",
            example = "Note about the step in the validation")
    @XssValid
    private String notes;

    /**
     * The customer type.
     *
     * The type of person, natural (F) or legal (J)
     *
     * E.g: 'F', 'J'
     */
    @Schema(description = "The customer type.", example = "F")
    @Pattern(regexp = "^[FJ]{1}$")
    private String customerType;

    /**
     * The custome id.
     *
     * The physical person code in the entity.
     */
    @Schema(description = "The physical person code in the entity.", example = "56236987")
    @Pattern(regexp = "^([0-9]+)$")
    private String customerId;

    /**
     * The bonding code.
     *
     * E.g.: 8
     */
    @Schema(description = "The bonding code.", example = "7")
    private Integer bondingCode;

    /** The contract cmc. */
    @Schema(description = "The contract cmc", example = "004932987452369236")
    @Pattern(regexp = "^[0-9]{1}([0-9\\s]+)[0-9]{1}$")
    private String contractCmc;

    /** The state code cmc. */
    @Schema(description = "The state code cmc.", example = "A")
    @Size(max = 1)
    private String stateCodeCmc;

    /** The state desc cmc. */
    @Schema(description = "The state cmc description.", example = "Activo")
    @XssValid
    @Size(max = 30)
    private String stateDescCmc;

    /** The ind password. */
    @Schema(description = "The ind password.", example = "A")
    @Size(max = 1)
    private String indPassword;

    /** The already costumer. */
    @Schema(description = "If is already costumer.", example = "true")
    private Boolean alreadyCostumer;

}
