package es.santander.esponboapf.domain.expread;

import com.fasterxml.jackson.annotation.JsonInclude;
import es.santander.esponboapf.domain.docmanager.signrecord.ContractPdfDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Holder contract status dto.
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HolderContractStatusDto {

    /** The Result. */
    private Boolean result;

    /** The Sign exp id. */
    private String signExpId;

    /**
     * The Holder name.
     */
    private String name;

    /**
     * The Contracts.
     */
    private List<ContractPdfDto> contracts;

}
