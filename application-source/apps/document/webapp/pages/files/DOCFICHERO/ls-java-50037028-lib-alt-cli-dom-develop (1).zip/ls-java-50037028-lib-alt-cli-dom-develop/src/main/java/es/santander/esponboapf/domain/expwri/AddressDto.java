package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AddressDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Address information.",
example = "{\"roadTypeCode\":\"Cl\",\"roadName\":\"AC/DC\",\"num\":\"6\","
        + "\"additionalInfo\":\"P1, Izqd, B\",\"postalCode\":\"28080\","
        + "\"city\"\"Pescueza\",\"proviceCode\":\"28\",\"provinceName\":\"Cáceres\"}")
// Address dto
public class AddressDto {

    /** The road type code. */
    // Road type code
    @Schema(maxLength = 3, description = "Road type code", example = "CL")
    @NotBlank
    @Size(max = 3)
    @Pattern(regexp = "[^0-9]{2,3}")
    private String roadTypeCode;

    /** The road name. */
    // Road name
    @Schema(maxLength = 250, description = "Road name", example = "AC/DC")
    @NotBlank
    @Size(max = 250)
    private String roadName;

    /** The num. */
    // Num
    @Schema(maxLength = 4, description = "Road number", example = "6")
    @Size(max = 4)
    @Pattern(regexp = "[0-9]{1,4}")
    private String num;

    /** The additional info. */
    // Additional info
    @Schema(maxLength = 30, description = "Home address additional information", example = "P1, Izqd, B")
    @Size(max = 30)
    private String additionalInfo;

    // At the moment, for Spain the postal code is always number, but for other
    // countries
    // the postal code might have letters, so then this pattern could be updated for
    // new requirements.
    /** The postal code. */
    @Schema(maxLength = 5, description = "Address postal code", example = "28080")
    @NotBlank
    @Size(max = 5)
    @Pattern(regexp = "[0-9]{5}")
    private String postalCode;

    /** The city. */
    // City
    @Schema(maxLength = 100, description = "Address city", example = "Pescueza")
    @NotBlank
    @Size(max = 100)
    @Pattern(regexp = "[^0-9]{1,100}")
    private String city;

    /** The province code. */
    // Province code
    @Schema(maxLength = 2, description = "Address province code", example = "28")
    @NotBlank
    @Size(max = 2)
    @Pattern(regexp = "[0-9]{1,2}")
    private String provinceCode;

    /** The province name. */
    // Province name
    @Schema(maxLength = 75, description = "Address province name", example = "Cáceres")
    @NotBlank
    @Size(max = 75)
    @Pattern(regexp = "[^0-9]{1,75}")
    private String provinceName;

}
