package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Consult ownership request dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsultOwnershipRequestDto {

    /**
     * The Identity number.
     */
    //identityNumber
    @Schema(description = "Identity number to request", example = "11111111H")
    private String identityNumber;

    /**
     * The Reference iberpay.
     */
    @Schema(description = "Iberpay request reference", example = "ES")
    private String referenceIberpay;

}
