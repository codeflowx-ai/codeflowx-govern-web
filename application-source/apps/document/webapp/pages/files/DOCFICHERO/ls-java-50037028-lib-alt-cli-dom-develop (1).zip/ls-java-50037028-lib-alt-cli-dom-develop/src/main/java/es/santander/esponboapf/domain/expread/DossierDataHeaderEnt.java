package es.santander.esponboapf.domain.expread;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierDataHeaderEnt.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information to display in the header of the dossier.",
example = "{\"dossierCode\":63,\"registerDate\":\"2021-09-09T11:57:53.627861\","
        + " \"office\":\"0282\",\"campaign\":\"Cuenta 123\",\"ipAddress\":\"123.876.345.09\","
        + "\"state\":\"Pendiente de documentación e ingreso\", \"stateCode\":5"
        + "\"substate\":\"Pendiente de documentación\","
        + "\"cancelReason\":\"Documentación fraudulenta\"}")
// Dossier data header ent
public class DossierDataHeaderEnt {

    /** The dossier code. */
    @Schema(description = "Dossier code", example = "63")
    private Long dossierCode;

    /** The register date. */
    @Schema(description = "Date of registration of the dossier.", example = "2021-09-09T11:57:53.627861")
    private LocalDateTime registerDate;

    /** The office. */
    @Schema(description = "Office code", example = "0282")
    private String office;

    /** The state code. */
    @Schema(description = "State code", example = "5")
    private Integer stateCode;

    /** The campaign. */
    @Schema(description = "Campaign in which the dossier is included.", example = "Cuenta 123")
    private String campaign;

    /** The ip address. */
    @Schema(description = "IP address.", example = "123.876.345.09")
    private String ipAddress;

    /** The state. */
    @Schema(description = "Status of the dossier.", example = "Pendiente de documentación e ingreso")
    private String state;

    /** The substate. */
    @Schema(description = "Subtate of the dossier.", example = "Pendiente de documentación")
    private String substate;

    /** The cancelReason. */
    @Schema(description = "Cancel reason of the dossier.", example = "Documentación fraudulenta")
    private String cancelReason;

}
