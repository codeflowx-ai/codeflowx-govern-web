package es.santander.esponboapf.domain.onboarding.api;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * IdSignDto
 *
 * The Class IdSignDto.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// IdSignDto
public class IdSignDto {

    /** The id sign expedient. */
    @NotNull
    @Schema(description = "Sign Expedient's identifier.", example = "1432")
    private Integer idSignExpedient;

    /** The person type. */
    @Schema(description = "Holder´s type person bdp", example = "F")
    @NotNull
    private String personType;

    /** The personcode. */
    @Schema(description = "Holder´s code person bdp", example = "143258")
    @NotNull
    private String personCode;

}
