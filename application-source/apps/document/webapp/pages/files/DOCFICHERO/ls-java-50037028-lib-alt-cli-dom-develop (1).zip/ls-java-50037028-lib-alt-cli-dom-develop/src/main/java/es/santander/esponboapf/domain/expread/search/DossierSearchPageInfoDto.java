package es.santander.esponboapf.domain.expread.search;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier search page info dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Dossier search result page info
public class DossierSearchPageInfoDto {

    /**
     * The Size.
     */
    // Size
    @Schema(description = "Size of the current search page", example = "7", defaultValue = "7")
    private Integer size;

    /**
     * The Number.
     */
    // Number
    @Schema(description = "Number of the current page", example = "0")
    private Integer number;

    /**
     * The Total pages.
     */
    // Total pages
    @Schema(description = "Total pages with the current size", example = "10")
    private Integer totalPages;

    /**
     * The Total elements.
     */
    // Total elements
    @Schema(description = "Total elements of the search", example = "111")
    private Long totalElements;

}
