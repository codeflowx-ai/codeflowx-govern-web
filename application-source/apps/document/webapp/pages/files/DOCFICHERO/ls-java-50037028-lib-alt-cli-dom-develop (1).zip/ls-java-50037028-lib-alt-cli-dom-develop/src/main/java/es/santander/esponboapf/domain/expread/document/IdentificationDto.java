package es.santander.esponboapf.domain.expread.document;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class IdentificationDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information about the status of the holder's identification.",
        example = "{\"stateCode\":\"O\",\"stateName\":\"Identificación\",\"identificationCode\":1,"
                + "\"identificationName\":\"Vídeollamada\"}")
// Identification dto
public class IdentificationDto {

    /** The statecode. */
    // State code
    @Schema(description = "Identification code of the identification status.", example = "O")
    private String statecode;

    /** The statename. */
    // State name
    @Schema(description = "Description of the identification status.", example = "Identificación")
    private String statename;

    /** The identification code. */
    // The identification code
    @Schema(description = "The reliable identification code", example = "1")
    private Integer identificationCode;

    /** The identification name. */
    // The identification name
    @Schema(description = "The reliable identification name", example = "Vídeollamada")
    private String identificationName;

    /** The pex. */
    @Schema(description = "Pex number of a document", example = "24G6E2TR")
    @Pattern(regexp = "[a-zA-Z0-9-_\\/ ]*")
    private String pex;

}
