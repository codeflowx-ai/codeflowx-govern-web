package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new country dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Activity performed according to occupation", 
example = "{\"countryCode\":\"AR\",\"countryName\":\"Argentina\","
        + "\"flagFile\":\"arentina.svg\",\"isTinRequired\":true}")
public class CountryDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -6249590953612010771L;

    /**
     * The country code.
     *
     * E.g.: 'AR'
     */
    @Schema(maxLength = 2, description = "code identifying a country", example = "AR")
    private String countryCode;

    /**
     * The country name.
     *
     * E.g.: 'Argentina'
     */
    @Schema(maxLength = 250, description = "Name of the country", example = "Argentina")
    private String countryName;

    /**
     * The flag file name inside the front package.
     *
     * E.g.: 'argentina.svg'
     */
    @Schema(description = " svf file containing the flag of the country", example = "argentina.svg")
    private String flagFile;

    /**
     * Flag to show if the tin is required.
     *
     * E.g.: true
     */
    @Schema(description = "It will be true if 'TIN' is required for the country", example = "true")
    private Boolean isTinRequired;
}
