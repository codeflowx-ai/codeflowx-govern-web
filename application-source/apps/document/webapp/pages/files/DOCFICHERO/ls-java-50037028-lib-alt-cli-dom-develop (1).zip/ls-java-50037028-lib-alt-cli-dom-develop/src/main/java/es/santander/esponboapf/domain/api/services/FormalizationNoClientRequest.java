package es.santander.esponboapf.domain.api.services;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


/**
 * The Class DossierCancelConsumptRequest.
 */
//Constructors
@NoArgsConstructor
@Data
@Schema(description = "Required information to cancel the dossier from consumpt.",
        example = "{\"dossierId\":\"91186c26-60ce-11ed-9b6a-0242ac120002\",\"cancelReasonCode\":22}")
@SuperBuilder
//Dossier Cancel request Onb object
public class FormalizationNoClientRequest{

    /**
     * The dossier id.
     *
     * Unique dossier identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     *
     */
    @Schema( description = "Unique dossier identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID dossierId;

    /** The cancel reason code. */
    @Schema( description = "Cancellation reason identifier.", example = "22")
    @NotNull
    private Integer cancelReasonCode;

    /** The other cancel reason. */
    @Schema(description = "Description reason other", example = "Other reason cancel.", maxLength = 150)
    private String otherCancelReason;

}
