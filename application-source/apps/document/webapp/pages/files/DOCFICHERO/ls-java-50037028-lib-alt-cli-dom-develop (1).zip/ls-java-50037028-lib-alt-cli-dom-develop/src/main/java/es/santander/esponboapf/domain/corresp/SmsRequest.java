package es.santander.esponboapf.domain.corresp;

import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class OtpRequest.
 */
@NoArgsConstructor
@Data
@Schema(description = "Mandatory information to be able to generate an OTP key.",
example = "{\"message\":\"Error in the otp\", \"fullPhoneNumber\":\"0034666666666\"}")
// OTP request
public class SmsRequest {

    /**
     * The holder id.
     *
     * The holder's identifier.
     */
    @Schema(maxLength = 100, description = "text to send in sms",
            example = "Error in the otp")
    @NotNull
    private String message;

    // the phone number should have the prefix code
    // as 00[prefix code] instead of +[prefix code]
    /**
     * The full phone number.
     *
     * The holder's full phone number.
     */
    @Schema(maxLength = 100,
            description = "Full phone number (including international prefix) where the sms with the OTP key "
                    + "will be sent to. ",
            example = "0034666666666")
    @XssValid
    @NotNull
    private String fullPhoneNumber;

}
