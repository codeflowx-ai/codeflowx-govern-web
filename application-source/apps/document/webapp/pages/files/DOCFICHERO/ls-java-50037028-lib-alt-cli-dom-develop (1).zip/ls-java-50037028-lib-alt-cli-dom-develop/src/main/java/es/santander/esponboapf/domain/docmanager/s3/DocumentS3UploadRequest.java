package es.santander.esponboapf.domain.docmanager.s3;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Document s 3 upload request.
 */
//The class DocumentS3UploadRequest
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentS3UploadRequest {

    /**
     * The Folder.
     */
    //Folder
    @Schema(description = "Destination folder", example = "629/TEST")
    @Pattern(regexp = "[\\w/]+")
    private String folder;

    /**
     * The Filename.
     */
    // The Filename
    @Schema(description = "File name", example = "file.jpg")
    @Pattern(regexp = "[\\w.]+")
    private String filename;

    /**
     * The Document base 64.
     */
    // The Document base 64
    @Schema(description = "Document data encoded in base 64", example = "dGVzdGV4YW1wbGU=")
    private String documentBase64;

}
