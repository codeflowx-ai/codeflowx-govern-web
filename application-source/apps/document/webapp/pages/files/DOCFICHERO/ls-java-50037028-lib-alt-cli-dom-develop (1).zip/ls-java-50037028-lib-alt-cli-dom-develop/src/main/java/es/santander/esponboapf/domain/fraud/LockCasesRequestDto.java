package es.santander.esponboapf.domain.fraud;

import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class LockCasesRequestDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class LockCasesRequestDto {

    /** The created. */
    @Schema(description = "Creation date and time", example = "2023-08-17T08:27:25.537Z")
    private String created;

    /** The expires. */
    @Schema(description = "Expiration date and time", example = "2023-08-18T08:27:25.538Z")
    private String expires;

    /** The guid. */
    private UUID guid;

    /** The request number. */
    @Schema(description = "Dossier Code", example = "123")
    private String requestNumber;

    /** The agent. */
    @Schema(description = "The agent", example = "")
    private String agent;

    /** The lock. */
    @Schema(description = "Indicate if the dossier is going to lock or unlock", example = "true")
    private Boolean lock;
}
