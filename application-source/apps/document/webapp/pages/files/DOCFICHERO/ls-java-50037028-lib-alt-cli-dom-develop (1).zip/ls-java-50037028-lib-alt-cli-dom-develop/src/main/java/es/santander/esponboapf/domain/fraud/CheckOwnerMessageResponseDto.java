package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CheckOwnerMessageResponseDto.
 */
//The class CheckOwnerMessageResponseDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "Information about a transfer process",
        example = "{\"code\":\"LN001\",\"description\":\"No otp for this holder or has expired.\"}")
public class CheckOwnerMessageResponseDto {

    /** The code. */
    //The Code
    @Schema(description = "Error code", example = "TR001")
    private String code;

    /** The description. */
    @Schema(description = "Error description", allowableValues = { "No otp for this holder or has expired.",
            "Wrong code, you have exceeded the number or retries.", "Wrong code, only (number) retries remain" },
            example = "No otp for this holder or has expired.")
    private String description;

}
