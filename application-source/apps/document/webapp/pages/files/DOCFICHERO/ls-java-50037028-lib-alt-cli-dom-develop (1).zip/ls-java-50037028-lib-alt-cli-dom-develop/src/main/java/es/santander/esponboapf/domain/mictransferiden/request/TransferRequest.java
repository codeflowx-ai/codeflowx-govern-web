package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferRequest {

    /** The Payment type. */
    private String paymentType;

    /** The Payer. */
    private TransferPayerRequest payer;

    /** The Beneficiary account. */
    private TransferBeneficiaryAccountRequest beneficiaryAccount;

    /** The Beneficiary. */
    private TransferBeneficiaryRequest beneficiary;

    /** The Payment details. */
    private TransferPaymentDetailsRequest paymentDetails;

    /** The Other information. */
    private TransferOtherInformationRequest otherInformation;

}
