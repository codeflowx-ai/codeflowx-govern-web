package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class DossierAuditRequest.
 */
@NoArgsConstructor
@Data
@Schema(description = "Request dto with information to be saved as audit for a dossier", 
    example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"dossierCode\":1,"
            + "\"dossierId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"dossierAction\":1,"
            + "\"actor\":\"user1\",\"field\":\"ip\",\"currentValue\":\"127.0.0.1\","
            + "\"responseCode\":\"400\",\"responseDesc\":\"Bad request\","
            + "\"notes\":\"Se han registrado los datos de ocupacion\",\"holderCode\":\"345\"}")
@SuperBuilder
@AllArgsConstructor
// Dossier Audit request object
public class DossierAuditRequest {

    /**
     * The holder id.
     *
     * Unique holder identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     *
     */
    @Schema(description = "Unique holder identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /**
     * The dossier code.
     *
     * Internal dossier code. Used by backoffice services. Null otherwise. E.g.: 1
     */
    @Schema(description = "Internal dossier code. Used by backoffice services. Null otherwise.", example = "1")
    private Long dossierCode;

    /**
     * The dossier id.
     *
     * Unique dossier identifier. Used by onboarding services. Null otherwise. E.g.:
     * '80fd7423-5759-445b-a92f-6e88f514cc00'
     *
     */
    @Schema(description = "Unique dossier identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID dossierId;

    /** The dossier action. */
    // Dossier action
    @Schema( description = "Action performed on the dossier.", example = "DOSSIER_CREATION")
    @Min(1)
    private int dossierAction;

    /** The actor. */
    // Actor
    @Schema(maxLength = 100,
            description = "The name of the user who performed the action on the dossier.", example = "user1")
    @Size(max = 100)
    private String actor;

    /** The field. */
    // Field
    @Schema(maxLength = 50, description = "Field over which the action was performed.", example = "ip")
    @Size(max = 50)
    private String field;

    // as usual, the ip address
    /** The current value. */
    @Schema(maxLength = 100, description = "Current value of the field.", example = "127.0.0.1")
    @Size(max = 100)
    private String currentValue;

    /** The response code. */
    // Response code
    @Schema(maxLength = 10, description = "Response code of the external service call."
            , example= "400")
    @Size(max = 10)
    private String responseCode;

    /** The response desc. */
    // Response desc
    @Schema(maxLength = 250, description = "Response description of the external service call."
            , example = "Bad request")
    @Size(max = 250)
    private String responseDesc;

    // to help the action
    /** The notes. */
    @Schema(maxLength = 2000, description = "Some notes about the action.",
            example = "Se han registrado los datos de ocupacion")
    private String notes;

    /** The holder code. */
    // Holder code
    @Schema(description = "Unique holder code.", example = "345")
    private Long holderCode;

}
