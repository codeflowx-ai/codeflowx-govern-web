package es.santander.esponboapf.domain.token;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Atributes.
 */
@NoArgsConstructor
@Data
public class Atributes {

    /** The alias. */
    private String alias;
    
    /** The uid. */
    private String uid;
}
