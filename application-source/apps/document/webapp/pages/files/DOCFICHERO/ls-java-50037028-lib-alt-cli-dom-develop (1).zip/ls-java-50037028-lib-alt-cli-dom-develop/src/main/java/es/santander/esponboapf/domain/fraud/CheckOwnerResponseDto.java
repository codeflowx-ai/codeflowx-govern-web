package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CheckOwnerResponseDto.
 */
//The class CheckOwnerResponseDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "Information about a transfer process", example = "{\"result\": false, \"message\": "
        + "{\"code\":\"LN001\",\"description\":\"No otp for this holder or has expired.\"}}")
public class CheckOwnerResponseDto {

    /** The result. */
    //Result
    @Schema(description = "Validation status. True if valid, false if failed.", example = "true")
    private boolean result;

    /** The message. */
    @Schema(description = "Information about a failed OTP key validation. It will be null if 'result' is true",
            example = "{\"code\":\"LN001\",\"description\":\"No otp for this holder or has expired.\"}")
    private CheckOwnerMessageResponseDto message;

}
