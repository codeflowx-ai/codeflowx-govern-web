package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer settlement concept response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferSettlementConceptResponse {

    /** The Catalog concept. */
    private String catalogConcept;

    /** The Amount concept applied. */
    private TransferAmountDataResponse amountConceptApplied;

    /** The Amount concept currency transfer. */
    private TransferAmountDataResponse amountConceptCurrencyTransfer;

    /** The Type concept. */
    private String typeConcept;

    /** The Rate. */
    private Double rate;

}
