package es.santander.esponboapf.domain.valcli;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FiocConceptoRequest.
 *
 * Fioc concept information.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Fioc concept information", 
example = "{\"idConc\":\"001\",\"valorConc\":\"001\"}")
public class FiocConceptoDto {

    /**
     * The id conc.
     *
     * Fioc concept id.
     * E.g.: '001'
     */
    @Schema(maxLength = 3, description = "Fioc concept id", example = "001")
    @Pattern(regexp = "^[0-9]{3}$")
    private String idConc;

    /**
     * The valor conc.
     *
     * Fioc concept value.
     * E.g.: '01'
     */
    @Schema(maxLength = 2, description = "Fioc concept value", example = "001")
    @Pattern(regexp = "^[0-9]{2}$")
    private String valorConc;
}
