package es.santander.esponboapf.domain.api.services;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CancelConsumptionRequest.
 */
// CancelConsumptionRequest
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CancelConsumptionRequest {

   /** The uid. */
   /** The account entity. */
   // Uid
    @Schema(description = "External dossier id to cancel in consumption",
            example = "91186c26-60ce-11ed-9b6a-0242ac120002")
   private String uid;
}
