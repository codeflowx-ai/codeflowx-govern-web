/*
 *
 */
package es.santander.esponboapf.domain.expwri;

import es.santander.esponboapf.domain.validation.annotations.PurposeOperations;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;

/**
 * The Class SavePurposeHolderDto.
 *
 * Information related to a holder who is on the process of the digital
 * onboarding.
 *
 * If 'purposeAccountCode' is 3, then 'investmentOperations' should not be
 * empty.
 *
 */
@NoArgsConstructor
@Data
@Schema(description = "Information about the purpose why the holder is opening an account.",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"purposeAccountCode\":1,\"investmentOperations\":[1,2]}")
@PurposeOperations
// Save purpose holder dto
public class SavePurposeHolderDto {

    /** The holder id. */
    // Holder id
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /** The purpose account code. */
    // Purpose account code
    @Schema( description = "Purpose type code",
            allowableValues = { "1 – Personal/family", "2 - Professional/Freelance", "3 - Investments" },
            example = "1")
    @Min(1)
    private int purposeAccountCode;

    /** The investment operations. */
    // Investment operation list
    @Schema(description = "List of operation codes that might be conducted if investments are the target.",
            example = "[1,2]",
            allowableValues = { "1 - Trade of bearer payment means",
                    "2 - Cash delivery or withdrawal", "3 - Foreign currencies trades",
                    "4 - Foreign payment or collection orders", "5 - Foreign trade operations",
                    "6 - None of the others" })
    private List<Integer> investmentOperations;

}
