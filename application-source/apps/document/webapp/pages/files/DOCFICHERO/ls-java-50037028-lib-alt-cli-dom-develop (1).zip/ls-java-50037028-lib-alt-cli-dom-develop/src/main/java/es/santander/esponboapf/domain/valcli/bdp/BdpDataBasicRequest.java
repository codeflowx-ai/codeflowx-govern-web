package es.santander.esponboapf.domain.valcli.bdp;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpDataBasicRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class BdpDataBasicRequest {

    /** The canalc. */
    private String canalc;

    /** The codpers. */
    private List<String> codpers;

    /** The idemp. */
    private String idemp;

    /** The inddircc. */
    private List<String> inddircc;

    /** The inddomi. */
    private List<String> inddomi;

    /** The indiba. */
    private List<String> indiba;

    /** The tipopers. */
    private List<String> tipopers;
}
