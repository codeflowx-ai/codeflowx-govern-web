package es.santander.esponboapf.domain.enums;

import lombok.Getter;

/**
 * The enum Audit action enum.
 * Gets the message.
 *
 * @return the message
 */

/**
 * Gets the message.
 *
 * @return the message
 */

/**
 * Gets the message.
 *
 * @return the message
 */
@Getter
public enum AuditActionEnum {

    /** The Dossier creation. */
    DOSSIER_CREATION(1, "alta del expediente"),
    /** The Attach id document. */
    ATTACH_ID_DOCUMENT(2, "adjuntar documento identificación"),
    /** The Dossier cancel. */
    DOSSIER_CANCEL(3, "cancelación del expediente"),
    /** The Dossier ending. */
    DOSSIER_ENDING(4, "finalización del expediente"),
    /** The Holder creation state. */
    HOLDER_CREATION_STATE(5, "estado alta de cliente"),
    /** The Pending activation. */
    PENDING_ACTIVATION(6, "en espera de activación"),
    /** The Activation. */
    ACTIVATION(7, "en activación"),
    /** The Holder bdp validation. */
    HOLDER_BDP_VALIDATION(8, "validacion titular"),
    /** The Pending documentation state. */
    PENDING_DOCUMENTATION_STATE(9, "estado pendiente de documentación"),
    /** The Details screen save. */
    DETAILS_SCREEN_SAVE(10, "guardado en pantalla de ficha"),
    /** The Confirma validation. */
    CONFIRMA_VALIDATION(11, "proceso de cruce con Confirma (fraude)"),
    /** The Email bboo cancelation. */
    EMAIL_BBOO_CANCELATION(12, "envío email por cancelación expediente BBOO"),
    /** The Email postpone identification. */
    EMAIL_POSTPONE_IDENTIFICATION(13, "envío email al posponer identificación"),
    /** The Video treatment doc read. */
    VIDEO_TREATMENT_DOC_READ(14, "lectura del documento tratamiento de la videoidentificación"),
    /** The Fioc risk query. */
    FIOC_RISK_QUERY(15, "consulta del riesgo a Fioc"),
    /** The Access key reported. */
    ACCESS_KEY_REPORTED(16, "clave de acceso informada"),
    /** The Identification state modification. */
    IDENTIFICATION_STATE_MODIFICATION(17, "modificación estado identificación"),
    /** The Documentation screen save. */
    DOCUMENTATION_SCREEN_SAVE(18, "guardado en pantalla de documentación"),
    /** The Occupation completed. */
    OCCUPATION_COMPLETED(19, "completado actividad profesional"),
    /** The Bdp f creation. */
    BDP_F_CREATION(20, "creacion de la F en BDP"),
    /** The Account reservation. */
    ACCOUNT_RESERVATION(21, "reserva de cuenta"),
    /** The Process voluntary abandon. */
    PROCESS_VOLUNTARY_ABANDON(22, "abandono voluntario del proceso"),
    /** The Attach occupation document. */
    ATTACH_OCCUPATION_DOCUMENT(23, "adjuntar documento actividad económica"),
    /** The Attach address document. */
    ATTACH_ADDRESS_DOCUMENT(24, "adjuntar documento domicilio"),
    /** The Reject document. */
    REJECT_DOCUMENT(25, "rechazar documento"),
    /** The Email automatic cancelation. */
    EMAIL_AUTOMATIC_CANCELATION(26, "envío email por cancelación automática"),
    /** The Email process recovery. */
    EMAIL_PROCESS_RECOVERY(27, "envío email recuperar proceso"),
    /** The Email document claim. */
    EMAIL_DOCUMENT_CLAIM(28, "envío email reclamación documentación"),
    /** The Tmp directory doc deletion. */
    TMP_DIRECTORY_DOC_DELETION(29, "borrado de documentación en directorio temporal"),
    /** The Email video technical error. */
    EMAIL_VIDEO_TECHNICAL_ERROR(30, "envio email error técnico video llamada"),
    /** The Email start over. */
    EMAIL_START_OVER(31, "envio email volver a empezar"),
    /** The Email video not verified. */
    EMAIL_VIDEO_NOT_VERIFIED(32, "envio email videollamada no verificada"),
    /** The Email welcome. */
    EMAIL_WELCOME(33, "envio email bienvenida"),
    /** The Holder contact bdp creation. */
    HOLDER_CONTACT_BDP_CREATION(34, "alta de contacto del cliente en bdp"),
    /** The Account activation. */
    ACCOUNT_ACTIVATION(35, "activación cuenta"),
    /** The Update bdp info. */
    UPDATE_BDP_INFO(36, "actualización datos en bdp"),
    /** The Multichannel contract creation. */
    MULTICHANNEL_CONTRACT_CREATION(37, "alta contrato multicanal"),
    /** The Debit card creation. */
    DEBIT_CARD_CREATION(38, "alta tarjeta débito"),
    /** The Sign sms send. */
    SIGN_SMS_SEND(39, "envío sms firma"),
    /** The Contract read. */
    CONTRACT_READ(40, "lectura de contratos"),
    /** The Contract sign. */
    CONTRACT_SIGN(41, "firma de contratos"),
    /** The Doc sent digitalization. */
    DOC_SENT_DIGITALIZATION(42, "Envío documentación a digitalización"),
    /** The Holder contact details completed. */
    HOLDER_CONTACT_DETAILS_COMPLETED(43, "completado datos de contacto"),
    /** The Otp code validated. */
    OTP_CODE_VALIDATED(44, "se valida código otp datos de contacto"),
    /** The Study level completed. */
    STUDY_LEVEL_COMPLETED(45, "completado nivel de estudios"),
    /** The Occupation job completed. */
    OCCUPATION_JOB_COMPLETED(46, "completado ocupación laboral"),
    /** The Account purpose completed. */
    ACCOUNT_PURPOSE_COMPLETED(47, "completado finalidad de cuenta"),
    /** The Colective creation. */
    COLECTIVE_CREATION(48, "alta en colectivo"),
    /** The Agent identification. */
    AGENT_IDENTIFICATION(49, "cliente identificado por gestor"),
    /** The Email postpone transfer otp. */
    EMAIL_POSTPONE_TRANSFER_OTP(50, "envío email posponer clave transferencia"),
    /** The Identification by transfer. */
    IDENTIFICATION_BY_TRANSFER(51, "identificación fehaciente por transferencia"),
    /** The Immediate transfer done to account. */
    IMMEDIATE_TRANSFER_DONE_TO_ACCOUNT(52, "se realiza transferencia inmediata a cuenta destino"),
    /** The Account holders. */
    ACCOUNT_HOLDERS(53, "Titulares de la cuenta"),
    /** The Second holder creation. */
    SECOND_HOLDER_CREATION(54, "Alta de segundo titular"),
    /** The Email sent second holder noclient. */
    EMAIL_SENT_SECOND_HOLDER_NOCLIENT(55, "Envio email 2 titular no cliente"),
    /** The Email sent first holder coholders. */
    EMAIL_SENT_FIRST_HOLDER_COHOLDERS(56, "Envio email 1er titular contacto cotitulares"),
    /** The Email sent second holder invitation. */
    EMAIL_SENT_SECOND_HOLDER_INVITATION(57, "Envio email Información invitación segundos titulares"),
    /** The Email sent second holder client nocmc. */
    EMAIL_SENT_SECOND_HOLDER_CLIENT_NOCMC(58, "Envio email 2º titulares clientes Banco sin CMC"),
    /** The Email sent second holder client. */
    EMAIL_SENT_SECOND_HOLDER_CLIENT(59, "Envio email Cotitulares proceso completado"),
    /** The Lynx fraud query. */
    LYNX_FRAUD_QUERY(60, "consulta por fraude lynx"),
    /** The Email sent second holder client cmcblock. */
    EMAIL_SENT_SECOND_HOLDER_CLIENT_CMCBLOCK(61, "Envio email 2º titulares clientes Banco CMC bloqueado"),
    /** The Sign expedient completed notification. */
    SIGN_EXPEDIENT_COMPLETED_NOTIFICATION(62, "notificación expediente de firma completado"),
    /** The Appian end. */
    APPIAN_END(63, "Finalización en Appian"),
    /** The Read accept lopd. */
    READ_ACCEPT_LOPD(64, "lectura y aceptación de la información sobre protección de datos (LOPD)"),
    /** The Informed mortgage iban personcode. */
    INFORMED_MORTGAGE_IBAN_PERSONCODE(65, "se informa a hipotecas de las F e iban"),
    /** The Financial analysis done. */
    FINANCIAL_ANALYSIS_DONE(66, "Evaluación del riesgo financiación"),
    /** The Loan formalized. */
    LOAN_FORMALIZED(67, "Formalización del preéstamo"),
    /** The Identification otp validated. */
    IDENTIFICATION_OTP_VALIDATED(68, "Se valida código OTP de identificación"),
    /** The Precontract read. */
    PRECONTRACT_READ(69, "Lectura de precontractual"),
    /** The Belong courts query. */
    BELONG_COURTS_QUERY(70, "Consulta perteneciente a juzgados"),
    /** The Email sent completed office identitication consumpt. */
    EMAIL_SENT_COMPLETED_OFFICE_IDENTITICATION_CONSUMPT(71,
            "Envio email identificación por video u oficina completada(Consumo)"),
    /** The Email sent reminder otp. */
    EMAIL_SENT_REMINDER_OTP(72, "Envio email recordatorio identificación pendiente de otp"),
    /** The Modified email resume screen. */
    MODIFIED_EMAIL_RESUME_SCREEN(73, "modificación de email en pantalla resumen"),
    /** The Sms validate otp. */
    SMS_VALIDATE_OTP(74, "envío de sms validación otp móvil"),
    /** The Sms validate sign otp. */
    SMS_VALIDATE_SIGN_OTP(75, "envío de sms validación otp firma"),
    /** The Sms electronic sign. */
    SMS_ELECTRONIC_SIGN(76, "evío de sms firma electrónica"),
    /** The Consumpt cancel. */
    CONSUMPT_CANCEL(77, "cancelación en aplicación Consumo"),
    /** The Holder pick identification. */
    HOLDER_PICK_IDENTIFICATION(78, "Cliente selecciona tipo de identificación"),
    /** The Holder skip identification. */
    HOLDER_SKIP_IDENTIFICATION(79, "Cliente continua sin identificarse"),
    /** The Holder modified ocr data. */
    HOLDER_MODIFIED_OCR_DATA(80, "Modificación de datos del OCR"),
    /** The Email modification. */
    EMAIL_MODIFICATION(81, "Modificación de email"),
    /** The Dossier finish. */
    DOSSIER_FINISH(82, "Finalización de expediente"),
    /** The commissions read. */
    COMMISSIONS_READ(85, "Lectura de comisiones"),
    /** The account blocking. */
    ACCOUNT_BLOCKING(89, "Bloqueo de cuenta"),
    /** The Email transfer instructions. */
    EMAIL_TRANSFER_INSTRUCTIONS(90, "Envio email instrucciones de Transferencia Entrante"),
    /** The Address number query. */
    ADDRESS_NUMBER_QUERY(91, "Consulta de Num Domicilio para alta de tarjeta"),
    /** The Device number query. */
    DEVICE_NUMBER_QUERY(92, "Consulta de Num Dispositivo para alta de tarjeta"),
    /** The Account block incoming transfer. */
    ACCOUNT_BLOCK_INCOMING_TRANSFER(93, "Bloqueo de cuenta por transferencia entrante"),
    /** The Rejected identification. */
    REJECTED_IDENTIFICATION(94, "Identificación rechazada"),
    /** The unlock account. */
    UNLOCK_ACCOUNT(96, "Desbloqueo de cuenta"),
    /** The disengaged consult. */
    DISENGAGED_CONSULT(97, "Consulta Desvinculado"),
    /** The opinion confirma. */
    OPINION_CONFIRMA(98, "Dictaminar caso Confirma(fraude)"),
    /** The Formalize rename. */
    FORMALIZE_RENAME(99, "Renombrado de fichero con el código de persona"),
    /** The Document attach videocall audit action enum. */
    ATTACH_ID_DOCUMENT_VIDEOCALL(100, "Adjuntado documento de identidad por videollamada"),

    /** The receiving account transfers. */
    RECEIVING_ACCOUNT_TRANSFERS(101, "Recogida de transferencias de una cuenta"),

    /** The transfer refund. */
    TRANSFER_REFUND(102, "Devolución de transferencia"),

    /** The modified holder identification transfer batch. */
    MODIFIED_HOLDER_IDENTIFICATION_TRANSFER_BATCH(103,
            "Modificado estado de la identificacion por proceso automático transferencias"),

    /** The expedient mulero. */
    EXPEDIENT_MULERO(104, "Llamada expediente mulero"),

    /** The account mulero. */
    ACCOUNT_MULERO(105, "Llamada cuenta mulero"),

    /** The failed mulero. */
    FAILED_MULERO(106, "Fallo llamada mulero"),

    /** The completion dossier. */
    COMPLETION_DOSSIER(107, "Finalización de expediente"),

    /** The status mulero. */
    STATUS_MULERO(108, "Llamada cambio estado muleros"),

    /** The heredo claim files. */
    HEREDO_CLAIM_FILES(109, "Expediente de reclamación creado");

    /** The Action code. */
    private Integer actionCode;

    /** The Message. */
    private String message;

    /**
     * Instantiates a new Audit action enum.
     *
     * @param actionCode the action code
     * @param message    the message
     */
    AuditActionEnum(Integer actionCode, String message) {
        this.actionCode = actionCode;
        this.message = message;
    }

}
