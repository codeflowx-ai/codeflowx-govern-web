package es.santander.esponboapf.domain.enums;

/**
 * The Enum IberpayStatusEnum.
 */
public enum IberpayStatusEnum {

    /**
     * The no iberpay.
     * No account checked in iberpay.
     */
    NO_IBERPAY,

    /**
     * The iberpay maxiberpays.
     * Max iberpay retries.
     */
    IBERPAY_MAXIBERPAYS,

    /**
     * The iberpay noiban.
     * Holder has an account checked but different than the current one.
     */
    IBERPAY_NOIBAN,

    /**
     * The iberpay noiban maxiberpays.
     * Holder has an account checked but different than the current one. Besides, this holder has reached the max number
     * of transfers.
     */
    IBERPAY_NOIBAN_MAXIBERPAYS,

    /**
     * The iberpay lasttransfer.
     * Last account ownership confirmed and transfer accepted.
     */
    IBERPAY_LASTTRANSFER,

    /**
     * The iberpay iban pendingownership.
     * Account ownership pending of iberpay.
     */
    IBERPAY_IBAN_PENDINGOWNERSHIP,

    /**
     * The iberpay iban wrongownership.
     * Account ownership request cancelled or with error.
     */
    IBERPAY_IBAN_WRONGOWNERSHIP,

    /**
     * The iberpay iban rejectedownership.
     * Account ownership request rejected.
     */
    IBERPAY_IBAN_REJECTEDOWNERSHIP,

    /**
     * The iberpay iban ownership prtransfer.
     * Account ownership confirmed and transfer cancelled.
     */
    IBERPAY_IBAN_OWNERSHIP_REJECTEDTRANSFER,

    /**
     * The iberpay iban ownership pendingtransfer.
     * Account ownership confirmed and transfer pending.
     */
    IBERPAY_IBAN_OWNERSHIP_PENDINGTRANSFER,

    /**
     * The iberpay iban ownership acctransfer.
     * Account ownership confirmed and transfer accepted.
     */
    IBERPAY_IBAN_OWNERSHIP_ACCTRANSFER,

    /**
     * The iberpay iban ownership maxtransfer.
     * Account ownership confirmed but max transfers reached.
     */
    IBERPAY_IBAN_OWNERSHIP_MAXTRANSFER,

    /** The other. */
    OTHER;

}
