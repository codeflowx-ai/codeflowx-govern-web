package es.santander.esponboapf.domain.enums;

import lombok.Getter;

/**
 * Document types
 *
 * @author Santander Tecnología
 *
 */
@Getter
public enum DocumentTypeEnum {

    DECLARACION_CLIENTE("FICHA_CRS", "L6", 1, "Declaración de datos de clientes", "FichaClienteCRS_PF", "SERC"),
    CONDICIONES_PARTICULARES_CMC("CONT_CMC", "MF", 8, "Contrato Multicanal", "", ""),
    CONDICIONES_PARTICULARES_CUENTA("SUPERCTA123", "JG", 5, "Contrato de Cuenta", "", ""),
    CONSENTIMIENTOS("FICHA_CONSENTIM", "EQ", 3, "Declaración consentimientos de cliente", "FICHA_CONSENTIM", "GDPR"),
    DECLARACION_SIN_ACTIVIDAD("MATRI_EST_ESP", "MV", 4, "Declaración de no actividad", "", ""),
    FIOC("CUE_OBL_PF", "XY", 2, "Fioc", "", ""),
    FIOC_PRINT("CUE_INF_OBL_PF", "XY", 2, "Fioc", "", ""),
    INF_PRECONTRACTUAL("INF_PREC_CUENTA", "JJ", 7, "Información precontractual cuenta", "", ""),
    CONDICIONES_GENERALES("CONDIC_GENERAL", "WJ", 6, "Condiciones generales", "", ""),
    CONDICIONES_GENERALES_DIG("REC_FOLLETO", "WI", 6, "Acuerdo aceptación", "", ""),
	INFORMACION_NORMALIZADA_EUROPEA("RECIBI_INE", "84", 9, "Información normalizada Europea", "", ""),
    CONTRATO_PRESTAMO("PRESTAMO_PO", "JS", 10, "Contrato de préstamo", "", ""),
    INF_COMISIONES("DOC_INF_COM_CTA", "i5", 11, "Documento Información Comisiones Cuenta", "", "");

    /**
     * este campo localizado su uso en San Firmas
     */
    private String codDocumentManager;

    /** código de tipo de documento */
    private String docType;

    /** titulo del documento */
    private String titleDoc;

    /** código de contrato en HC **/
    private int contractCode;

    /** nombre documento **/
    private String nameDoc;

    /** cliente **/
    private String client;

    /**
     * Constructor
     *
     * @param docType            type code
     * @param codDocumentManager document manager code
     * @param contractCode       contract code
     * @param titleDoc           document title
     * @param nameDoc            document name
     * @param client             client
     */
    DocumentTypeEnum(String docType, String codDocumentManager, int contractCode, String titleDoc, String nameDoc,
            String client) {
        this.docType = docType;
        this.codDocumentManager = codDocumentManager;
        this.contractCode = contractCode;
        this.titleDoc = titleDoc;
        this.nameDoc = nameDoc;
        this.client = client;
    }

    /**
     * Obtiene el DocumentTypeEnum asociado a un codigo de tipo de documento.
     *
     * @param docType codigo tipo de documento
     * @return DocumentTypeEnum
     */
    public static DocumentTypeEnum valueOfByDocType(String docType) {
        final DocumentTypeEnum[] types = DocumentTypeEnum.values();
        for (final DocumentTypeEnum documentTypeEnum : types) {
            if (documentTypeEnum.getDocType().equalsIgnoreCase(docType)) {
                return documentTypeEnum;
            }
        }
        return null;
    }

    /**
     * Obtiene el DocumentTypeEnum asociado a un codigo de tipo de documento.
     *
     * @param contractCode codigo tipo de contrato
     * @return DocumentTypeEnum
     */
    public static DocumentTypeEnum valueOfByContractCode(Integer contractCode) {
        final DocumentTypeEnum[] types = DocumentTypeEnum.values();
        for (final DocumentTypeEnum documentTypeEnum : types) {
            if (documentTypeEnum.getContractCode() == contractCode) {
                return documentTypeEnum;
            }
        }
        return null;
    }

}
