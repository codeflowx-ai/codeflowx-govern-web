package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Instantiates a new holder info details.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Holder's extended information.")
public class HolderInfoDetailsDto extends HolderDetailDto {

    /**
     * The prefix.
     */
    @Schema(description = "Phone prefix number", example = "34")
    private String prefix;

    /**
     * The road type name.
     *
     * E.g.: 'Avenue'
     */
    @Schema(maxLength = 50, description = "Road type description", example = "Avenida")
    private String roadTypeName;

    /**
     * The status code.
     *
     * E.g: 'A'
     */
    @Schema(maxLength = 1, description = "occupation type in BDP", example = "A")
    private String statusCode;

    /** The occupation type name. */
    @Schema(description = "occupation type name", example = "Autónomo")
    private String occupationTypeName;

    @Schema(description = "Name country", example = "España")
    private String countryIdentification;

    /**
     * The bboo registration.
     *
     */
    @Schema(description = "BBOO registration indicator", example = "false")
    private Boolean bbooRegistration;
    
    /** The state dossier. */
    @Schema(description = "Id dossier state", example = "2")
    private Integer stateDossier;

    /** The bdp language code. */
    @Schema(description = "Bdp preferred language code", example = "E")
    private String bdpLanguageCode;

}
