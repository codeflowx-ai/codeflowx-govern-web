package es.santander.esponboapf.domain.valcli;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FiocNumericosRequest.
 *
 * Fioc numeric information.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Fioc numeric information", 
example = "{\"idNum\":\"001\",\"numero\":\"25\"}")
public class FiocNumericosDto {

    /**
     * The id num.
     *
     * Fioc numeric id
     * E.g.: '001'
     */
    @Schema(maxLength = 3, description = "Fioc numeric id", example = "001")
    @Pattern(regexp = "^[0-9]{3}$")
    private String idNum;

    /**
     * The numero.
     *
     * Fioc numeric id.
     * E.g.: '25'
     */
    @Schema(maxLength = 2, description = "Fioc numeric value", example = "25")
    @Pattern(regexp = "^[0-9]{2}$")
    private String numero;

}
