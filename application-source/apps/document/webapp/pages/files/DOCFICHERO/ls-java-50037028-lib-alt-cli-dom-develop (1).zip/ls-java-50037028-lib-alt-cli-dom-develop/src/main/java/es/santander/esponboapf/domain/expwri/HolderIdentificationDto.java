package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder identification dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderIdentificationDto {

    /**
     * The Holder code.
     */
    // Holder code
    @Schema(description = "Holder code", example = "1")
    private Long holderCode;

    /**
     * The identification code.
     */
    // Identification code
    @Schema(description = "Identification code", example = "1")
    private Integer identificationCode;

    /**
     * The reject number video.
     */
    // Reject number video
    @Schema(description = "Reject number video", example = "1")
    private Integer rejectNumberVideo;

}
