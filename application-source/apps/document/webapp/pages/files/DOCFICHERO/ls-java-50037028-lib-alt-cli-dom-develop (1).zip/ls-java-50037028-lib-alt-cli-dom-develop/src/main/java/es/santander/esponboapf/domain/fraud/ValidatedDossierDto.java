package es.santander.esponboapf.domain.fraud;

import java.util.List;

import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ValidatedDossier.
 */

/**
 * Instantiates a new validated dossier dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Validated dossier for a holder provided.",
    example = "{\"dossierCode\":1,\"ipAddress\":\"127.0.0.0\","
        + "\"holders\":[{\"incomeRange\":\"30000\","
        + "\"occupationType\":\"11\",\"viaType\":\"11\","
        + "\birthDate\":\"07/07/1975\"}], \"campaignCode\":221}")
// Validate dossier data object
public class ValidatedDossierDto {

    /**
     * The dossier code.
     *
     * Internal dossier code. Used by backoffice services. Null otherwise. E.g.: 1
     */
    @Schema(description = "Internal dossier code. Used by backoffice services. Null otherwise.", example = "1")
    private Long dossierCode;

    /** The ip address. */
    @Schema(maxLength = 39, description = "Ip of the holder at the time of the request", example = "127.0.0.0")
    @Size(max = 39)
    private String ipAddress;

    /** The holders. */
    @Schema(maxLength = 39, description = "List of holders", example = "[{\"incomeRange\":\"30000\","
            + "\"occupationType\":\"11\",\"viaType\":\"11\",\"birthDate\":\"07/07/1975\"}]")
    @Size(max = 39)
    private List<FraudReferenceDto> holders;
    
    /** The campaign code. */
    @Schema(description = "Number identifying a campaign", example = "341")
    private Integer campaignCode;
}
