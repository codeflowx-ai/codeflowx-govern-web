package es.santander.esponboapf.domain.expwri.dossier.save;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * The type Save document dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class SaveDocumentDto {

    /** The Holder document code. */
    private Long holderDocCode;

    /** The Document code.  */
    @NotNull
    private Integer documentCode;

    /** The Doc state code. */
    @NotNull
    private String docStateCode;

    /**  The Reject reason code. */
    private Integer rejectReasonCode;

    /** The Reject reason text.  */
    private String rejectReasonText;

    /** The Document data. */
    private List<String> filename;

    /** The Audit action. */
    private Integer auditAction;

}
