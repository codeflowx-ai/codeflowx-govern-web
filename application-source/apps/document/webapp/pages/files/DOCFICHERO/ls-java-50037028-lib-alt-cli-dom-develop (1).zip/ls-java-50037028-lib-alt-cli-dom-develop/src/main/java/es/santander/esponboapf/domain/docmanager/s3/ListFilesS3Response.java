package es.santander.esponboapf.domain.docmanager.s3;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type List files s 3 response.
 */
//The class ListFilesS3Response
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ListFilesS3Response {

    /**
     * The Files.
     */
    // The Files
    private List<String> files;

}
