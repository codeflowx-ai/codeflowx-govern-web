package es.santander.esponboapf.domain.expwri.dossier.save;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Save document compare result.
 */
// Constructors
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Save document compare result
public class SaveDocumentCompareResult {

    /**
     * The Actions needed.
     */
    // Holder list
    private List<HolderDocumentCompare> holders;

}
