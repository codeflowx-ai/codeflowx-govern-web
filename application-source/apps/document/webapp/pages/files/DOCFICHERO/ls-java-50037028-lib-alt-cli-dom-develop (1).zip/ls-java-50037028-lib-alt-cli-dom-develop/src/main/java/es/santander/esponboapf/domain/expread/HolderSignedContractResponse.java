package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new holder contact response.
 */

@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Information about dossier related to a holder")
public class HolderSignedContractResponse  {

    /** The contract name. */
    @Schema(description = "The contract GNID", example = "Condiciones particulares")
    private String gnId;

    /**
     * Instantiates a new holder contact response.
     *
     * @param gnId the gn id
     */
    public HolderSignedContractResponse(String gnId) {

        this.gnId = gnId;
    }

}
