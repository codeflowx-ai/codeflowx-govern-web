package es.santander.esponboapf.domain.mictransferiden.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * TransferDetailBeneficiaryClientResponse
 *
 * The type Transfer detail beneficiary client response.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferDetailBeneficiaryClientResponse {

    /** The Person identifier. */
    @Schema(description = "Bank person identifier", example = "F12345678")
    private String personIdentifier;

}
