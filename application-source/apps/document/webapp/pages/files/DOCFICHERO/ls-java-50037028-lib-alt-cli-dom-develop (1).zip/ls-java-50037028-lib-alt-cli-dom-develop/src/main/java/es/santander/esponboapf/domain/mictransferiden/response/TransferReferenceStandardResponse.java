package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer reference standard response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferReferenceStandardResponse {

    /** The Product. */
    private String product;

    /** The Subtype. */
    private String subtype;

    /** The Standard. */
    private String standard;

}
