package es.santander.esponboapf.domain.fraud;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * The type Dossier fraud result dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Dossier fraud result
public class DossierFraudResultDto {

    /**
     * The Result.
     */
    // Result
    private String result;

    /**
     * The Priority.
     */
    // Priority
    private String priority;

    /**
     * The Identity number.
     */
    // Identity number
    private String identityNumber;

    /**
     * The Rule name.
     */
    // Rule name
    private String ruleName;

    /**
     * The Policy code.
     */
    // Policy code
    private String policyCode;

    /**
     * The Definition.
     */
    // Definition
    private String definition;

    /**
     * The Severity.
     */
    // Severity
    private String severity;

    /**
     * The confirm bboo.
     */
    // Confirm bboo    
    private Boolean confirmBboo;
    
    /**
     * Is filled boolean.
     *
     * @return the boolean
     */
    // Has rules method
    public Boolean hasRules() {
        return !StringUtils.isAnyEmpty(this.priority, this.identityNumber, this.ruleName,
                this.policyCode, this.definition, this.severity);
    }

}
