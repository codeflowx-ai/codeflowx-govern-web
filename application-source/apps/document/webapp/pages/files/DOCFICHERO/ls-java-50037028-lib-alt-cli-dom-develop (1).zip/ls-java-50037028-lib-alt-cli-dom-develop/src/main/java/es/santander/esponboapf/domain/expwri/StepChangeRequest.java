package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class StepChangeRequest.
 *
 * Request class to save information about a step of a dossier.
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Required information to save only the current step.",
        example = "\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\"")
// Step change request
public class StepChangeRequest extends DossierParentDto {

    /**
     * the HOLDERGUID.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     */
    @Schema(maxLength = 100, description = "Unique holder identifier. The first time is null.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

}
