package es.santander.esponboapf.domain.docmanager.signrecord;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new consent dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ConsentDto {

    /**
     * The consent code.
     *
     * Consent identifier
     * E.g.: 1
     */
    @Schema( description = "Consent identifier", example = "1")
    private Integer consentCode;

    /**
     * The consent description.
     *
     * E.g.: 'a oferta por parte del Banco de productos y servicios...'
     */
    @Schema(description = "Consent description",
            example = "a oferta por parte del Banco de productos y servicios...")
    private String consentDescription;
}
