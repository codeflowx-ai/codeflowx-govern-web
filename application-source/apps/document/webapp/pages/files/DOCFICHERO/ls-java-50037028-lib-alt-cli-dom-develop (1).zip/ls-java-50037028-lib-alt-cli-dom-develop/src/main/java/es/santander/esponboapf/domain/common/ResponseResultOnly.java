package es.santander.esponboapf.domain.common;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ResponseResultOnly.
 *
 * Response result only.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Response from a service.", example = "{\"result\":true}")
public class ResponseResultOnly {

    /** The result. */
    // The result
    @Schema(description = "Result status. True or false.", example = "false")
    private boolean result;

}
