package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class Holder.
 * Instantiates a new holder dto.
 */
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Natural person performing the digital onboarding",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"priority\":\"1\",\"universityCode\":1}")
public class HolderDto extends HolderContactDto {

    /**
     * The holder id.
     *
     */
    @Schema(maxLength = 100, description = "Unique holder identifier. The first time is null.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    // Para validar la persona que se está dando de alta, es necesario que facilite
    // los datos de HolderContactDto
    // (su número de móvil + prefijo, correo electrónico) y saber si es primer
    // titular o no.
    /**
     * The priority.
     *
     */
    @Schema(maxLength = 1, description = "Order of holders, e.g '1' is the main holder, '2' is the second holder",
            example = "1")
    @NotBlank
    @Size(max = 1)
    @Pattern(regexp = "[0-9]{1}")
    private String priority;

    /**
     * The university code.
     */
    @Schema(description = "Number identifying an university", example = "1")
    private Integer universityCode;

}
