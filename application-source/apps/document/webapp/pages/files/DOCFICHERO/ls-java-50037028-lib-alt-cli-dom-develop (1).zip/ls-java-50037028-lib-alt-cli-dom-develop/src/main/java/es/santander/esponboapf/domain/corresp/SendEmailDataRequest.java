package es.santander.esponboapf.domain.corresp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Send email data request.
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
// Send email data request
public class SendEmailDataRequest extends SendCommunicationDataRequest {

    /**
     * The Center.
     */
    @Builder.Default
    private String center = "";

    /**
     * The Date 1.
     */
    @Builder.Default
    @JsonProperty("date_1")
    private String date = "";

    /**
     * The Client surname 1.
     */
    @Builder.Default
    @JsonProperty("client_surname1")
    private String clientSurname1 = "";

    /**
     * The Client surname 2.
     */
    @Builder.Default
    @JsonProperty("client_surname2")
    private String clientSurname2 = "";

    /**
     * The Client name.
     */
    @Builder.Default
    @JsonProperty("client_name")
    private String clientName = "";

    /**
     * The Client name full.
     */
    @Builder.Default
    @JsonProperty("client_name_full")
    private String clientFullName = "";

    /**
     * The Name.
     */
    @Builder.Default
    private String name = "";

    /**
     * The Surname.
     */
    @Builder.Default
    private String surname = "";

    /**
     * The Operation.
     */
    @Builder.Default
    private String operation = "";

    /**
     * The Product name.
     */
    @Builder.Default
    @JsonProperty("product_name")
    private String productName = "";

    /**
     * The Product id.
     */
    @Builder.Default
    @JsonProperty("product_id")
    private String productId = "";

    /**
     * The Product description.
     */
    @Builder.Default
    @JsonProperty("product_description")
    private String productDescription = "";

    /**
     * The Description.
     */
    @Builder.Default
    private String description = "";

    /**
     * The Office.
     */
    @Builder.Default
    private String office = "";

    /**
     * The Code.
     */
    @Builder.Default
    private String code = "";

    /**
     * The Category.
     */
    @Builder.Default
    private String category = "";

    /**
     * The Group.
     */
    @Builder.Default
    private String group = "";

}
