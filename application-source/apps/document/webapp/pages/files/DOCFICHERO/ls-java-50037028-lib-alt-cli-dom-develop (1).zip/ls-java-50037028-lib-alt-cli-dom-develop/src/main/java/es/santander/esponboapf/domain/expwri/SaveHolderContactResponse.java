package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * The Class SaveHolderContactResponse.
 */

@NoArgsConstructor
@AllArgsConstructor
@Data
// Save holder contact response
public class SaveHolderContactResponse {

    /**
     * The dossier id.
     *
     * The dossier identifier
     */
    // Dossier id
    @Schema(maxLength = 100, description = "Unique dossier identifier.",
            example = "70fd7423-5759-447b-a92f-6e88f514cc89")
    private UUID dossierId;

    /**
     * The holder id.
     *
     * The holder identifier
     */
    // Holder identifier
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;
    
    /** The expiration days. */
    @Schema(description = "Process expiration days", example = "21")
    private Integer daysToCancel;

}
