package es.santander.esponboapf.domain.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * The type Local date time iso 8601 deserializer.
 */
public class LocalDateTimeISO8601Deserializer extends JsonDeserializer<LocalDateTime> {

    /**
     * Deserialize local date time.
     *
     * @param jsonParser             the json parser
     * @param deserializationContext the deserialization context
     * @return the local date time
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Override
    public LocalDateTime deserialize(JsonParser jsonParser,
                                     DeserializationContext deserializationContext) throws IOException {
        return LocalDateTime.parse(jsonParser.getText(), DateTimeFormatter.ISO_DATE_TIME);
    }

}
