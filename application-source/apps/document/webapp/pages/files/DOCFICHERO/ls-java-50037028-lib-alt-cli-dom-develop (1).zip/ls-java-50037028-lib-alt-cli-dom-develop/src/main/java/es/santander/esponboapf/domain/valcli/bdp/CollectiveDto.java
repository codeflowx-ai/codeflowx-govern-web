package es.santander.esponboapf.domain.valcli.bdp;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serial;
import java.io.Serializable;

/**
 * The type Collective dto.
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public final class CollectiveDto implements Serializable {

    /**
     * The constant serialVersionUID.
     */
    @Serial
    private static final long serialVersionUID = -830000321165910028L;
    /**
     * The Grupo.
     */
    @Schema( description = "Collective's group", example = "Company's group")
    private String grupo;

    /**
     * The Idioma.
     */
    @Schema( description = "Collective's language", example = "es-ES")
    private String idioma;

    /**
     * The Negocio.
     */
    @Schema( description = "Collective's company", example = "Company's type")
    private String negocio;

    /**
     * The Subtipo colectivo.
     */
    @Schema( description = "Collective's subtype", example = "001")
    private String subtipoColectivo;

    /**
     * The Tipo colectivo.
     */
    @Schema( description = "Collective's type", example = "0001")
    private String tipoColectivo;

}
