package es.santander.esponboapf.domain.expread.search;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Dossier search result dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
// The dossier search result
public class DossierSearchResultDto {

    /**
     * The Content.
     */
    // Content
    @Schema(description = "The content of the search")
    private List<DossierSearchDto> content;

    /**
     * The Page info.
     */
    // Page information
    @Schema(description = "The page information")
    private DossierSearchPageInfoDto pageInfo;

}
