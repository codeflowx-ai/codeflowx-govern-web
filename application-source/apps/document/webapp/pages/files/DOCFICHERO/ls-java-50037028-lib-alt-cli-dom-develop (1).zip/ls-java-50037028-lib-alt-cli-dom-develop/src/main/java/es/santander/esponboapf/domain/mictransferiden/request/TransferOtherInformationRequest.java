package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer other information request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferOtherInformationRequest {

    /** The Urgency indicator. */
    private String urgencyIndicator;

    /** The Mail sending indicator. */
    private String mailSendingIndicator;

    /** The Expense indicator. */
    private String expenseIndicator;

    /** The Operation breakdown indicator. */
    private String operationBreakdownIndicator;

    /** The Cryptography indicator. */
    private String cryptographyIndicator;

    /** The Same business group indicator. */
    private String sameBusinessGroupIndicator;

    /** The Cancelable indicator. */
    private String cancelableIndicator;

    /** The Auto fx indicator. */
    private String autoFXIndicator;

    /** The Fraud assessment. */
    private String fraudAssessment;

    /** The Fraud reference. */
    private String fraudReference;

}
