package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FraudRuleOpinionDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// FraudRuleOpinionDto
public class FraudRuleOpinionDto implements Serializable {


    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4924420647858903341L;

    /** The status code. */
    @Schema(description = "Status Code", example = "APST3")
    private String statusCode;

    /** The desc status. */
    @Schema(description = "Desc status", example = "REVISADO CORRECTO")
    private String descStatus;

    /** The comment code. */
    @Schema(description = "Comment code", example = "09")
    private String commentCode;

    /** The desc comment. */
    @Schema(description = "Desc comment", example = "Revisada Correcta")
    private String descComment;



}
