package es.santander.esponboapf.domain.gesdoc;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import es.santander.esponboapf.domain.docmanager.signrecord.ContractPdfDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class ReadDocPrecontractRequest.
 *
 * ReadDocPrecontractRequest.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
public class ReadDocPrecontractRequest extends ReadDocParamRequest {

    /** The contracts. */
    private List<ContractPdfDto> contracts;

    /** The config read doc. */
    @JsonInclude(Include.NON_NULL)
    private ReadDocParamRequest configReadDoc;

}
