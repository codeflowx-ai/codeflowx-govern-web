package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SavePersonalInfoResponseMessage.
 *
 * Response class with information about the process of saving personal
 * information.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information about a failed information validation. "
        + "Null if it did not fail and result is true", example = "{\"code\":\"VC001\","
                + "\"groupCode\":\"VG600\",\"description\":\"Client is on a black list\","
                + "\"urlRedirect\":\"http://phoenixapp.isban.dev.corp/REGCLA_PHOENIX/static/index.html?sty=SNET\"}")
public class SavePersonalInfoResponseMessage {

    /**
     * The code.
     *
     * The error code. Example: 'VC001', 'VC002',...
     */
    @Schema(maxLength = 5, description = "Validation error code", example = "VC001")
    @NotBlank
    @Size(max = 5)
    @Pattern(regexp = "^VC([0-9]{3})B?$")
    private String code;

    /**
     * The code.
     *
     * The error code. Example: 'VC001', 'VC002',...
     */
    @Schema(maxLength = 5, description = "Validation grouped error code", example = "VG600")
    @NotBlank
    @Size(max = 5)
    @Pattern(regexp = "^VG([0-9]{3})B?$")
    private String groupCode;

    /**
     * The description.
     *
     * The error description.
     */
    @Schema( description = "Validation error description",
            example = "Client is on a black list")
    @NotBlank
    @Pattern(regexp = "[0-9]{1,2}")
    private String description;

    /**
     * The url redirect.
     *
     * The url to be redirected depending on the error.
     */
    @Schema( description = "Url to be redirected depending on the error",
            example = "http://phoenixapp.isban.dev.corp/REGCLA_PHOENIX/static/index.html?sty=SNET")
    @NotBlank
    private String urlRedirect;

}
