package es.santander.esponboapf.domain.expread.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class ProcessDetailsDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Process details data object
public class ProcessDetailsDto {

    /** The Process code. */
    private Long processCode;

    /** The Process name. */
    private String processName;

    /** The Status. */
    private Boolean completed;

    /** The num order. */
    private Integer numOrder;

    /** The type col. */
    private Integer typeCol;

}
