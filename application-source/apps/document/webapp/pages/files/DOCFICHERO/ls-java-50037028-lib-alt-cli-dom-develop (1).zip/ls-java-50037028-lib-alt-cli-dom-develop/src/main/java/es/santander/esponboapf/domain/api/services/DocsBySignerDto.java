package es.santander.esponboapf.domain.api.services;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SignedDocsDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocsBySignerDto {

    /** The codgdoc. */
    private String codgdoc;

    /** The person number doc. */
    private String personNumberDoc;

    /** The status. */
    private String status;

    /** The type doc. */
    private String typeDoc;

    /** The gn id. */
    private String gnId;

    /** The result. */
    private String signed;

}
