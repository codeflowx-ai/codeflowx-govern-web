package es.santander.esponboapf.domain.expread;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier transfer dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DossierTransferDto {

    /** The Reference. */
    private String reference;

    /** The Date. */
    private String date;

    /** The Amount. */
    private Double amount;

    /** The Currency. */
    private String currency;

    /** The Payer name. */
    private String payerName;

    /** The Country. */
    private String country;

}
