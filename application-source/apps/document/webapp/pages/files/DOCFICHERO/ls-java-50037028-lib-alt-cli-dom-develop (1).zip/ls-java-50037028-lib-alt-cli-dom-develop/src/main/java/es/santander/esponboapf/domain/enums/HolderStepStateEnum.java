package es.santander.esponboapf.domain.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The Enum HolderStepStateEnum.
 */
public enum HolderStepStateEnum {

    /** The pending. */
    PENDING("P"),

    /** The pending validation. */
    PENDING_VALIDATION("V"),

    /** The pending otp. */
    PENDING_OTP("O"),

    /** The rejected. */
    REJECTED("K"),

    /** The completed. */
    COMPLETED("R");

    /** The Constant BY_VALUE. */
    private static final Map<String, HolderStepStateEnum> BY_VALUE = Arrays.stream(values())
            .collect(Collectors
                    .toUnmodifiableMap(e -> e.value, e -> e));

    /** The label. */
    public final String value;

    /**
     * Instantiates a new holder step state enum.
     *
     * @param value the value
     */
    HolderStepStateEnum(String value) {
        this.value = value;
    }

    /**
     * From value.
     *
     * @param value the value
     * @return the holder step state enum
     */
    public static HolderStepStateEnum fromValue(String value) {
        return BY_VALUE.get(value);
    }

}
