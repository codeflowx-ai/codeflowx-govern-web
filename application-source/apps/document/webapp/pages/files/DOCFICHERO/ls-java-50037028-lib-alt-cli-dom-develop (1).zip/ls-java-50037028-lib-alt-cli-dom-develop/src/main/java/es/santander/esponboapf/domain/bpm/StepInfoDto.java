package es.santander.esponboapf.domain.bpm;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StepInfoResponse.
 */
//The class StepInfoDto
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information about a bpm step.", example = ""
        + "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"processCode\":2,\"stepBpmId\":\"7\",\"casebpm\":\"5822CDAF47E448FE\","
        + "\"externalFlow\":true}")
public class StepInfoDto {

    /** The holder id. */
    @Schema(maxLength = 100, description = "Unique holder identifier. ",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    //HolderId
    private String holderId;

    /** The process code. */
    @Schema(description = "Process code", example = "2")
    private Integer processCode;

    /** The step bpm id. */
    @Schema(description = "Bpm step identifier.", example = "7")
    private String stepBpmId;

    /** The casebpm. */
    @Schema(description = "Id case appian.", example = "5822CDAF47E448FE")
    private String casebpm;

    /** The external flow. */
    @Schema(description = "Indicate if step is on the Consumption", example = "true")
    private Boolean externalFlow;
}
