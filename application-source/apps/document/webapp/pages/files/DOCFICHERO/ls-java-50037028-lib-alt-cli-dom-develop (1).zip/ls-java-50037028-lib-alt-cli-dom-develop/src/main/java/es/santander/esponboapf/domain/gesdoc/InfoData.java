package es.santander.esponboapf.domain.gesdoc;

import java.util.List;

import lombok.Builder;
import lombok.Data;

/**
 * The Class InfoData.
 */
@Data
@Builder
public class InfoData {

    /** The below sign. */
    private boolean belowSign;

    /** The text. */
    private List<String> text;

    /** The position. */
    private String position;
}
