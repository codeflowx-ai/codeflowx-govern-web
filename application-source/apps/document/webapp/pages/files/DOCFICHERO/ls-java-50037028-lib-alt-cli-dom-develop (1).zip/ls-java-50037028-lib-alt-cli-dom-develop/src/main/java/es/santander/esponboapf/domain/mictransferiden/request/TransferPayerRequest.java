package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer payer request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferPayerRequest {

    /** The Person identifier. */
    private String personIdentifier;

    /** The Name payer. */
    private String namePayer;

    /** The Order account. */
    private String orderAccount;

}
