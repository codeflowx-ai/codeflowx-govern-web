package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TransferBeneficiaryRequest
 *
 * The type Transfer beneficiary request.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferBeneficiaryRequest {

    /** The Beneficiary name. */
    private String beneficiaryName;

    /** The Residence indicator. */
    private String residenceIndicator;

}
