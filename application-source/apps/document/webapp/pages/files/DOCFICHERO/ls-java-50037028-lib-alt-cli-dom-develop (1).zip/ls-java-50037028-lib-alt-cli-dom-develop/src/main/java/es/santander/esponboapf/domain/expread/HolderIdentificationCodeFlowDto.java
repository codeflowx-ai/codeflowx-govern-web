package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderIdentificationDto.
 */
//The class HolderIdentificationCodeFlowDto
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Holder identification code flow dto.")
public class HolderIdentificationCodeFlowDto {

    /**
     * The Holder id.
     */
    @Schema(description = "UUID identifying an holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /** The reject number video. */
    @Schema(description = "Rejects numbers of the video-identification", example = "0")
    private Integer rejectNumberVideo;
    
    /** The identification code. */
    @Schema(description = "Indicates type of indetification", example = "1")
    private Integer identificationCode;

}
