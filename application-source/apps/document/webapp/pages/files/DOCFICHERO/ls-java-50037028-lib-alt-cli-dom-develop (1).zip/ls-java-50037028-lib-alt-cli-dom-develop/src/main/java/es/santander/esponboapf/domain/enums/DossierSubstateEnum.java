package es.santander.esponboapf.domain.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The Enum DossierSubstateEnum.
 */
public enum DossierSubstateEnum {

    /**
     * The id validation pending.
     * Value 1.
     */
    ID_VALIDATION_PENDING(1),

    /**
     * The id validated.
     * Value 2.
     */
    ID_VALIDATED(2),

    /**
     * The id rejected.
     * Value 3.
     */
    ID_REJECTED(3),

    /**
     * The document pending.
     * Value 4.
     */
    DOCUMENT_PENDING(4),

    /**
     * The validation pending.
     * Value 5.
     */
    VALIDATION_PENDING(5),

    /**
     * The document rejected.
     * Value 6.
     */
    DOCUMENT_REJECTED(6),

    /**
     * The document claimed.
     * Value 7.
     */
    DOCUMENT_CLAIMED(7);

    /** The Constant BY_VALUE. */
    private static final Map<Integer, DossierSubstateEnum> BY_VALUE = Arrays.stream(values())
            .collect(Collectors
                    .toUnmodifiableMap(e -> e.value, e -> e));

    /** The label. */
    public final int value;

    /**
     * Instantiates a new dossier state enum.
     *
     * @param value the value
     */
    DossierSubstateEnum(int value) {
        this.value = value;
    }

    /**
     * From value.
     *
     * @param value the value
     * @return the dossier state enum
     */
    public static DossierSubstateEnum fromValue(int value) {
        return BY_VALUE.get(value);
    }

}
