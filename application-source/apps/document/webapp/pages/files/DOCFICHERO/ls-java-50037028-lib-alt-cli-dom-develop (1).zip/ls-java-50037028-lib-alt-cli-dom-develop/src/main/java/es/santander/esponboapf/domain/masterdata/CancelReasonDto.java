package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CancelReasonDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Campaign chosen in the onboarding process",
example = "{\"cancelReasonCode\":1,\"cancelReasonName\":\"Expiration\"}")
public class CancelReasonDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -4205702705665268786L;

    /** The cancel reason code. */
    // Identifica el motivo de cancelación de expediente
    @Schema(description = "Number identifying a cancel reason", example = "1")
    private Integer cancelReasonCode;

    /** The cancel reason name. */
    // Es la descripción del motivo de cancelación de expediente.
    @Schema(description = "Cancel reason description", example = "Expiration")
    private String cancelReasonName;

}
