/**
 * Self.
 *
 * @return the change holder step request. change holder step request builder
 *         impl
 */
package es.santander.esponboapf.domain.expwri;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

/**
 * The Class ChangeHolderStepRequest.
 */

/**
 * To string.
 *
 * @return the java.lang. string
 */
@Data

/**
 * Hash code.
 *
 * @return the int
 */
@EqualsAndHashCode(callSuper = true)

/**
 * Builds the.
 *
 * @return the change holder step request
 */
@SuperBuilder
public class ChangeHolderStepRequest extends UniversalHolder {

    /** The step code. */
    private int stepCode;

    /** The step state. */
    private String stepState;
}
