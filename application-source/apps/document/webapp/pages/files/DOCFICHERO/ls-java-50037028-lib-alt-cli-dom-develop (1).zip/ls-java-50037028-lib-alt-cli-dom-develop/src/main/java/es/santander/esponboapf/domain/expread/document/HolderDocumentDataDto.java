package es.santander.esponboapf.domain.expread.document;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Holder document data dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
// Holder document data
public class HolderDocumentDataDto {

    /**
     * The Document code.
     */
    // Document code
    @Schema(description = "Document identifier", example = "1")
    private String documentCode;

    /**
     * The Document name.
     */
    // Document name
    @Schema(description = "Name of the document", example = "Pasaporte")
    private String documentName;

    /** The heredo code. */
    @Schema(description = "Document identifier in Heredo", example = "jg")
    private String heredoCode;

}
