package es.santander.esponboapf.domain.corresp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder pending communication step dto.
 */
//The class HolderPendingCommunicationStepDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HolderPendingCommunicationStepDto {

    /**
     * The Step code.
     */
    private Integer stepCode;

    /**
     * The Step state code.
     */
    private String stepStateCode;

}
