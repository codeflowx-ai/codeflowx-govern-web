package es.santander.esponboapf.domain.expread;

import java.io.Serializable;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class StepAside.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Holder aside information",
example = "{\"asideTitle\":\"Tu cuenta y tu préstamo\", \"listStepAside\":"
        + "[{\"stepCode\":\"1\",\"asideName\":\"Datos personales\",\"order\":1,\"isCompleted\":true}]}")
// Step status aside
public class StepStatusAside implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 2635632215776154521L;

    /** The aside title. */
    // Aside title
    @Schema(description = "Aside title",
            example = "Tu cuenta y tu préstamo”,")
    private String asideTitle;

    /** The step aside. */
    // List step aside
    @Schema(description = "List of step aside",
            example = "{\"stepCode\":\"1\",\"asideName\":\"Datos personales\",\"order\":1,\"isCompleted\":true}")
    private List<StepStatusAsideDto> listStepAside;

}
