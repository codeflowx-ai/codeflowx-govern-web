package es.santander.esponboapf.domain.clientreg;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activation CMC.
 */
//The class ActivationCmcRequest
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Input object activation cmc request")
// ActivationCmcRequest
public class ActivationCmcRequest {

    /** The personType. */
    //Person type
    @NotNull
    @Pattern(regexp = "[a-zA-Z]*")
    @Schema(description = "person type indicator", example = "F")
    private String personType;
    
    /** The personCode. */
    // Person code
    @XssValid
    @NotNull
    @Schema(description = "person code indicator", example = "12896587")
    private String personCode;

    /** The documentType. */
    // Document type
    @NotNull
    @XssValid
    @Schema(description = "document type indicator", example = "N")
    private String documentType;

    /** The document code. */
    // Document code
    @NotNull
    @XssValid
    @Schema(description = "document code indicator", example = "22224444G")
    private String documentCode;

    /** The fullNameHolder. */
    // Full name holder
    @NotNull
    @XssValid
    @Schema(description = "full name holder indicator", example = "Beatriz Pascual Marín")
    private String fullNameHolder;

    /** The numDomicilio. */
    // Num domicilio
    @NotNull
    @XssValid
    @Schema(description = "number address indicator", example = "1")
    private String numDomicilio;

    /** The productTypeAcount. */
    // Product type
    @NotNull
    @XssValid
    @Schema(description = "product type acount indicator", example = "300")
    private String productType;

    /** The subTypeAcount. */
    // Subtype account
    @NotNull
    @XssValid
    @Schema(description = "sub type acount indicator", example = "001")
    private String subType;

    /** The accountEntyty. */
    // Account entity
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "account entyty indicator", example = "0049")
    private String accountEntyty;
   
    /** The accountBranch. */
    // Account branch
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "account branch indicator", example = "2548")
    private String accountBranch;
    
    /** The partenonProduct. */
    // Partenon product
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "partenon product indicator", example = "300")
    private String partenonProduct;
   
    /** The accountCd. */
    // Account control digit
    @Schema(description = "account control digit", example = "00")
    @XssValid
    private String accountCd;
    
    /** The partenonAccount. */
    // Partenon account
    @NotNull
    @Pattern(regexp = "^[0-9]+$")
    @Schema(description = "partenon account indicator", example = "0500667")
    private String partenonAccount;

    /** The mobile. */
    // Mobile phone
    @NotNull
    @XssValid
    @Schema(description = "mobile number", example = "666777888")
    private String mobilePhone;

    /** The old format account. */
    // Old format account
    @XssValid
    @Schema(description = "Old format account", example = "0000325")
    private String oldFormatAccount;

    /** The old format product. */
    // Old format product
    @XssValid
    @Schema(description = "Old format product", example = "string")
    private String oldFormatProduct;

}
