package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new investment operation dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Activity performed according to occupation",
example = "{\"operationInvestmentCode\":1,"
        + "\"operationInvestmentName\":\"Compra o venta de medios de pago al portador\"}")
// Investment operation data object
public class InvestmentOperationDto implements Serializable{

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = 1267542742179971986L;

    /**
     * The operation investment code.
     *
     * E.g.: 1
     */
    @Schema(description = "Number identifying an operation", example = "1")
    private Integer operationInvestmentCode;

    /**
     * The operation investment name.
     *
     * E.g.: 'Trade of bearer payment means'
     */
    @Schema(maxLength = 200, description = "Description of the operation",
            example = "Compra o venta de medios de pago al portador")
    private String operationInvestmentName;
}
