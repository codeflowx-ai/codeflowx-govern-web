package es.santander.esponboapf.domain.docmanager.s3;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

/**
 * The type Formalize s 3 request.
 */
//The class FormalizeS3Request
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormalizeS3Request {

    /**
     * The Dossier code.
     */
    //Dossier code
    @NotNull
    private Long dossierCode;

    /**
     * The Priority.
     */
    @NotEmpty
    @Pattern(regexp = "^[0-9]$")
    private String priority;

    /**
     * The Filename.
     */
    @NotEmpty
    @Pattern(regexp = "[\\w.]+")
    private String filename;

    /**
     * The Person code.
     */
    @NotEmpty
    @Pattern(regexp = "[F][0-9]{1,20}")
    private String personCode;

}
