package es.santander.esponboapf.domain.expwri;

import java.time.LocalDate;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import es.santander.esponboapf.domain.util.LocalDateDeserializer;
import es.santander.esponboapf.domain.util.LocalDateSerializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder validation cancel data dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderValidationCancelDataDto {

    /**
     * The holder id.
     * <p>
     * Holder's identifier.
     */
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /** The holder code. */
    @Schema(description = "Holder code", example = "505")
    private Long holderCode;

    /**
     * The PRIORITY.
     * <p>
     * Holder's priority. '1' for main. Other numbers for subsequent ones.
     */
    @Schema(maxLength = 1,
            description = "Order of holders, e.g '1' is the main holder, '2' is the second holder",
            example = "1")
    private String priority;

    /**
     * The name.
     * <p>
     * Holder's name.
     */
    @Schema(maxLength = 20, description = "Holder's name",
            example = "Elena")
    private String name;

    /**
     * The surname 1.
     * <p>
     * Holder's first surname.
     */
    @Schema(maxLength = 26, description = "Holder's first or only surname",
            example = "Nito")
    private String surname1;

    /**
     * The surname 2.
     * <p>
     * Holder's second surname.
     */
    @Schema(maxLength = 26, description = "Holder's second surname",
            example = "Del Bosque")
    private String surname2;

    /**
     * The identity type code.
     * <p>
     * The holder's identity type code. '1' - 'NIF', '2' - 'NIE'
     */
    @Schema(description = "Identifier type code", example = "1",
            allowableValues = { "1 - NIF", "2 - NIE" })
    private Integer identityTypeCode;

    /**
     * The indentity number.
     * <p>
     * The holder's identity number.
     */
    @Schema(maxLength = 9, description = "Holder's identity document number",
            example = "L1234567L")
    private String identityNumber;

    /**
     * The birth date.
     * <p>
     * The holder's birth date.
     */
    @Schema(description = "Holder's birthdate (dd/MM/yyyy)", example = "07/07/1975")
    @JsonDeserialize(using = LocalDateDeserializer.class)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate birthDate;

    /**
     * The sex.
     * <p>
     * The holder's sex (M/F).
     */
    @Schema(maxLength = 1, description = "Holder's sex", example = "F", allowableValues = { "M", "F" })
    private String sex;

    /**
     * The birth city.
     * <p>
     * The holder's birth city.
     */
    @Schema(maxLength = 60, description = "Holder's city of birth", example = "Cachorrilla")
    private String birthCity;

    /** The birth province code. */
    @Schema(maxLength = 2, description = "Holder's birth province code", example = "28")
    private String birthProvinceCode;

    /** The birth province. */
    @Schema(maxLength = 2, description = "Holder's birth province name", example = "MADRID")
    private String birthProvince;

    /**
     * The birth country.
     * <p>
     * The holder's birth country code. E.g.: 'ES'.
     */
    @Schema(maxLength = 2, description = "Holder's country of birth code", example = "ES")
    private String birthCountry;

    /**
     * The nationality.
     * <p>
     * The holder's nationality code. E.g.: 'ES'
     */
    @Schema(maxLength = 2, description = "Holder's nationality code", example = "ES")
    private String nationality;

    /** The Email. */
    @Schema(description = "Email", example = "manuel1r223@gmail.com")
    private String email;

    /** The Prefix. */
    @Schema(description = "Phone prefix", example = "34")
    private String prefixPhone;

    /** The Movil. */
    @Schema(description = "Phone number", example = "686124154")
    private String cellPhone;

}
