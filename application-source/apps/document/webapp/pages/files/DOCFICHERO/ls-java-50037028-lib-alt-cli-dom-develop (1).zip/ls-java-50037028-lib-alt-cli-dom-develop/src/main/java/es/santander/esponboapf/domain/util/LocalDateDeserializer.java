package es.santander.esponboapf.domain.util;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

/**
 * The Class LocalDateDeserializer.
 */
public class LocalDateDeserializer extends JsonDeserializer<LocalDate> {

    /**
     * Deserialize.
     *
     * @param arg0 the arg 0
     * @param arg1 the arg 1
     * @return the local date
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Override
    public LocalDate deserialize(JsonParser arg0, DeserializationContext arg1) throws IOException {
        return LocalDate.parse(arg0.getText(), DateTimeFormatter.ofPattern(HagcliUtils.DATE_FORMAT));
    }

}
