package es.santander.esponboapf.domain.docmanager.s3;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Save document response.
 */
//The class SaveDocumentResponse
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SaveDocumentResponse {

    /**
     * The Filename.
     */
    // The Filename
    @Schema(description = "The generated file name", example = "DNI_F12345678_A.jpg")
    private String filename;

}
