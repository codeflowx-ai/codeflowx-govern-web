package es.santander.esponboapf.domain.expread;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new step holder response.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "The whole information about Holder's steps for a dossier")
@Builder
public class StepHolderResponse {

    /**
     * The step dossier.
     *
     * Paso del expediente.
     */
    @Schema(description = "Dossier's step description", example = "pantalla informacion fiscal titular1")
    private String stepDossier;

    /**
     * The all steps completed.
     *
     * Indica si el titular tiene todos los pasos completados.
     */
    @Schema(description = "indicator for all completed steps", example = "false")
    private boolean allStepsCompleted;

    /** The is multi holder. */
    @Schema(description = "indicator for multiholder", example = "false")
    private Boolean isMultiHolder;

    /** The address complete. */
    @Schema(description = "indicator for know if the holder has the address complete", example = "false")
    private Boolean addressComplete;
    /**
     * The steps holder.
     *
     * Lista de pasos del titular.
     */
    @Schema(description = "List of Holder's steps", example = "[]")
    private List<StepHolderDto> stepsHolder;

    /**
     * The Show pre contract screen.
     */
    @Schema(description = "indicator for showing the precontract screen", example = "false")
    private boolean showPreContractScreen;

    /**
     * The Show pre contract screen.
     */
    @Schema(description = "indicator for knowing if the campaing is being registered by a back office",
            example = "false")
    private boolean bbooRegistration;

}
