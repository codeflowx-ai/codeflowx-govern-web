package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FraudOpinionRequest.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FraudOpinionRequest {

    /** The request number. */
    // The request number
    @Schema(description = "Dossier identifier.", example = "666L")
    private String requestNumber;

    /** The statuscode. */
    // The status code
    @Schema(description = "Code opinion in confirma", example = "APST3")
    private String statusCode;

    /** The commentcode. */
    // The comment code
    @Schema(description = "Opinion`s comment code in confirma", example = "09")
    private String commentCode;

}
