package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer history payer data response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferHistoryPayerDataResponse {

    /** The Payer name. */
    private String payerName;

    /** The Payer home. */
    private TransferHistoryPayerHomeResponse payerHome;

    /** The Origin country payment. */
    private String originCountryPayment;

}
