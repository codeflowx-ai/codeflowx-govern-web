package es.santander.esponboapf.domain.expread;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class HolderOtherInfo.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Details of the holder")
// Holder detail
public class HolderOtherInfo {

    /**
     * The Holder code.
     */
    // Holder code
    @Schema( description = "Number identifying an holder", example = "341")
    @NotNull
    private Long holderCode;

    /** The office. */
    @Schema(description = "Office code", example = "0049")
    private String office;
}
