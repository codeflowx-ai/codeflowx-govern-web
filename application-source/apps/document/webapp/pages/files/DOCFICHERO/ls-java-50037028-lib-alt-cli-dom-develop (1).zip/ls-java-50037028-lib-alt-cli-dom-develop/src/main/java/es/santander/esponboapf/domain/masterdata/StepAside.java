package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class StepAside.
 */
// StepAside
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Campagin aside information",
example = "{\"asideTitle\":\"Tu cuenta y tu préstamo\", \"listStepAside\":"
        + "[{\"stepCode\":\"1\",\"asideName\":\"Datos personales\",\"order\":1,}]}")
public class StepAside implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 3103054592276086348L;

    /** The aside title. */
    // AsideTitle
    @Schema(description = "Aside title",
            example = "Tu cuenta y tu préstamo”,")
    private String asideTitle;

    /** The step aside. */
    // ListStepAside
    @Schema(description = "List of step aside",
            example = "{\"stepCode\":\"1\",\"asideName\":\"Datos personales\",\"order\":1}")
    private List<StepAsideDto> listStepAside;


}
