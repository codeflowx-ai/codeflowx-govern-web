package es.santander.esponboapf.domain.masterdata;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * The type Campaign account dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "Account of the campaign", example = "{\"accountCode\":10,\"accountName\":\"Cuenta Smart\","
        + "\"typeClient\":1,\"minAge\":\"18\",\"maxAge\":\"150\",\"label\":\"label text\","
        + "\"icon\":\"icon.svg\",\"chat\":true}")
public class CampaignAccountDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -8042274613252278486L;

    /**
     * The Account code.
     */
    @Schema(description = "Code of the account", example = "10")
    private Long accountCode;

    /**
     * The Account name.
     */
    @Schema(description = "Name of the account", example = "Cuenta Smart")
    private String accountName;

    /**
     * The Type client.
     */
    @Schema(description = "Client type of the account for this campaign", example = "1",
            allowableValues = {"1", "2"})
    private Integer typeClient;

    /**
     * The min age.
     * <p>
     * E.g.: 18
     */
    @Schema(description = "Minimum age for the account", maxLength = 4, example = "18")
    private String minAge;

    /**
     * The max age.
     * <p>
     * E.g.: 120
     */
    @Schema(description = "Maximum age for the account", maxLength = 4, example = "150")
    private String maxAge;

    /**
     * The Label.
     */
    @Schema(description = "Label for the account", example = "label text")
    private String label;

    /**
     * The Icon.
     */
    @Schema(description = "Icon for the account", example = "icon.svg")
    private String icon;

    /**
     * The Chat.
     */
    @Schema(description = "Chat enabled", example = "true")
    private Boolean chat;

}
