package es.santander.esponboapf.domain.expwri;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new save holder transfer dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
// Save holder transfer payment information
public class SaveHolderTransferDto {

    /** The beneficiary iban. */
    // ccc de la cuenta del titular sobre la que se realiza la transferencia
    @Schema(description = "IBAN account of the holder to which the transfer is made.",
            example = "ES1821007837171300060477")
    private String beneficiaryIban;

    /** The payer iban. */
    // IBAN ordenante
    @Schema(description = "IBAN transferor.",
            example = "ES1821007837171300060477")
    private String payerIban;

    /** The transfer state code. */
    // codigo del estado de transferencia
    @Schema(description = "Transfer status code.", example = "PE")
    private String transferStateCode;

    /** The transfer state desc. */
    // descripcion del estado de transferencia
    @Schema(description = "Transfer status description.", example = "PENDIENTE")
    private String transferStateDesc;

    // fecha en la que se hace la transferencia
    @Schema(description = "Date of transfer.", example = "28/12/2022")
    private LocalDateTime transferDate;

    /** The otp key. */
    // codigo otp
    @Schema(description = "OTP code.", example = "F154F365")
    private String otpKey;

    /** The otp expiration. */
    // fecha en la que expira la otp
    @Schema(description = "OTP expiration.", example = "29/12/2022 08:20:14")
    private LocalDateTime otpExpiration;

    /** The otp retries. */
    // intentos de confirmar la otp
    @Schema(description = "attempts to confirm the otp.", example = "1")
    private Integer otpRetries;

    /** The last operation ref. */
    @Schema(description = "Last REF operation transfer.", example = "004944671236285256")
    private String lastOperationRef;

    /** The liquidation date. */
    @Schema(description = "Date of transfer is paid", example = "28/12/2022")
    private LocalDateTime liquidationDate;

    /** The update transfer. */
    @Schema(description = "Flag to indicate whether we update the transfer or not", example = "false")
    private boolean updateTransfer;

}
