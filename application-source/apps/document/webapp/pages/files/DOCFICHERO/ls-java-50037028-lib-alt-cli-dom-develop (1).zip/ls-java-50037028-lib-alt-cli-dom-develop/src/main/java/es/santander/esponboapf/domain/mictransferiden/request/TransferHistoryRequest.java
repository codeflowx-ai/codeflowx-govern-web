package es.santander.esponboapf.domain.mictransferiden.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer history request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferHistoryRequest {

    /** The Beneficiary account. */
    private String beneficiaryAccount;

    /** The Beneficiary account local format. */
    private String beneficiaryAccountLocalFormat;

    /** The Internal contract identifier. */
    private String internalContractIdentifier;

    /** The Amount from. */
    private Double amountFrom;

    /** The Amount to. */
    private Double amountTo;

    /** The Currency. */
    private String currency;

    /** The Date from. */
    private String dateFrom;

    /** The Date to. */
    private String dateTo;

}
