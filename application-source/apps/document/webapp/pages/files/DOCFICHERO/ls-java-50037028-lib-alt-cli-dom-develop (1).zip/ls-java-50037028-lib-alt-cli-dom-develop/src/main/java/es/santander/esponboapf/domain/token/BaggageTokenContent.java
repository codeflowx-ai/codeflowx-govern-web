package es.santander.esponboapf.domain.token;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * The Class BaggageTokenContent.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Data
@Slf4j
public class BaggageTokenContent {

    /** The uid. */
    private String uid;

    /** The realm. */
    private String realm;

    /** The san tipo oficina. */
    private String sanTipoOficina;

    /** The com cod centro. */
    private String comCodCentro;

    /** The full name. */
    private String fullName;

    /** The dossier id. */
    private UUID dossierId;

    /** The holder id. */
    private UUID holderId;

    /** The dossier code. */
    private Long dossierCode;

    /** The holder code. */
    private Long holderCode;

    /**
     * From token.
     *
     * @param baggageTokenContent the baggage token content
     * @return the baggage token content
     */
    public static BaggageTokenContent fromToken(String baggageTokenContent) {

        try {
            return new ObjectMapper().readValue(
                    Base64.getDecoder().decode(Optional.ofNullable(baggageTokenContent).orElse("")),
                    BaggageTokenContent.class);
        } catch (IOException e) {
            log.trace(e.getMessage(), e);
            return null;
        }
    }

    /**
     * To token.
     *
     * @return the string
     */
    public String toToken() {
        try {
            return convertDataAndSaveInfoBaggage();
        } catch (JsonProcessingException e) {
            // We were unable to get inside this catch, so no coverage for this.
            log.trace(e.getMessage(), e);
            return null;
        }

    }

    /**
     * Convert data and save info baggage.
     *
     * @param btc the btc
     * @throws JsonProcessingException the json processing exception
     */
    protected String convertDataAndSaveInfoBaggage() throws JsonProcessingException {
        return new String(
                Base64.getEncoder()
                        .encode(new ObjectMapper().writeValueAsString(this).getBytes(Charset.defaultCharset())),
                StandardCharsets.UTF_8);
    }
}
