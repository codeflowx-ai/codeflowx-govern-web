package es.santander.esponboapf.domain.expread.recovery;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.LocalDateTimeDeserializer;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Recovery info holder dto.
 */
//The class RecoveryInfoHolderDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecoveryInfoHolderDto {

    /**
     * The Holder code.
     */
    @Schema(description = "Number identifying an holder", example = "341")
    private Long holderCode;

    /**
     * The Holder id.
     */
    @Schema(description = "UUID identifying an holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /**
     * The Priority.
     */
    @Schema(description = "Number identifying the priority", example = "1")
    private String priority;

    /**
     * The Name.
     */
    @Schema(description = "Name of the holder", example = "Jorge")
    private String name;

    /**
     * The Surname 1.
     */
    @Schema(description = "Surname1 of the holder", example = "Garcia")
    private String surname1;

    /**
     * The Surname 2.
     */
    @Schema(description = "Surname2 of the holder", example = "Ramirez")
    private String surname2;

    /**
     * The Identity type code.
     */
    @Schema(description = "Number identifying type of code", example = "1")
    private Integer identityTypeCode;

    /**
     * The Identity number.
     */
    @Schema(description = "Document identity number", example = "38268686K")
    private String identityNumber;

    /**
     * The Prefix.
     */
    @Schema(description = "Phone prefix number", example = "34")
    private String prefix;

    /**
     * The Movil.
     */
    @Schema(description = "Phone number", example = "686124154")
    private String movil;

    /**
     * The Email.
     */
    @Schema(description = "Email", example = "manuel1r223@gmail.com")
    private String email;

    /**
     * The Birth date.
     */
    @Schema( description = "Holder's birthdate (dd/MM/yyyy)", example = "07/07/1975")
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDateTime birthDate;

    /**
     * The Occupation type code.
     */
    @Schema(description = "Occupation type code", example = "2")
    private Integer occupationTypeCode;

    /**
     * The University.
     */
    @Schema(description = "Holder's university",
            example = "{\"universityCode\":2,\"universityName\":\"Universidad de Madrid\"}")
    private RecoveryInfoHolderUniversityDto university;

    /** The completed step 1 and 3. */
    @Schema(description = "Indicate if the holder has the steps 1 and 3 completed", example = "true")
    private boolean completedStep1And3;

    /** The personType. */
    //person type
    @Schema(description = "person type indicator", example = "F")
    private String personType;

    /** The personCode. */
    // The personCode
    @Schema(description = "person code indicator", example = "124661240")
    private String personCode;

    /** The type client. */
    @Schema(description = "Client type of the account for this campaign", example = "1")
    private Integer typeClient;

    /** The identification name. */
    @Schema(description = "Description of the identification of this holder", example = "1")
    private String identificationName;

    /** The is cmc blocked. */
    @Schema(description = "Indicate if cmc is blocked", example = "true")
    private Boolean isCmcBlocked;

}
