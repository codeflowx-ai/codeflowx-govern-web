package es.santander.esponboapf.domain.expwri;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class SavePurposeRequest.
 *
 * Request class to save holder's account purpose.
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Required information to save the purpose for the account creation.",
example = "{\"holderAccountPurpose\":{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"purposeAccountCode\":1,\"investmentOperations\":[1,2]}}")
// Save purpose request
public class SavePurposeRequest extends DossierParentDto {

    /**
     * The holder account purpose.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     */
    @Schema(description = "Information about the purpose why the holder is opening an account.",
            example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
                    + "\"purposeAccountCode\":1,\"investmentOperations\":[1,2]}")
    @Valid
    @NotNull
    private SavePurposeHolderDto holderAccountPurpose;

}
