package es.santander.esponboapf.domain.enums;

import java.util.Arrays;

import lombok.Getter;

/**
 * Identify Person Document types
 *
 * @author Santander Tecnología
 *
 */
@Getter
public enum IdentityPersonDocumentTypeEnum {

    /** The nif. */
    NIF("N", 1, "NIF"),

    /** The dni. */
    DNI("N", 1, "DNI"),

    /** The tarjeta residencia. */
    TARJETA_RESIDENCIA("C", 2, "NIE"),

    /** The pasaporte. */
    PASAPORTE("I", 3, "PASSPORT");

    /** the code of tipo identity document */
    private String codIdentityPersonDocument;

    /** the code of type identity for HC */
    private int identityPersonCode;

    /** The name. */
    private String name;

    IdentityPersonDocumentTypeEnum(String codIdentityPersonDocument, int identityPersonCode, String name) {
        this.codIdentityPersonDocument = codIdentityPersonDocument;
        this.identityPersonCode = identityPersonCode;
        this.name = name;
    }

    /**
     * Obtiene el DocumentTypeEnum asociado a un codigo de tipo de documento.
     *
     * @param codIdentityPersonDocument codigo tipo de documento
     * @return IdentityPersonDocumentTypeEnum
     */
    public static IdentityPersonDocumentTypeEnum valueOfByCodIdentityPersonDocument(String codIdentityPersonDocument) {
        return Arrays.asList(IdentityPersonDocumentTypeEnum.values()).stream()
                .filter(dte -> dte.getCodIdentityPersonDocument().equalsIgnoreCase(codIdentityPersonDocument))
                .findFirst().orElse(null);
    }

    /**
     * Obtiene el DocumentTypeEnum asociado a un codigo de tipo de documento.
     *
     * @param codIdentityPersonDocument codigo tipo de documento
     * @return IdentityPersonDocumentTypeEnum
     */
    public static IdentityPersonDocumentTypeEnum valueOfByIdentityPersonCode(int codIdentityPersonDocument) {
        return Arrays.asList(IdentityPersonDocumentTypeEnum.values()).stream()
                .filter(dte -> dte.getIdentityPersonCode() == codIdentityPersonDocument)
                .findFirst().orElse(null);
    }

    /**
     * Obtiene el DocumentTypeEnum asociado a un codigo de tipo de documento.
     *
     * @param name nombre tipo de documento
     * @return IdentityPersonDocumentTypeEnum
     */
    public static IdentityPersonDocumentTypeEnum valueOfByName(String name) {
        return Arrays.asList(IdentityPersonDocumentTypeEnum.values()).stream()
                .filter(dte -> dte.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }

}
