package es.santander.esponboapf.domain.sas;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Sas Credentials Entity request.
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class SasCredentialsDtoRequest {

    /** The credential type. */
    private List<String> credentialType;

    /** The id attributes. */
    private IdAttributes idAttributes;

    /** The password. */
    private String password;

    /** The realm. */
    private String realm;

    /**
     * The Id Attributes class through record.
     *
     * @param alias            the alias
     * @param companyId        the company Id
     * @param contractNumber   the contract Number
     * @param creditCardNumber the credit Card Number
     * @param documentCode     the document Code
     * @param documentType     the document Type
     * @param mobile           the mobile
     * @param personalId       the personalId
     * @param uid              the uid
     */

    @Builder
    public record IdAttributes(String alias, String companyId, String contractNumber, String creditCardNumber,
            String documentCode, String documentType, String mobile, String personalId, String uid) {
        // Sonar asks for a comment here, so we add a comment here. A critical, seriously?
    }

}
