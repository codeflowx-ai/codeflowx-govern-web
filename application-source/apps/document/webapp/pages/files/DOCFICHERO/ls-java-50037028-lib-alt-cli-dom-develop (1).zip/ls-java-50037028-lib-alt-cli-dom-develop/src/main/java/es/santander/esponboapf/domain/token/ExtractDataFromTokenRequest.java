package es.santander.esponboapf.domain.token;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ExtractDataFromTokenRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
// Extract data from token
public class ExtractDataFromTokenRequest {

    /** The token. */
    // General token
    private String token;

}
