package es.santander.esponboapf.domain.docmanager.signrecord;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;

/**
 * The Class FilenetDocSign.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class FilenetDocSign {

    /** The codgdoc. */
    @Builder.Default
    private String codgdoc = "MV";

    /** The person number doc. */
    private String personNumberDoc;

    /** The type doc. */
    private String typeDoc;

    /** The gn id. */
    private String gnId;

    /** The num sign rea. */
    private int numSignRea;

    /** The num sign req. */
    @Builder.Default
    private int numSignReq = 1;

    /** The ind pre contract. */
    @Builder.Default
    private String indPreContract = "N";

    /** The ind dig sealing. */
    @Builder.Default
    private String indDigSealing = "S";

    /** The status. */
    @Builder.Default
    private String status = "01";

    /** The signers. */
    @Singular
    private List<FilenetSigner> signers;
}
