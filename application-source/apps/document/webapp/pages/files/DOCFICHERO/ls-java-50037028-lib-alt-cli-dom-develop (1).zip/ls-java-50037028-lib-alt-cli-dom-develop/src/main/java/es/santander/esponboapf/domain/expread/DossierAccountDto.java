package es.santander.esponboapf.domain.expread;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierAccountDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder(toBuilder = true)
@Schema(description = "Information to display in the header of the dossier.",
        example = "{\"dossierId\": \"1abe4f7c-d843-477d-b1c8-d181410c1a47\"," +
                "\"iban\": \"ES26 0049 2594 6025 1500 0446\"}")
// DossierAccountDto
public class DossierAccountDto {

    /**
     * The Dossier id.
     */
    // DossierId
    @Schema(description = "UUID identifying a dossier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String dossierId;

    /** The iban. */
    // Iban
    @Schema(description = "Account number in IBAN format", example = "ES0700492594682815000250")
    private String iban;

    /** The account blocked by ucar. */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Schema(description = "Is the account blocked by ucar?", example = "false")
    // accountBlockedByUcar
    private Boolean accountBlockedByUcar;

}
