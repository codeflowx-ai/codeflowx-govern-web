package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Universal only holder.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
@Schema(description = "Basic structure to be used by onboarding and backoffice services",
        example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"holderCode\":1}")
public class UniversalOnlyHolder {

    /**
     * The holder id.
     * <p>
     * Unique holder identifier. Used by onboarding services. Null otherwise.
     * E.g.: '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(description = "Unique holder identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /**
     * The holder code.
     * <p>
     * Internal holder code. Used by backoffice services. Null otherwise.
     * E.g.: 1
     */
    @Schema(description = "Internal holder code. Used by backoffice services. Null otherwise.",
            example = "1")
    private Long holderCode;

}
