package es.santander.esponboapf.domain.expread;

import java.util.List;

import es.santander.esponboapf.domain.masterdata.IdentificationStateDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderIdentificationResponse.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information about holder identification")
// HolderIdentificationResponse
public class HolderIdentificationResponse {

    /** The list identification state. */
    // List identification state
    @Schema(description = "List of identification state")
    private List<IdentificationStateDto> listIdentificationState;

    /** The skip identification. */
    // Skip identification
    @Schema(description = "If the holder can skip identification", example = "true")
    private boolean skipIdentification;

    /** The accesscode complete. */
    // Access code complete
    @Schema(description = "If the holder already done the access code step", example = "false")
    private boolean accesscodeComplete;

    /** The is identification by transfer. */
    // Is identification by transfer
    @Schema(description = "If is identification by transfer", example = "true")
    private boolean isIdentificationByTransfer;

    /** The code flow. */
    // Code flow
    @Schema(description = "Indicator with code flow ", example = "PP002")
    private String codeFlow;

}
