package es.santander.esponboapf.domain.fraud;

import javax.validation.Valid;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FraudResponse.
 *
 * Fraud detection information.
 */
@NoArgsConstructor
@Data
@Schema(description = "Fraud detection information.")
public class FraudResponse {

    /**
     * The result.
     *
     * The fraud process result.
     * True = no rules, false = some rules.
     */
    @Schema( description = "The fraud detection process result. True = no rules, false = some rules.",
            example = "true")
    private boolean result;

    /**
     * The report.
     *
     * Information received and processed about the fraud detection process.
     */
    @Schema( description = "Information received and processed about the fraud detection process.",
            example = "{\"guid\":\"a4f5121f-0aef-494d-a8e4-b0a9dd8c6070\","
                    + "\"requestNumber\":2455,\"decisionResult\":\"01\","
                    + "\"cancelDossier\":true,\"rules\":[{\"holderCode\":102,\"ruleCode\":15}],"
                    + "\"errorCode\":1303,\"errorMessage\":\"El GUID ya existe en el sistema\"}")
    @Valid
    private ReportFraudDto report;

}
