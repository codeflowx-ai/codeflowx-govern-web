package es.santander.esponboapf.domain.api.services;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class TransferIncomingMessageDto.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
// TransferIncomingMessageDto
public class TransferIncomingMessageDto {

    /** The code. */
    // Code
    @Schema(description = "Message code", example = "TD001")
    private String code;

    /** The description. */
    // Description
    @Schema(description = "Message description", example = "functional error")
    private String description;

}
