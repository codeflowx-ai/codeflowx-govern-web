package es.santander.esponboapf.domain.api.services;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class RetrieveDocsBySignerRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// RetrieveDocsBySignerRequest
public class RetrieveDocsBySignerRequest {

    /** The id exp sec. */
    // Id exp
    @NotNull
    @Schema(description = "Sign Expedient's identifier.", example = "16")
    private Integer idExpSec;

    /** The signer. */
    // Signer
    @NotNull
    @Schema(description = "Signer identifier.", example = "F124649583")
    private String signer;

}
