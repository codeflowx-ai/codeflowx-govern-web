package es.santander.esponboapf.domain.expwri;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ActivationDataDto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ActivationDataDto {

    /** The dossier code. */
    private Long dossierCode;

    /** The partenon. */
    private String partenon;

    /** The local account. */
    private String localAccount;

}
