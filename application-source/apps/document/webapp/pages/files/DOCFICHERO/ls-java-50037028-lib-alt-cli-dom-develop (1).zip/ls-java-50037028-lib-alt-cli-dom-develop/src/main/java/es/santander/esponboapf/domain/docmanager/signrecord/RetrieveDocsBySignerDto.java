package es.santander.esponboapf.domain.docmanager.signrecord;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class RetrieveDocsBySignerRequest.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
// RetrieveDocsBySignerDto
public class RetrieveDocsBySignerDto {

    /** The id sign expedient. */
    // Id sign expedient
    @Schema( description = "Sign Expedient's identifier.", example = "1432")
    private Integer idSignExpedient;

    /** The person type. */
    // Person type
    @Schema( description = "Holder´s type person bdp", example = "F")
    private String personType;

    /** The person code. */
    // Person code
    @Schema( description = "Holder´s code person bdp", example = "124649583")
    private String personCode;

}
