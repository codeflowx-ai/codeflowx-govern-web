package es.santander.esponboapf.domain.expwri;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The Class SaveOccupationRequest.
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Required information to save the current holder occupation.")
public class SaveOccupationRequest extends DossierParentDto {

    // datos profesionales asociados al titular
    // que realiza el onboarding digital
    /**
     * The holder occupation.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     */
    @Schema(description = "Information about the current holder occupation.")
    @Valid
    @NotNull
    private SaveOccupationHolderDto holderOccupation;

}
