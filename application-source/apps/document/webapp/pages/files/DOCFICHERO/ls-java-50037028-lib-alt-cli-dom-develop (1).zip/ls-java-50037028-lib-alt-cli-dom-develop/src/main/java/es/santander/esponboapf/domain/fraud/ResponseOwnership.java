package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ResponseOwnership.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// ResponseOwnership
public class ResponseOwnership {

    /** The reference */
    //reference
    @Schema(description = "Reference from iberpay", 
            example = "TIC00499020202206160000000000000005NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN")
    private String reference;

}
