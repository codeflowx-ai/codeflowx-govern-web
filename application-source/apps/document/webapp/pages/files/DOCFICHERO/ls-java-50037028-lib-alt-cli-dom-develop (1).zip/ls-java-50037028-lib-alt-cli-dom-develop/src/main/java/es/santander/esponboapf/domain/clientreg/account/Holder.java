package es.santander.esponboapf.domain.clientreg.account;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new Holder.
 */
//The class Holder
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Input object Holder avtivation account request",
        example = "{\"personType\":\"F\", \"personCode\":\"124661240\", "
                + "\"order\":1,\"nimDomicilio\":\"12\"}")
public class Holder implements Comparable<Holder> {

    /** The personType. */
    //person type
    @NotNull
    @Schema(description = "person type indicator", example = "F")
    private String personType;

    /** The personCode. */
    // The personCode
    @NotNull
    @Schema(description = "person code indicator", example = "124661240")
    private String personCode;

    /** The order. */
    // The order
    @NotNull
    @Schema(description = "intervention type order indicator", example = "1")
    private Integer order;

    /** The numDomicilio. */
    // The numDomicilio
    @NotNull
    @Schema(description = "The Home number", example = "1")
    private String numDomicilio;

    /**
     * Compare to.
     *
     * @param o the o
     * @return the int
     */
    @Override
    public int compareTo(Holder o) {
        return this.getOrder().compareTo(o.getOrder());
    }

}
