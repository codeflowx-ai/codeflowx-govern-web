package es.santander.esponboapf.domain.corresp;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class OtpRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@Schema(description = "Mandatory information to be able to generate an OTP key.", 
          example = "\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\", "
                  + "\"fullPhoneNumber\":\"0034666666666\"")
// OTP request
public class OTPRequest {

    /**
     * The holder id.
     * <p>
     * The holder's identifier.
     */
    @Schema(maxLength = 100, description = "Unique holder identifier. ",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    // the phone number should have the prefix code
    // as 00[prefix code] instead of +[prefix code]
    /**
     * The full phone number.
     * <p>
     * The holder's full phone number.
     */
    @Schema(maxLength = 100,
            description = "Full phone number (including international prefix) where the sms with the OTP key "
                    + "will be sent to. ",
            example = "0034666666666")
    @XssValid
    @NotNull
    private String fullPhoneNumber;

}
