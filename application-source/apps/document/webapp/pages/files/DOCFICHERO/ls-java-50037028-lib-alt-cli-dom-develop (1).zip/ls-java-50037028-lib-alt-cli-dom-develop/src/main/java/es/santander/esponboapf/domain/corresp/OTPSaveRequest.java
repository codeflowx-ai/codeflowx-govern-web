package es.santander.esponboapf.domain.corresp;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class OTPSaveRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Mandatory information to save a holder OTP key.", 
    example = "{ \"expirationMinutes\": 2, \"retries\":3}")
public class OTPSaveRequest extends OTPValRequest {

    /**
     * The expiration minutes.
     * E.g.: 5
     */
    @Schema(maxLength = 100, description = "Minutes to expire the key. ", example = "5")
    private Integer expirationMinutes;

    /**
     * The retries.
     * E.g.: 3
     */
    @Schema(maxLength = 100, description = "Maximum number of retries in case validation goes wrong.", example = "3")
    private Integer retries;

}
