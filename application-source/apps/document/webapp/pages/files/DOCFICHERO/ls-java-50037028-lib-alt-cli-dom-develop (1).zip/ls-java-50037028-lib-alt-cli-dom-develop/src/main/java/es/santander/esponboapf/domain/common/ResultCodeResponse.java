package es.santander.esponboapf.domain.common;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Result code response.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
@Schema(description = "Response from a service.", example = "{\"result\":true,\"message\":{}}")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResultCodeResponse {

    /** The result. */
    // The result
    @Schema(description = "Result status. True or false.", example = "false")
    private boolean result;

    /**
     * The Code.
     */
    // The code
    @Schema(description = "Code of the error.", example = "SV001")
    private String code;

}
