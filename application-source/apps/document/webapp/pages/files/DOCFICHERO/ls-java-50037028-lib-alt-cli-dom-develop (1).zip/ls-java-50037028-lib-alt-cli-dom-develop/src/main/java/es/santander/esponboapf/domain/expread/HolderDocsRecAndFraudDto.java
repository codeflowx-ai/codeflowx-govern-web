package es.santander.esponboapf.domain.expread;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new HolderDocsRecAndFraudDto.
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information about holder documents and fraud",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"allDocsREC\":true, "
        + "\"existsFraud\":true,\"accountActivation\":true,"
        + "\"stepCode\":6,\"stepState\":\"R\"\"identityRealized\":true}")
// Holder docs required and fraud
public class HolderDocsRecAndFraudDto {

    /** The Holder Id. */
    // Holder id
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /** Indicates if he has all documents in REC status. */
    // All docs required
    @Schema(description = "All documents REC", example = "true")
    private boolean allDocsREC;

    /** Indicates if he has any document in RPV status. */
    // Any doc pending validation
    @Schema(description = "Any document RPV", example = "true")
    private boolean anyDocRPV;

    /** Indicates if the holder has any Fraud */
    // Exist fraud
    @Schema(description = "Exists any fraud", example = "true")
    private boolean existsFraud;

    /** Indicates if the account can be activated */
    // Account activation
    @Schema(description = "Validation indicator to activate an account", example = "true")
    private boolean accountActivation;

    /** Indicates the step code */
    // Step code
    @Schema(description = "Code of the step", example = "6")
    private Integer stepCode;

    /** Indicates the step state */
    // Step state
    @Schema(description = "State to put a step", example = "R")
    @Pattern(regexp = "[A-Z]*")
    private String stepState;
    
    /** The identity realized. */
    // Identity realized
    @Schema(description = "Indicate if the identity is realized", example = "true")
    private boolean identityRealized;

}
