package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Identification state dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Identification state dto
public class IdentificationStateDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 2002819010889912239L;

    /**
     * The Identification code.
     */
    // Identification code
    @Schema(description = "Identification state identifier", example = "R")
    private String identificationCode;

    /**
     * The Identification name.
     */
    // Identification name
    @Schema(description = "Identification state name", example = "realizada")
    private String identificationName;

}
