package es.santander.esponboapf.domain.fraud;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Consult request result info dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsultRequestResultInfoDto {

    /**
     * The Http code.
     */
    private Integer httpCode;

    /**
     * The Http message.
     */
    private String  httpMessage;

    /**
     * The More information.
     */
    private String moreInformation;

}
