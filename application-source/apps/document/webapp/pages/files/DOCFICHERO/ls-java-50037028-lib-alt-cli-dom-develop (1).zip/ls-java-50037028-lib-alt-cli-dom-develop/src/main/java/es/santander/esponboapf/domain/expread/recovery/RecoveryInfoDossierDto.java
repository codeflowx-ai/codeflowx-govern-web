package es.santander.esponboapf.domain.expread.recovery;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Recovery info dossier dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RecoveryInfoDossierDto {

    /**
     * The Dossier code.
     */
    @Schema(description = "Number identifying a dossier", example = "341")
    private Long dossierCode;

    /**
     * The Dossier id.
     */
    @Schema(description = "UUID identifying a dossier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String dossierId;

    /**
     * The Office code.
     */
    @Schema(description = "Dossier's office code", example = "0148")
    private String officeCode;
    
    /** The promotional code. */
    @Schema(description = "Promotional code.", example = "536345634563")
    private String promotionalCode;

    /** The is multi holder. */
    @Schema(description = "Indicate if the dossier has multiholder.", example = "false")
    private Boolean isMultiHolder;

    /** The num holders. */
    @Schema(description = "Number of holders currently in this dossier.", example = "1")
    private Integer numHolders;

    /** The all holders complete step 1 and 3. */
    @Schema(description = "Indicate if all the holders from a dossier have the steps 1 and 3 completed",
            example = "false")
    private Boolean allHoldersCompleteStep1And3;
    
    /** The expiration date. */
    @Schema(description = "Process expiration days", example = "19")
    private Integer daysToCancel;
    
    /**
     * The Agent.
     */
    @Schema(description = "Dossier's Agent", example = "{\"identityNumber\":\"11111111H\","
            + "\"identityType\":\"1234\",\"fullName\":\"Nombre completo agente\"}")
    private RecoveryInfoAgentDto agent;

    /**
     * The Account.
     */
    @Schema(description = "Dossier's account", 
            example = "{\"accountCode\":221,\"accountName\":\"Cuenta online\"}")
    private RecoveryInfoAccountDto account;

    /**
     * The Campaign.
     */
    @Schema(description = "Dossier's campaign", 
            example = "{\"campignCode\":341,\"typeOffice\":\"virtual\",\"officeCode\":\"2222\"}")
    private RecoveryInfoCampaignDto campaign;

    /** The state code. */
    @Schema(description = "Dossier status identifier code.", example = "1")
    private Integer stateCode;

}
