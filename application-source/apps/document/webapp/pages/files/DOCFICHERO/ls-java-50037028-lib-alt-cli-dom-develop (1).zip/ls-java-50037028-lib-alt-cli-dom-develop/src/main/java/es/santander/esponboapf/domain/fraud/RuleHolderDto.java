package es.santander.esponboapf.domain.fraud;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RuleHolderDto.
 *
 * Fraud detection rule.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Fraud detection rule.", 
example = "{\"holderCode\":102,\"ruleCode\":15}")
public class RuleHolderDto {

    /**
     * The holder code.
     *
     * Code to a holder whom this detected fraud rule is assigned to.
     * E.g.: 102
     */
    @Schema( description = "Code to a holder whom this detected fraud rule is assigned to. ",
            example = "102")
    @NotNull
    private Long holderCode;

    /**
     * The rule code.
     *
     * Code of a fraud rule assignet to a holder
     * E.g.: 15
     */
    @Schema( description = "Code of a fraud rule assignet to a holder.", example = "15")
    @NotNull
    private Integer ruleCode;

}
