package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import es.santander.esponboapf.domain.validation.annotations.UniversalBothIdValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class UniversalDossier.
 *
 * Basic structure to be used by onboarding and backoffice services.
 *
 * The @UniversalDossierValid annotation below will validate that only one of
 * the
 * fields is null whenever a @Valid annotation is used.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Basic structure to be used by onboarding and backoffice services",
example = "{\"dossierId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\"}")
@SuperBuilder
@UniversalBothIdValid
public class UniversalBothId extends UniversalHolder {

    /**
     * The dossier id.
     *
     * Unique dossier identifier. Used by onboarding services. Null otherwise.
     * E.g.: '80fd7423-5759-445b-a92f-6e88f514cc00'
     *
     */
    @Schema(description = "Unique dossier identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID dossierId;

}
