package es.santander.esponboapf.domain.expread.recovery;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Recovery info agent dto.
 */
//The class RecoveryInfoAgentDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecoveryInfoAgentDto {

    /**
     * The Identity number.
     */
    @Schema(description = "Agent's identity number", example = "11111111H")
    private String identityNumber;

    /**
     * The Identity type.
     */
    @Schema(description = "Agent's identity type", example = "1234")
    private String identityType;

    /**
     * The Full name.
     */
    @Schema(description = "Agent's full name", example = "Nombre completo agente")
    private String fullName;

}
