package es.santander.esponboapf.domain.masterdata;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Campaign metric dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Schema(description = "Metrics of the campaign")
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
// CampaignMetricDto
public class CampaignMetricDto implements Serializable {

    @Serial
    private static final long serialVersionUID = -6687373727569858530L;

    /**
     * The Product.
     */
    // Product
    private List<String> product;

    /**
     * The Product name.
     */
    // Product name
    private List<String> productName;

    /**
     * The Product category.
     */
    // Product category
    private List<String> productCategory;

    /**
     * The Product subcategory.
     */
    // Product subcategory
    private List<String> productSubcategory;

}
