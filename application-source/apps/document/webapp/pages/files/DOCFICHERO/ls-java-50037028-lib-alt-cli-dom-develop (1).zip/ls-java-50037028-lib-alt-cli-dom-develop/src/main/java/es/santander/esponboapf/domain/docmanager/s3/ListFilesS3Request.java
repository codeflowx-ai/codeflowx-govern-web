package es.santander.esponboapf.domain.docmanager.s3;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;

/**
 * The type List files s 3 request.
 */
//The class ListFilesS3Request
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ListFilesS3Request {

    /**
     * The Folder.
     */
    //Folder
    @Schema(description = "Folder(s) route", example = "1/IDENTIFICACION")
    @Pattern(regexp = "[\\w/]+")
    private String folder;

    /**
     * The Filename.
     */
    @Schema(description = "Folder(s) route", example = "example.txt")
    @Pattern(regexp = "[\\w.]*")
    private String filename;

}
