package es.santander.esponboapf.domain.docmanager.s3;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * The type Holder document data dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderDocumentDataDto {

    /**
     * The Document ar.
     */
// Document anverse or reverse
    @Schema(description = "Document anverse or reverse", example = "A")
    @Pattern(regexp = "[AR]")
    private String documentAR;

    /**
     * The extension.
     */
// Extension
    @Schema(description = "The file extension", example = "jpg")
    @Size(min = 2, max = 5)
    @NotBlank
    @Pattern(regexp = "[\\w]+")
    private String extension;

    /**
     * The document base 64
     */
// Document in base 64
    @Schema(description = "Document data", example = "BASE64 encoded file")
    private String documentBase64;

}
