package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer history payer home response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferHistoryPayerHomeResponse {

    /** The Domicile. */
    private String domicile;

    /** The Square. */
    private String square;

    /** The Country. */
    private String country;

}
