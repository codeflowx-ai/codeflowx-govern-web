package es.santander.esponboapf.domain.docmanager.uploaddoc;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;

/**
 * The type Upload document request document test.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class UploadDocumentRequestDocument {

    /**
     * The priority.
     * <p>
     * Number identifying the priority.
     * E.g.: '1'
     */
    @Schema(description = "Number identifying the priority", example = "1")
    @NotBlank
    @Pattern(regexp = "^[0-9]?$")
    private String priority;

    /**
     * The doc type code.
     * <p>
     * E.g.: 1
     */
    @Schema(description = "Document type code", example = "1")
    @NotNull
    private Integer docTypeCode;

    /**
     * The document code.
     * <p>
     * E.g.: 1
     */
    @Schema(description = "Document code", example = "1")
    @NotNull
    private Integer documentCode;

    /**
     * The File param.
     */
    @Schema(description = "List of params of this document", example = "param1")
    private List<String> fileParam;

}
