package es.santander.esponboapf.domain.valcli;

import com.fasterxml.jackson.annotation.JsonInclude;

import es.santander.esponboapf.domain.common.ResultCodeResponse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * ExpressValidationResponse
 *
 * The Class ExpressValidationResponse.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
@Schema(description = "Response from a service.", example = "{\"result\":true,\"message\":{}}")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExpressValidationResponse extends ResultCodeResponse {

    /**
     * The Full Name.
     */
    // The full name
    @Schema(description = "Full name of holder in case of already customer error.", example = "Full Name Example")
    private String fullName;

}
