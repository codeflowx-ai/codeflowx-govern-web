package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new holder contact response.
 */

@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Information about dossier related to signexpId")
public class SignedDocumentExpedientInfo  {

    /** The contract name. */
    @Schema(description = "The contract signexpId", example = "Condiciones particulares")
    private Long signexpId;

    /**
     * Instantiates a new holder contact response.
     *
     * @param signexpId the signexp id
     */
    public SignedDocumentExpedientInfo(Long signexpId) {

        this.signexpId = signexpId;
    }

}
