package es.santander.esponboapf.domain.expread;

import java.util.UUID;

import es.santander.esponboapf.domain.expwri.SaveHolderContactResponse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new holder contact response.
 */

@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Information about dossier related to a holder",
        example = "{\"accountCode\":221,\"daysToCancel\":13}")
public class HolderContactResponse extends SaveHolderContactResponse {

    /**
     * The campaign code.
     *
     * The campaign code which the dossier will be based in.
     */
    @Schema(description = "Campaign chosen by the holder to be contracted", example = "221")
    private Integer campaignCode;

    /**
     * The account code.
     *
     * The account code which the dossier will be based in.
     */
    @Schema(description = "Account chosen by the holder to be contracted", example = "221")
    private Long accountCode;

    /** The campaign expired. */
    @Schema(description = "Campaign expired or not", example = "true")
    private Boolean xp;

    /** The expiration date. */
    @Schema(description = "Process expiration days", example = "19")
    private Integer daysToCancel;

    /** The priority. */
    @Schema(description = "Number identifying the priority", example = "1")
    private String priority;
    
    /** The tp. */
    @Schema(description = "Type clients´s holder", example = "1")
    private Integer tp;

    /** The lopd read. */
    @Schema(description = "Indicates whether the LOPD document has been read.", example = "true")
    private boolean lopdRead;

    /** The precon and commissions read. */
    @Schema(description = "Indicates whether the Pre-contractual and Commissions documents have been read.",
            example = "false")
    private boolean preconAndCommissionsRead;

    /**
     * Instantiates a new holder contact response.
     *
     * @param dossierId    the dossier id
     * @param holderId     the holder id
     * @param accountCode  the account code
     * @param daysToCancel the days to cancel
     * @param priority     the priority
     */
    public HolderContactResponse(UUID dossierId, UUID holderId, Long accountCode, Integer daysToCancel,
            String priority) {
        super(dossierId, holderId, daysToCancel);
        this.accountCode = accountCode;
        this.daysToCancel = daysToCancel;
        this.priority = priority;
    }

}
