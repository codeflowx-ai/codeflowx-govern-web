package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

/**
 * The Class CancelSignExpSec.
 */
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
// Cancel sign exp sec
public class CancelSignExpSec extends CancelSignRecordRequest {

    /** The id exp sec. */
    // ID exp sec
    private long idExpSec;
}
