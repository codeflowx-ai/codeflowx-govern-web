package es.santander.esponboapf.domain.clientreg.account;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class ExternalResponseRegisterAccount.
 */
//The class ExternalResponseRegisterAccount
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@Schema(description = "Output object activation account response", example = "{\"accountInformation\":["
        + "{\"accountIdType\":\"TXT\\\", \"accountId\":\"004912342410000619\"}], "
        + "\"indicatorPassbook\":true, \"indicatorTalon\":true}")
public class ExternalResponseRegisterAccount {

    /**
     * accountInformation
     */
    // The account information list
    @Schema(description = "The account information list", example = "\"accountIdType\":\"TXT\","
            + " \"accountId\":\"004912342410000619\"")
    private List<InputAccountIdentification> accountInformation;

    /**
     * indicatorPassbook
     */
    // The pass book indicator
    @Schema(description = "pass book indicator", example = "true")
    private boolean indicatorPassbook;
    /**
     * indicatorTalon
     */
    // The talon indicator
    @Schema(description = "talon indicator", example = "true")
    private boolean indicatorTalon;

}
