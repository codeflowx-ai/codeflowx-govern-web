package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import es.santander.esponboapf.domain.validation.annotations.UniversalHolderValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class UniversalHolder.
 *
 * Basic structure to be used by onboarding and backoffice services.
 *
 * The @UniversalHolderValid annotation below will validate that only one of the
 * fields is null whenever a @Valid annotation is used.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
@Schema(description = "Basic structure to be used by onboarding and backoffice services",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"dossierCode\":1}")
@UniversalHolderValid
public class UniversalHolder {

    /**
     * The holder id.
     *
     * Unique holder identifier. Used by onboarding services. Null otherwise.
     * E.g.: '80fd7423-5759-445b-a92f-6e88f514cc00'
     *
     */
    @Schema(description = "Unique holder identifier. Used by onboarding services. Null otherwise.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /**
     * The dossier code.
     *
     * Internal dossier code. Used by backoffice services. Null otherwise.
     * E.g.: 1
     */
    @Schema(description = "Internal dossier code. Used by backoffice services. Null otherwise.",
            example = "1")
    private Long dossierCode;
}
