package es.santander.esponboapf.domain.api.services;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class InfoStepsDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InfoStepsDto {

    /** The step code. */
    // StepCode
    @Schema(description = "Holder's step code", example = "2")
    private Integer stepCode;

    /** The step state code. */
    // StepStateCode
    @Schema(description = "Holder's step status code", example = "R")
    private String stepStateCode;

}
