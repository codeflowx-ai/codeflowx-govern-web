package es.santander.esponboapf.domain.office;

import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier office data dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierOfficeDataDto {

    /** The Dossier code. */
    private Long dossierCode;

    /** The Dossier id. */
    private UUID dossierId;

    /** The Campaign code. */
    private Integer campaignCode;

    /** The Register date. */
    private String registerDate;

    /** The Office code. */
    private String officeCode;

    /** The state code. */
    private Integer stateCode;

    /** The State name. */
    private String stateName;

    /** The Substate name. */
    private String substateName;

    /** The Cancel reason. */
    private String cancelReason;

    /** The is cancel by fraud. */
    private Boolean isCancelByFraud;

    /** The Account code. */
    private Integer accountCode;

    /** The Account name. */
    private String accountName;

    /** The Iban. */
    private String iban;

    /** The Holders. */
    private List<HolderOfficeDataDto> holders;

    /** The show validate fraud. */
    private Boolean showValidateFraud;

}
