package es.santander.esponboapf.domain.sas;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type SasCredentialsEntity response
 *
 * @author Vector ITC Group
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class SasCredentialsDtoResponse {

    /** jwt **/
    private String jwt;

    /** cookieCorp **/
    private String cookieCorp;

    /** tokenCorp **/
    private String tokenCorp;

}
