package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Save identification dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Holder identification data object
public class SaveIdentificationDto {

    /** The identification state code. */
    // identification state code
    @Schema(description = "Code of the selected identification state", example = "R")
    private String identificationStateCode;

    /** The identification code. */
    // identification code
    @Schema(description = "Code identifying the type of identification.", example = "4")
    private Integer identificationCode;

    /** The Reject reason. */
    // Reject reason
    @Schema(description = "Description of the reject reason.", nullable = true, example = "transferencia ilicita")
    private String rejectReason;

    /** The Pex. */
    @Schema(description = "Pex number of a document", example = "24G6E2TR")
    @Pattern(regexp = "[a-zA-Z0-9-_\\/ ]*")
    @Size(max = 20)
    private String pex;

}
