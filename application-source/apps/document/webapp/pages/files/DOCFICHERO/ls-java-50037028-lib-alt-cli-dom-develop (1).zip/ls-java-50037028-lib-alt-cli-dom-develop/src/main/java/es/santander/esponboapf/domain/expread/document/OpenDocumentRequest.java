package es.santander.esponboapf.domain.expread.document;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class OpenDocumentRequest
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Info about a document, for service consult document on documentation screen",
example = "{\"dossierCode\":63,\"holderCode\":341,\"priority\":\"341\",\"personCode\":\"12896587\","
        + "\"docTypeCode\":1,\"documentCode\":1,\"filenameS3\",\"file.jpg\"}")
// Open document request
public class OpenDocumentRequest {

    /** The dossier code. */
    // Dossier code
    @Schema(description = "Dossier code", example = "63")
    @NotNull
    private Long dossierCode;

    /** The holder code. */
    // Holder code
    @Schema(description = "Number identifying an holder", example = "341")
    @NotNull
    private Long holderCode;

    /** The priority. */
    // Priority
    @Schema(description = "Holder's priority", example = "341")
    @NotNull
    private String priority;

    /** The person code. */
    // Person code
    @Schema(description = "Holder's priority", example = "12896587")
    private String personCode;

    /** The doc type code. */
    // Doc type code
    @Schema(description = "Document type identifier", example = "1")
    @NotNull
    private Integer docTypeCode;

    /**
     * The document code.
     *
     * E.g.: 1
     */
    // Document code
    @Schema(description = "Document code", example = "1")
    @NotNull
    private Integer documentCode;

    /**
     * Filename s3
     */
    // Filename s3
    @Schema(description = "Filename s3", example = "file.jpg")
    private String filenameS3;

}
