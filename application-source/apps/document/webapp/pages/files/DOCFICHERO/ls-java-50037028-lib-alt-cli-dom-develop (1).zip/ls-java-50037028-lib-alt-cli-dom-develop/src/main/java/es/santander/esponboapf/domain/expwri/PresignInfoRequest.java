package es.santander.esponboapf.domain.expwri;

import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class PresignInfoRequest.
 */
//The class PresignInfoRequest
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
@Schema(description = "Request dto with information to presign info")
public class PresignInfoRequest {

    /** The holder id. */
    // The holder id
    @Schema(description = "Holder id", example = "9f0604e6-cd74-4bd0-a0db-24a7d054fd74")
    @NotNull
    private UUID holderId;

    /** The signexp id. */
    // The signexp id
    @NotNull
    @Schema(description = "Signed expedient Id", example = "2")
    private Long signexpId;

    /** The holder contract. */
    // The holder contract
    @NotNull
    @Schema(description = "The contract holder list")
    private List<HolderContractDto> holderContract;

}
