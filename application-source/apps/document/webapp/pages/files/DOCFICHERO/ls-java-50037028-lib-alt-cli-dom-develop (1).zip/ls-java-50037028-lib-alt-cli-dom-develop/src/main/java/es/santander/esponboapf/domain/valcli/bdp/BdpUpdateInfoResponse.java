package es.santander.esponboapf.domain.valcli.bdp;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class BdpUpdateInfoResponse.
 */
//The class BdpUpdateInfoResponse
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
@EqualsAndHashCode(callSuper = true)
public class BdpUpdateInfoResponse extends BdpUpdateInfoBBDDResponse {

    /** The info tax list. */
    //infoTaxList
    private List<BdpUpdateInfoTaxResponse> infoTaxList;
}
