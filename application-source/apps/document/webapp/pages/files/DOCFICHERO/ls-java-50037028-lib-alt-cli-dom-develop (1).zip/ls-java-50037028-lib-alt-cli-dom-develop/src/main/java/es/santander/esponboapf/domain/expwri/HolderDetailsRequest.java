package es.santander.esponboapf.domain.expwri;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import es.santander.esponboapf.domain.expread.HolderInfoDetailsDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new holder details request.
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
// Holder details request object
public class HolderDetailsRequest {

    /** The dossier code. */
    @Schema(description = "Internal dossier code. Used by backoffice services. Null otherwise.", example = "1")
    @NotNull
    // Not null
    // Dossier code
    private Integer dossierCode;

    /** The holders details. */
    @Schema(description = "List of personal and professional data of all holders.")
    @NotNull
    @Valid
    // Not null
    // Holder details
    private List<HolderInfoDetailsDto> holdersDetails;

    /** The user profile. */
    @Schema(description = "User profile name", example = "Administrador")
    private String userProfile;

}
