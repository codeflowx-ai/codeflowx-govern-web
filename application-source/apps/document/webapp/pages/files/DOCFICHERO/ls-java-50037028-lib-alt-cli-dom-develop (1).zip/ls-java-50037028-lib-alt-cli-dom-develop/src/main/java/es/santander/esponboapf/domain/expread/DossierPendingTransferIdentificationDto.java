package es.santander.esponboapf.domain.expread;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier pending transfer identification dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierPendingTransferIdentificationDto {

    /** The Dossier code. */
    private Long dossierCode;

    /** The Iban. */
    private String iban;

    /** The Contract partenon. */
    private String contractPartenon;

    /** The Local Account. */
    private String localAccount;

}
