package es.santander.esponboapf.domain.expread.document;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder document type dto.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
// Holder document type
public class HolderContractPdfDto {

    /**
     * The Contract type code.
     */
    // Document type code
    @Schema(description = "number of contract", example = "1")
    private Integer contractCode;

    /**
     * The contract name.
     */
    // Document type name
    @Schema(description = "Contract name", example = "Condiciones generales")
    private String contractName;

    /**
     * The Mandatory list.
     */
    // Mandatory list
    @Schema(description = "mandatory contract", example = "false")
    private boolean mandatory;

    /**
     * The url of the contract
     */
    // url of the contract
    @Schema(description = "url of the contract",
            example = "https://microsite.bancosantander.es/hc/condiciones_generales_20220203.pdf")
    private String url;

}
