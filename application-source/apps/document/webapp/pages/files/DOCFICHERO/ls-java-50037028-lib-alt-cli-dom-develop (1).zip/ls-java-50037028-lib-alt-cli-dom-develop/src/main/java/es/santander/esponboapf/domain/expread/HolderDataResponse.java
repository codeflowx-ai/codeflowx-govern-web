package es.santander.esponboapf.domain.expread;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderDataResponse.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HolderDataResponse {

    /** The holder id. */
    private String holderId;

    /** The type client. */
    private Integer typeClient;

}
