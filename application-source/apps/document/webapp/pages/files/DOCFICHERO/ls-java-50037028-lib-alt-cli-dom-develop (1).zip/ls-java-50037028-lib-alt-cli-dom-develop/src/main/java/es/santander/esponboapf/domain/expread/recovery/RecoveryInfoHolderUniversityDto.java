package es.santander.esponboapf.domain.expread.recovery;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Recovery info holder university dto.
 */
//The class RecoveryInfoHolderUniversityDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecoveryInfoHolderUniversityDto {

    /**
     * The University code.
     */
    @Schema(description = "Number identifying an university", example = "1")
    private Integer universityCode;

    /**
     * The University name.
     */
    @Schema(description = "Name of the university", example = "Universidad de Madrid")
    private String universityName;

}
