package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;
import java.util.Set;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class University.
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "International dialling number information", 
example = "{\"universityCode\":1078,\"universityName\":\"Carlos III\","
        + "\"offices\":[{'officeCode':'4918', 'address':'4918 - FERROL'}]}")
// University out data object
public class UniversityOutDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = 886311982952578283L;

    /**
     * The country code.
     *
     * E.g.: 1078
     */
    @Schema(description = "University identifier", example = "1078")
    private int universityCode;

    /**
     * The country name.
     *
     * E.g.: 'Carlos III'
     */
    @Schema(maxLength = 50, description = "Description of the university and the data to be displayed on the screen",
            example = "Carlos III")
    private String universityName;

    /**
     * The offices. E.g.: [{'officeCode':'4918', 'address':'4918 - FERROL}]
     */
    @Schema(description = "List of offices linked to the univerity",
            example = "[{'officeCode':'4918', 'address':'4918 - FERROL'}]")
    private Set<MaintenanceOfficeDTO> offices;

}
