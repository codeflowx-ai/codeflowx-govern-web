package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CallMeBackInfoDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information to holder.")
public class CallMeBackInfoDto {

    /** The name. */
    @Schema(description = "Holder's name.", example = "Juan")
    private String name;

    /** The surname 1. */
    @Schema(description = "Holder's surname 1.", example = "Ruiz")
    private String surname1;

    /** The surname 2. */
    @Schema(description = "Holder's surname 2.", example = "Perez")
    private String surname2;

    /** The identity type. */
    @Schema(description = "Identity type.", example = "1")
    private String identityType;

    /** The identity number. */
    @Schema(description = "Identity number.", example = "53000153B")
    private String identityNumber;

    /** The person type. */
    @Schema(description = "Person type.", example = "F")
    private String personType;

    /** The person code. */
    @Schema(description = "Person code.", example = "124661240")
    private String personCode;

    /** The campaign code. */
    @Schema(description = "Campaign code.", example = "221")
    private Integer campaignCode;

    /** The campaign name. */
    @Schema(description = "Campaign name.", example = "Online")
    private String campaignName;

    /** The cmb code. */
    @Schema(description = "Cmb code.", example = "1")
    private Integer cmbCode;

}
