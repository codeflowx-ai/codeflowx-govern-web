package es.santander.esponboapf.domain.valcli.bdp;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpContactListResponse.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BdpContactListResponse {

    /** The codigops. */
    @Schema(description = "codigops", example = "[\"PS4417\"]")
    private List<String> codigops;

    /** The codperr. */
    @Schema(description = "codperr", example = "0")
    private Integer codperr;

    /** The codperso. */
    @Schema(description = "codperso", example = "[\"128820947\"]")
    private List<Integer> codperso;

    /** The direcci. */
    @Schema(description = "Address", example = "[\"UNO@UNO.COM\"]")
    private List<String> direcci;

    /** The horadesx. */
    @Schema(description = "Horadesx.", example = "[\"08:00:00\"]")
    private List<String> horadesx;

    /** The horahasx. */
    @Schema(description = "Horahasx.", example = "[\"18:00:00\"]")
    private List<String> horahasx;

    /** The iddispod. */
    @Schema(description = "Iddispod.", example = "[\"I\"]")
    private List<String> iddispod;

    /** The iddispor. */
    @Schema(description = "Value corresponding to device type repositioning field", example = "")
    private Integer iddispor;

    /** The idorgtel. */
    @Schema(description = "Idorgtel.", example = "[\"01\"]")
    private List<String> idorgtel;

    /** The idorirop. */
    @Schema(description = "Idorirop.", example = "")
    private Integer idorirop;

    /** The indice. */
    @Schema(description = "Value corresponding to type of source of operational risk.", example = "0")
    private Integer indice;

    /** The indice 2. */
    @Schema(description = "Index2.", example = "[1]")
    private List<Integer> indice2;

    /** The indprer. */
    @Schema(description = "Value corresponding to rest inclusion indicator", example = "")
    private Integer indprer;

    /** The indpres. */
    @Schema(description = "Indpres.", example = "[\"S\"]")
    private List<String> indpres;

    /** The jnroseca. */
    @Schema(description = "Jnroseca.", example = "[1]")
    private List<Integer> jnroseca;

    /** The jnrosec 1. */
    @Schema(description = "Jnrosec1.", example = "0")
    private Integer jnrosec1;

    /** The retorno. */
    @Schema(description = "Value corresponding to return code of the operation / request", example = "00")
    private String retorno;

    /** The retorno 2. */
    @Schema(description = "Return2.", example = "[\"00\"]")
    private List<String> retorno2;

    /** The rutina. */
    @Schema(description = "Routine.", example = "[\"PSBCDACO\"]")
    private List<String> rutina;

    /** The tipoperr. */
    @Schema(description = "Value corresponding to related person type", example = "F")
    private String tipoperr;

    /** The tipperso. */
    @Schema(description = "Type person.", example = "[\"F\"]")
    private List<String> tipperso;

    /** The fech act. */
    @Schema(description = "Date", example = "[\"2022-04-05T00:00:00.000+0200\"]")
    private List<String> fech_act;
}
