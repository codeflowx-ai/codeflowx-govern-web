package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new road type dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Types of road", 
example = "{\"roadTypeCode\":\"AV\",\"roadTypeName\":\"Avenida\"}")
public class RoadTypeDto {

    /**
     * The road type code.
     *
     * E.g.: 'AV'
     */
    @Schema(description = "Code that identifies a type of road", example = "AV")
    private String roadTypeCode;

    /**
     * The road type name.
     *
     * E.g.: 'Avenue'
     */
    @Schema(maxLength = 50, description = "Road type description", example = "Avenida")
    private String roadTypeName;
}
