package es.santander.esponboapf.domain.corresp;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CallMeBackResponse.
 */
//The class CallMeBackResponse
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response from the service requesting to receive a call from the bank.")
public class CallMeBackResponse {

    /** The result. */
    //Result
    @Schema(description = "Result response call me back", example = "OK")
    private String result;
}
