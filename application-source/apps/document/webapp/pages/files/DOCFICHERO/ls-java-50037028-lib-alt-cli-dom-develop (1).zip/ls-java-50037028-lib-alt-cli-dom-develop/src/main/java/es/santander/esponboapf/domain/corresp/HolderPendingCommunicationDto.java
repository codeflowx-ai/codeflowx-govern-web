package es.santander.esponboapf.domain.corresp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Holder pending communication dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HolderPendingCommunicationDto {

    /**
     * The Dossier code.
     */
    private Long dossierCode;

    /**
     * The Holder code.
     */
    private Long holderCode;

    /**
     * The Holder id.
     */
    private String holderId;

    /**
     * The Holder name.
     */
    private String holderName;

    /**
     * The Holder surname 1.
     */
    private String holderSurname1;

    /**
     * The Holder surname 2.
     */
    private String holderSurname2;

    /**
     * The Email.
     */
    private String email;

    /**
     * The Dossier state.
     */
    private Integer dossierState;

    /**
     * The Days last update.
     */
    private Integer daysLastUpdate;

    /**
     * The Identification type.
     */
    private Integer identificationCode;

    /**
     * The Steps.
     */
    private List<HolderPendingCommunicationStepDto> steps;

    /**
     * Gets step.
     *
     * @param stepCode the step code
     * @return the step
     */
    public HolderPendingCommunicationStepDto getStep(Integer stepCode) {
        return steps.stream().filter(step -> step.getStepCode().equals(stepCode))
                .findFirst()
                .orElseThrow();
    }

}
