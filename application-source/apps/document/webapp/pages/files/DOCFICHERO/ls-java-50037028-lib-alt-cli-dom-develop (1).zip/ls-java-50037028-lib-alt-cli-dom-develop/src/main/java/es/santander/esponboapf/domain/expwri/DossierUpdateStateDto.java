package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier update state dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information to change a dossier state and or substate.",
        example = "{\"currentStateCode\":1,\"stateCode\":1,\"substateCode\":1}")
public class DossierUpdateStateDto {

    /**
     * The current state code.
     *
     * Code of the state which will be updated from.
     * E.g.: 1
     */
    @Schema(description = "Code of the dossier's current state.", example = "1")
    private Integer currentStateCode;

    /**
     * The state code.
     * <p>
     * Code of the state which will be updated to.
     * E.g.: 1
     */
    @Schema(description = "Code of the state which will be updated to.", example = "1")
    @NotNull
    private Integer stateCode;

    /**
     * The substate code.
     * <p>
     * Code of the substate which will be updated to.
     * E.g.: 1
     */
    @Schema(description = "Code of the substate which will be updated to.", example = "1")
    private Integer substateCode;

}
