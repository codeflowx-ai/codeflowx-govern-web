package es.santander.esponboapf.domain.expwri.dossier.save;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Compare action.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CompareResult {

    /**
     * The Document code.
     */
    private Integer documentCode;

    /**
     * The Document name.
     */
    private String documentName;

    /**
     * The Document type.
     */
    private Integer documentType;

    /**
     * The Holder document code.
     */
    private Long holderDocumentCode;

    /**
     * The Action.
     */
    private CompareAction action;

    /**
     * The Reject reason code.
     */
    private Integer rejectReasonCode;

    /**
     * The Reject reason.
     */
    private String rejectReason;

    /** The reject reason text. */
    private String rejectReasonText;

    /**
     * Is filled boolean.
     *
     * @return the boolean
     */
    @JsonIgnore
    public Boolean isFilled() {
        return Boolean.valueOf(documentCode != null
                && action != null);
    }

}
