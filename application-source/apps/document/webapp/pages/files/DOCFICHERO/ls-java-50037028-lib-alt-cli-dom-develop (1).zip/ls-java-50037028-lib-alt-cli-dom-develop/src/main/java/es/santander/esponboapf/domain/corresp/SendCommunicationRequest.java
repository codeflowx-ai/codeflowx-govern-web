package es.santander.esponboapf.domain.corresp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Send email request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
// Send communication request object
public class SendCommunicationRequest {

    /**
     * The Channel.
     */
    private String channel;

    /**
     * The Application id.
     */
    @JsonProperty("application_id")
    private String applicationId;

    /**
     * The Email.
     */
    private String email;

    /**
     * The Phone.
     */
    @JsonProperty("mobile_number")
    private String phoneNumber;

    /**
     * The Data.
     */
    private CommunicationDataDto data;
    
}
