package es.santander.esponboapf.domain.expread;

import javax.validation.constraints.NotBlank;

import es.santander.esponboapf.domain.expwri.HolderContactDto;
import es.santander.esponboapf.domain.validation.annotations.IdDocumentNumber;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new request login.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Natural person performing the digital onboarding",
    example = "{\"identityNumber\":\"L1234567L\"}")
public class RequestLogin extends HolderContactDto {

    /**
     * The identity number.
     *
     * The holder's identity number.
     */
    // Para validar la persona que se está dando de alta, es necesario que facilite
    // los datos de HolderContactDto
    // (su número de móvil + prefijo, correo electrónico) y el número de su
    // documento de identidad.
    @Schema(maxLength = 9, description = "Holder's identity document number", example = "L1234567L")
    @NotBlank
    @IdDocumentNumber
    private String identityNumber;
}
