package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class PersonDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PersonDto {

    /** The type person. */
    // TypePerson
    @Schema(description = "Type of person in BDP.", example = "F")
    private String typePerson;

    /** The cod person. */
    // CodPerson
    @Schema(description = "Code of person in BDP.", example = "123456")
    private Integer codPerson;

}
