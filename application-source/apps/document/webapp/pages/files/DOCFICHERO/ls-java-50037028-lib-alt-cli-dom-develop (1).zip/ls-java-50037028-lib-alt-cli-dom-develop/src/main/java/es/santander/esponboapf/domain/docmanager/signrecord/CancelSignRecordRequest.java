package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class CancelSignRecord.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
// Cancel sign record request
public class CancelSignRecordRequest {

    /** The ind delete docs. */
    // Delete docs indicator
    private String indDeleteDocs;

}
