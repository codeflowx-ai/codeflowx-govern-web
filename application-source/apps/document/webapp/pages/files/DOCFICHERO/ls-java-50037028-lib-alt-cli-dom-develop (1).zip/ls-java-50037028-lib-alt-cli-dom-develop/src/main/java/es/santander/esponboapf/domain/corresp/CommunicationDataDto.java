package es.santander.esponboapf.domain.corresp;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Communication data dto.
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
// Communication data
public class CommunicationDataDto {

    /**
     * The Holder full name.
     */
// Holder full name
    @JsonProperty("client_name_full")
    @XssValid
    private String holderFullName;

    /**
     * The Holder name.
     */
// Holder name
    @JsonProperty("client_name")
    @XssValid
    private String holderName;

    /** The holder name 2. */
    @JsonProperty("client_name_2")
    @XssValid
    private String holderName2;

    /**
     * The Url.
     */
// url
    @JsonProperty("url_1")
    @XssValid
    private String url;

    /**
     * The Documents.
     */
// Document list
    @JsonProperty("list_1")
    private List<CommunicationDataDocumentDto> documents;

    /**
     * The description.
     */
// description
    @JsonProperty("description")
    @XssValid
    private String description;

    /**
     * The hour.
     */
// hour
    @JsonProperty("hour")
    @XssValid
    private String hour;

    /**
     * The date.
     */
// date
    @JsonProperty("date_1")
    @XssValid
    private String date;

    /** The product name. */
    @JsonProperty("product_name")
    @XssValid
    private String productName;

    /** The product id. */
    @JsonProperty("product_id")
    @XssValid
    private String productId;

    /** The Code. */
    @JsonProperty("code")
    @XssValid
    private String code;

    /** The Hashbio. */
    @JsonProperty("hashbio")
    @XssValid
    private String hashbio;

}
