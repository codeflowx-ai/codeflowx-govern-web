package es.santander.esponboapf.domain.mictransferiden.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import es.santander.esponboapf.domain.util.StringTrimmerDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer detail response.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransferDetailResponse {

    /** The Response date. */
    private String responseDate;

    /** The Payer. */
    private TransferDetailPayerResponse payer;

    /** The Beneficiary name. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String beneficiaryName;

    /** The Beneficiary client. */
    private TransferDetailBeneficiaryClientResponse beneficiaryClient;

    /** The Beneficiary account. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String beneficiaryAccount;

    /** The Payer account. */
    private TransferDetailPayerAccountResponse payerAccount;

    /** The Payment data. */
    private TransferDetailPaymentDataResponse paymentData;

}
