package es.santander.esponboapf.domain.fraud;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MulerosRequest.
 *
 * MulerosRequest.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MulerosRequest {

    /** The person type. */
    @Schema(description = "Person type.", example = "F")
    @NotNull
    private String personType;

    /** The person code. */
    @Schema(description = "Person code.", example = "123654")
    @NotNull
    private String personCode;

    /** The full name. */
    @Schema(description = "Name and surname of the person.", example = "MARIA SANZ SANZ")
    @NotNull
    private String fullName;

    /** The doc type. */
    @Schema(description = "Document type", example = "N")
    @NotNull
    private String docType;

    /** The identity number. */
    @Schema(description = "Identity number", example = "69311093H")
    @NotNull
    private String identityNumber;

    /** The office. */
    @Schema(description = "Office code", example = "5525")
    @NotNull
    private String office;

    /** The final review result. */
    @Schema(description = "Final review result.", example = "00")
    @NotNull
    private String finalReviewResult;

}
