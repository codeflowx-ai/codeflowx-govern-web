package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * TransferAmountDataResponse
 *
 * The type Transfer amount concept applied response.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferAmountDataResponse {

    /** The Amount. */
    private Double amount;

    /** The Currency. */
    private String currency;

}
