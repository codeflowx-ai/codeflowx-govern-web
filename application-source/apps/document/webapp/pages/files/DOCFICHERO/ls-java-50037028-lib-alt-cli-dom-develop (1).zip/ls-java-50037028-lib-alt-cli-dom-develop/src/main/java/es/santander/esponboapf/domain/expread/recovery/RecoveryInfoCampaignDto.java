package es.santander.esponboapf.domain.expread.recovery;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Recovery info campaign dto.
 */
//The class RecoveryInfoCampaignDto
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecoveryInfoCampaignDto {

    /**
     * The Campaign code.
     */
    @Schema(description = "Number identifying a campaign", example = "341")
    private Integer campaignCode;

    /**
     * The Type office.
     */
    @Schema(description = "Type of the office", example = "virtual")
    private String typeOffice;

    /**
     * The Office code.
     */
    @Schema(description = "Code of the campaign's office", example = "2222")
    private String officeCode;

    /** The is BBOO registration. */
    @Schema(description = "Indicates whether the file has been created from BBOO.", example = "true")
    private Boolean isBBOORegistration;

}
