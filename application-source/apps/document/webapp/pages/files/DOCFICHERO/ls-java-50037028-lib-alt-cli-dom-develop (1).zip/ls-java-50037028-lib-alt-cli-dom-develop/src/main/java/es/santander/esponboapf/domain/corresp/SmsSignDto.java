package es.santander.esponboapf.domain.corresp;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.UUID;

/**
 * The Class OtpRequest.
 */
@NoArgsConstructor

/**
 * To string.
 *
 * @return the java.lang. string
 */
@Data
@Schema(description = "Mandatory information to be able to generate an OTP key.",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\","
        + "\"fullPhoneNumber\":\"0034666666666\", \"signature\":\"80fd7423\"}")
// OTP request
public class SmsSignDto {


    /** The holder id. */
    @Schema(maxLength = 100, description = "Unique holder identifier. ",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    // the phone number should have the prefix code
    // as 00[prefix code]  instead of +[prefix code]
    /**
     * The full phone number.
     *
     * The holder's full phone number.
     */
    @Schema(maxLength = 100,
            description = "Full phone number (including international prefix) where the sms with the OTP key "
                    + "will be sent to. ",
            example = "0034666666666")
    @NotNull
    @Pattern(regexp = "[\\w+]*")
    private String fullPhoneNumber;

    /** The signature. */
    @Schema(maxLength = 100, description = "Unique account identifier. ",
            example = "80fd7423")
    @NotNull
    private String signature;

}
