package es.santander.esponboapf.domain.mictransferiden.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import es.santander.esponboapf.domain.util.StringTrimmerDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TransferDetailPayerAddressResponse
 *
 * The type Transfer detail payer address response.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferDetailPayerAddressResponse {

    /** The Zip code. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String zipCode;

    /** The Domicile. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String domicile;

    /** The Square. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String square;

    /** The Country. */
    @JsonDeserialize(using = StringTrimmerDeserializer.class)
    private String country;

}
