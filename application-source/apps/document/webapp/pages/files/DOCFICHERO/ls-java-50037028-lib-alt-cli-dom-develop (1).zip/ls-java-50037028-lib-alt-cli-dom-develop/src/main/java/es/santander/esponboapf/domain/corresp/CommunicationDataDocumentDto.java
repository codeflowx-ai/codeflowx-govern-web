package es.santander.esponboapf.domain.corresp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Communication data document dto.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
// Communication data document
public class CommunicationDataDocumentDto {

    /**
     * The Document name.
     */
    // Document name
    @JsonProperty("doc_name")
    private String documentName;

    /**
     * The Error.
     */
    // Document error
    @JsonProperty("doc_error")
    private String error;

    /**
     * The Valid document.
     */
    // Valid document/s
    @JsonProperty("valid_doc")
    private String validDocument;

}
