package es.santander.esponboapf.domain.enums;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The Enum DossierStateEnum.
 */
public enum DossierStateEnum {

    /** The preregister. */
    PREREGISTER(1, -1),

    /** The client registration. */
    CLIENT_REGISTRATION(2, 1),

    /** The pending documentation. */
    PENDING_DOCUMENTATION(3, 9),

    /** The pending activation. */
    PENDING_ACTIVATION(4, 6),

    /** The activating. */
    ACTIVATING(5, 7),

    /** The complete. */
    COMPLETE(6, 4),

    /** The cancelled. */
    CANCELLED(7, 3),

    /** The multiholder. */
    MULTIHOLDER(8, 54);

    /** The Constant BY_VALUE. */
    private static final Map<Integer, DossierStateEnum> BY_VALUE = Arrays.stream(values())
            .collect(Collectors
                    .toUnmodifiableMap(e -> e.value, e -> e));

    /** The Constant BY_ACTION. */
    private static final Map<Integer, DossierStateEnum> BY_ACTION = Arrays.stream(values())
            .collect(Collectors
                    .toUnmodifiableMap(e -> e.actionAudit, e -> e));

    /** The label. */
    public final int value;

    /** The action audit. */
    public final int actionAudit;

    /**
     * Instantiates a new dossier state enum.
     *
     * @param value       the value
     * @param actionAudit the action audit
     */
    DossierStateEnum(int value, int actionAudit) {
        this.value = value;
        this.actionAudit = actionAudit;
    }

    /**
     * From value.
     *
     * @param value the value
     * @return the dossier state enum
     */
    public static DossierStateEnum fromValue(int value) {
        return BY_VALUE.get(value);
    }

    /**
     * From action.
     *
     * @param action the action
     * @return the dossier state enum
     */
    public static DossierStateEnum fromAction(int action) {
        return BY_ACTION.get(action);
    }
}
