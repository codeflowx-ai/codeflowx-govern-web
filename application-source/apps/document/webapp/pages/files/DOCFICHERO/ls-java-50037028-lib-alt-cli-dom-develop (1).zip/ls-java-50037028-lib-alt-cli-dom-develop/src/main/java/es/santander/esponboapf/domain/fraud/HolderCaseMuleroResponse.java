package es.santander.esponboapf.domain.fraud;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderCaseMuleroResponse.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HolderCaseMuleroResponse {

    /** The holder code. */
    private Long holderCode;

    /** The person type. */
    private String personType;

    /** The person code. */
    private String personCode;

    /** The document type. */
    private String documentType;

    /** The identity number. */
    private String identityNumber;

    /** The full name. */
    private String fullName;

    /** The office. */
    private String office;

    /** The mulero info. */
    private List<CaseMuleroDto> muleroInfo;

}
