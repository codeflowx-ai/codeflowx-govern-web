package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DataHolderDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Data from a holder.",
example = "{\"holderId\":\"1abe4f7c-d843-477d-b1c8-d181410c1a47\",\"fullName\":\"Nombre Apellido1 Apellido2\","
        + "\"name\":\"Juan\",\"surname1\":\"Rodrigo\",\"surname2\":\"Lopez\","
        + "\"identityTypeCode\":1,\"identiyTypeName\":\"DNI\",\"identityNumber\":\"53000153B\","
        + "\"email\":\"manuel1r223@gmail.com\",\"movil\":\"34-686124154\",\"addressCompleted\":true,"
        + "\"identificationCompleted\":false}")
public class DataHolderDto {


    /** The holder id. */
    @Schema(description = "UUID identifying a holder", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    private String holderId;

    /** The full name. */
    @Schema(description = "Complete holder´s name", example = "Nombre Apellido1 Apellido2")
    private String fullName;

    /** The name. */
    @Schema(description = "Holder name", example = "Juan")
    private String name;
    
    /** The surname 1. */
    @Schema(description = "Holder surname1", example = "Rodrigo")
    private String surname1;
    
    /** The surname 2. */
    @Schema(description = "Holder surname2", example = "Lopez")
    private String surname2;

    /** The identity type code. */
    @Schema(description = "Number identifying type of code", example = "1")
    private Integer identityTypeCode;

    /** The identity type name. */
    @Schema(maxLength = 6, description = "Description of the type of identification", example = "DNI")
    private String identityTypeName;

    /** The identity number. */
    @Schema(description = "Document identity number", example = "53000153B")
    private String identityNumber;

    /**
     * The Email.
     */
    @Schema(description = "Email", example = "manuel1r223@gmail.com")
    private String email;
    
    /**
     * The Movil.
     */
    @Schema(description = "Phone number", example = "34-686124154")
    private String movil;

    /** The address complete. */
    @Schema(description = "indicator for know if the holder has the address complete", example = "false")
    private boolean addressCompleted;
    
    /** The identification completed. */
    @Schema(description = "indicator for know if the holder has the identification complete", example = "false")
    private boolean identificationCompleted;
}
