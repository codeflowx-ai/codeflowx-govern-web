package es.santander.esponboapf.domain.expread;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierToActivateDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DossierToActivateDto {

    /**
     * The Dossier code.
     */
    private Long dossierCode;

    /**
     * The Dossier id.
     */
    private Long holderCode;

    /**
     * The Holder identity number.
     */
    private String holderIdentityNumber;

    /**
     * The State.
     */
    private String state;

    /**
     * The Sub state.
     */
    private String subState;

    /**
     * The Register date.
     */
    private LocalDateTime registerDate;

    /** The riesgo. */
    private String risk;

    /** The personal data. */
    private String personalData;
    
    /** The identity reliable. */
    private String identityReliable;
    
    /** The activate account. */
    private String activateAccount;
    
    /** The contract signed. */
    private String contractSigned;
    
    /** The access password. */
    private String accessPassword;
    
    /** The attach documentation. */
    private String attachDocumentation;
    
    /** The last modified date. */
    private LocalDateTime lastModifiedDate;    
    
}
