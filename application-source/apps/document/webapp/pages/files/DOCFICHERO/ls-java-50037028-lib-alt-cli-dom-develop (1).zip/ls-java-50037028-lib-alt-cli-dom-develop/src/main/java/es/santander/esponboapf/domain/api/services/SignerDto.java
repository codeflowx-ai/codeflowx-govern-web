package es.santander.esponboapf.domain.api.services;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SignerDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SignerDto {

    /** The person number. */
    private String personNumber;
}
