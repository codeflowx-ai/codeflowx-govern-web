package es.santander.esponboapf.domain.docmanager.signrecord;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ClientAndAccountInfoTotal.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ClientAndAccountInfoTotal {

    /** The dossier code. */
    private Long dossierCode;

    /** The person code (the F code). */
    private String personCode;

    /** The phone number of person. */
    private String phoneNumber;

    /** The person full name. */
    private String fullName;

    /** The person name. */
    private String name;

    /** The Identity type. */
    private String identityType;

    /**
     * The Identity number.
     */
    private String identityNumber;

    /** The account CCC. */
    private String accountCCC;

    /** The account entity. */
    private String accountEntity;

    /** The account branch. */
    private String accountBranch;

    /** The partenon product. */
    private String partenonProduct;

    /** The partenon account. */
    private String partenonAccount;

    /** The partenon subtype. */
    private String partenonSubtype;

    /** The account IBAN. */
    private String accountIBAN;

    /** The no activity holder. */
    private Boolean noActivityHolder;

    /** The reading date precontract. */
    private LocalDateTime readingDatePrecontract;

    /** The campaign code. */
    private Integer campaignCode;

    /** The account code. */
    private Long accountCode;

    /** The state step signature. */
    private String stateStepSignature;

    /** The gn id. */
    private String gnId;

    /** The gnd id imp. */
    private String gnIdImp;

    /** The contract code. */
    private Integer contractCode;

    /** The is signed. */
    private Boolean isSigned;

    /** The is add exp sign. */
    private Boolean isAddExpSign;

    /** The holder code. */
    private Long holderCode;

    /** The holder id. */
    private String holderId;

    /** The dossier id. */
    private String dossierId;

    /** The type client. */
    private Integer typeClient;

    /** The reading date commissions. */
    private LocalDateTime readingDateCommissions;


}
