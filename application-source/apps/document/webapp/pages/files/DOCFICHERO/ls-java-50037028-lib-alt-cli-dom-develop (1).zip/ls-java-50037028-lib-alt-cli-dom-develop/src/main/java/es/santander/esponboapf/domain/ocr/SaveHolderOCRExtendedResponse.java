package es.santander.esponboapf.domain.ocr;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Instantiates a new save holder OCR extended resonse.
 *
 * This is the response sent as an answer but with both images.
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SaveHolderOCRExtendedResponse extends SaveHolderOCRResponse {

    /**
     * The front image.
     *
     * String rendering the FRONT image in base64
     */
    private String frontImage;

    /**
     * The back image.
     *
     * String rendering the BACK image in base64
     */
    private String backImage;

}
