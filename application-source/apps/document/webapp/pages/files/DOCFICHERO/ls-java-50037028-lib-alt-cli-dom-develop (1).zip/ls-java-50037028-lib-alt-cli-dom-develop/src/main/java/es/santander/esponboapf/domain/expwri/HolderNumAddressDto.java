package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new holder num address dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
// HolderNumAddressDto
public class HolderNumAddressDto {

    /** The holder id. */
    // Holder id
    private UUID holderId;

    /** The num address. */
    // Num address
    private String numAddress;
}
