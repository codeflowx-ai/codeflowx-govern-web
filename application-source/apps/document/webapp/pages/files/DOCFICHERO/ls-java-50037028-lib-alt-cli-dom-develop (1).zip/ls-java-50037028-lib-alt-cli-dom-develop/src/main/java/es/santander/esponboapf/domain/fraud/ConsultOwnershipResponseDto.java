package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Consult ownership response dto.
 */
//The class ConsultOwnershipResponseDto
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConsultOwnershipResponseDto {

    /**
     * The State code ownership.
     */
    @Schema(description = "State code of the ownership", example = "AC")
    private String stateCodeOwnership;

    /**
     * The State desc ownership.
     */
    @Schema(description = "State description of the ownership", example = "ACEPTADA")
    private String stateDescOwnership;

}
