package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new response transfer dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Response due to quick transfer.",
        example = "{\"result\":\"false\",\"errorCode\":\"PL0903\","
                + "\"errorDescription\":\"FALTA DATO OBLIGATORIO\"}")
// ResponseTransfer data object
public class ResponseTransferDto {

    /**
     * The result.
     *
     * The transfer process result.
     * True = OK, false = some errors.
     */
    @Schema( description = "The transfer process result. True = OK, false = some errors.",
            example = "false")
    private boolean result;

    /**
     * The error code.
     *
     * Error code in case something went wrong in the transfer process
     * E.g.: PL0903
     */
    @Schema(description = "Error code in case something went wrong in the transfer process.", example = "PL0903")
    private String errorCode;

    /**
     * The error message.
     *
     * E.g.: 'FALTA DATO OBLIGATORIO'
     */
    @Schema(description = "Information about error transfer.", example = "FALTA DATO OBLIGATORIO")
    private String errorMessage;

}
