package es.santander.esponboapf.domain.valcli.bdp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpUpdateCustomerRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class BdpUpdateCustomerRequest {

    /** The person. */
    private PersonUpdateDto person;

    /** The postal address. */
    private PostalAddressDto postalAddress;

    /** The postal address comp. */
    private PostalAddressCompDto postalAddressComp;

    /** The address num. */
    private String addressNum;

    /** The indmodbas. */
    private String indmodbas;

    /** The indmod dom. */
    private String indmodDom;

    /** The indmod comp. */
    private String indmodComp;

    /** The indmod CRS. */
    private String indmodCRS;
}
