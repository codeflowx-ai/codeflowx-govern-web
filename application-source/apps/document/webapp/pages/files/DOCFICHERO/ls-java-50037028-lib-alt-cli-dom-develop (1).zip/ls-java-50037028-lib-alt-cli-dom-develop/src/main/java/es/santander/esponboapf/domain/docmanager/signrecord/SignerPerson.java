package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SignerPerson.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SignerPerson {

	/**
	 * Person number signer. ex. F124664238
	 */
	private String personNumber; 
    
	/**
     * Tipo de intervención del firmante. ex. 01 -> Titular, 08 -> Autorizado
     */
	private String intervType;
	
	/**
	 * Fullname signer. ex. SOFIA GARCIA LOPEZ
	 */
    private String fullname;
    
    /**
     * Identity document person. ex. N65537253A
     */
    private String identityDocument;
}
