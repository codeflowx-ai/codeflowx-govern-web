package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type SubstateDto.
 *
 * This is part of an output dto to the state listing service.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
// Substate data object
public class SubstateDto implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4511553101160413151L;

    /**
     * The SubstateDto code.
     *
     * E.g.: 1
     */
    @Schema( description = "Number identifying an substate", example = "1")
    @Size(max = 10)
    @NotNull
    private Integer substateCode;

    /**
     * The SubstateDto name.
     *
     * E.g.: 'Identificacion Pendiente de Validar'
     */
    @Schema( maxLength = 75, description = "Name of the substate",
            example = "Identificación Pendiente de Validar")
    @NotNull
    private String substateName;
}
