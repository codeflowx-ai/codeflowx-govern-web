package es.santander.esponboapf.domain.operations;

import javax.validation.constraints.NotEmpty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class LoginRequest.
 */
// The LoginRequest Class
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Request to to the login service.",
        example = "{\"user\":\"01378983H\",\"password\":\"*****\",\"campaignCode\":666}")
public class LoginRequest {

    /** The user. */
    // The user
    @Schema(description = "Indicate the user", example = "01378983H")
    @NotEmpty
    private String user;

    /** The password. */
    // The password
    @Schema(description = "Indicate the encrypt password", example = "*****")
    @NotEmpty
    private String password;

    /** The campaign code. */
    @Schema(description = "Campaign code", example = "1")
    private Integer campaignCode;

}
