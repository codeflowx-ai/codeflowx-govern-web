package es.santander.esponboapf.domain.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The enum Identification type enum.
 */
@Getter
public enum IdentificationTypeEnum {

    /**
     * Video identification type enum.
     */
    VIDEO(1),
    /**
     * Office identification type enum.
     */
    OFFICE(2),
    /**
     * Bboo identification type enum.
     */
    BBOO(3),
    /**
     * Otp transfer identification type enum.
     */
    OTP_TRANSFER(4),
    /**
     * Incoming transfer identification type enum.
     */
    INCOMING_TRANSFER(5);

    /**
     * The constant BY_VALUE.
     */
    private static final Map<Integer, IdentificationTypeEnum> BY_VALUE = Arrays.stream(values())
            .collect(Collectors
                    .toUnmodifiableMap(e -> e.value, e -> e));

    /** The label. */
    public final int value;

    /**
     * Instantiates a new Identification type enum.
     *
     * @param value the value
     */
    IdentificationTypeEnum(int value) {
        this.value = value;
    }

    /**
     * From value.
     *
     * @param value the value
     * @return the identification type enum
     */
    public static IdentificationTypeEnum fromValue(int value) {
        return BY_VALUE.get(value);
    }

}
