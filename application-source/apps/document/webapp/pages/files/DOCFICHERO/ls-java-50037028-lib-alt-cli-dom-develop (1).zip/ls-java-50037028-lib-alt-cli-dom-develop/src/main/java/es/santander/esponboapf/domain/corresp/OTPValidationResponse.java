package es.santander.esponboapf.domain.corresp;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class OTPValidationResponse.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Information about a OTP key validation.",
        example = "{\"result\":true,\"message\":{\"code\":\"LN001\","
                + "\"description\":\"No otp for this holder or has expired.\",\"retries\":1}}")
public class OTPValidationResponse {

    /**
     * The result.
     *
     * The validation result.
     */
    @Schema(description = "Validation status. True if valid, false if failed.", example = "true")
    private boolean result;

    /**
     * The message.
     *
     * The validation message structure in case of error.
     */
    @Schema(description = "Information about a failed OTP key validation. It will be null if 'result' is true",
            example = "{\"code\":\"LN001\",\"description\":\"No otp for this holder or has expired.\",\"retries\":1}")
    private OTPValidationMessage message;
}
