package es.santander.esponboapf.domain.token;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class HagcliTokenJweDecoded.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter
@Schema(description = "Jwe token data part decoded")
// HagcliTokenJweDecoded
public class HagcliTokenJweDecoded {

    /** The data. */
    // Data
    @Schema(description = "Data token data", example = "666")
    private String data;

    /** The exp. */
    // Expiration
    @Schema(description = "Data token expiration", example = "1234584687")
    private String exp;

}
