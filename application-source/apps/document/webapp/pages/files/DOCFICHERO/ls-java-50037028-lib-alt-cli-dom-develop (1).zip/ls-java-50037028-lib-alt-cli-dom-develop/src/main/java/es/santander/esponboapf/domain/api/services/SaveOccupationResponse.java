package es.santander.esponboapf.domain.api.services;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SaveOccupationResponse.
 * When occupational data is saved from an external application, we will return
 * this object with the information of the person type and person code, the
 * signature file identifier and the account related data.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SaveOccupationResponse {

    /** The sign exp id. */
    @Schema(description = "Sing identifier", example = "1234")
    private Long signExpId;

    /** The person type. */
    @Schema(description = "Person type", example = "F")
    private String personType;

    /** The personcode. */
    @Schema(description = "Person code", example = "143258")
    private String personcode;

    /** The account data. */
    @Schema(description = "Account's data", example = "{}")
    private AccountDataDto accountData;

}
