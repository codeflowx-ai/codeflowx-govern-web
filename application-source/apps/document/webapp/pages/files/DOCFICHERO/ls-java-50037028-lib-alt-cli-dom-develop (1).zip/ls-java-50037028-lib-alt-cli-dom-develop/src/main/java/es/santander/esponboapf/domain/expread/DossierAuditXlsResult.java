package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier audit xls result.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
// Dossier audit xls result
public class DossierAuditXlsResult {

    /**
     * The Content.
     */
    // Content
    @Schema(description = "The content encoded in base64", example = "YmFzZTY0IGRlIHBydWViYQ...")
    private String content;

    /**
     * The Content type.
     */
    // ContentType
    @Schema(description = "Content type of the result",
            example = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    private String contentType;

    /**
     * The Name.
     */
    // Name
    @Schema(description = "Given name of the file", example = "file.jpg")
    private String name;

}
