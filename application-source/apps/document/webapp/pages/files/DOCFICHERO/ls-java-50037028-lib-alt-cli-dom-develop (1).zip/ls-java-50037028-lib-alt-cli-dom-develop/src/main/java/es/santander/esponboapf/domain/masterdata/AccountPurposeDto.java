package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new account purpose dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Purpose of the account", 
example = "{\"purposeAccountCode\":1,\"purposeAccountName\":\"Inversiones\"}")
public class AccountPurposeDto implements Serializable{

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = 1832291094621990410L;

    /**
     * The purpose account code.
     *
     * E.g.: 1, 2, 3,...
     */
    @Schema(description = "number identifying a purpose", example = "1")
    private Integer purposeAccountCode;

    /**
     * The purpose account name.
     *
     * E.g.: Investments, ...
     */
    @Schema(maxLength = 50, description = "description of the purpose", example = "Inversiones")
    private String purposeAccountName;
}
