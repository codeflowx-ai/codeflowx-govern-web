package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new save occupation holder dto.
 */
@NoArgsConstructor
@Data
@Schema(description = "Information about the current holder occupation.",
example = "{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"occupationTypeCode\":1,\"sectorCode\":\"M\","
        + "\"sectorName\":\"ACTIVIDADES PROFESIONALES,CIENTIFICAS Y TECNICAS\",\"professionCode\":702,"
        + "\"professionName\":\"ACTIVIDADES DE CONSULTORIA DE GESTION EMPRESARIAL\",\"companyCode\":15,"
        + "\"companyCode\":15,\"companyAddress\":\"Cantabria Av, Boadilla del Monte\","
        + "\"activityCode\":9}")
// Save occupation holder
public class SaveOccupationHolderDto {

    // datos profesionales asociados al titular
    // que realiza el onboarding digital
    /** The holder id. */
    // Holder id
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /** The occupation type code. */
    // Occupation type code
    @Schema( description = "Occupation identifier", example = "1 - Freelance, 2, - Employee")
    @Min(1)
    private int occupationTypeCode;

    /** The sector code. */
    // Sector code
    @Schema(description = "Professional sector identifier", example = "M")
    private String sectorCode;

    /** The sector name. */
    // Sector name
    @Schema(description = "Professional sector name", example = "ACTIVIDADES PROFESIONALES,CIENTIFICAS Y TECNICAS")
    @Size(max = 50)
    private String sectorName;

    /** The profession code. */
    // Profession code
    @Schema(description = "Profession identifier", example = "702")
    @Min(1)
    private Integer professionCode;

    /** The profession name. */
    // Profession name
    @Schema(description = "Profession name", example = "ACTIVIDADES DE CONSULTORIA DE GESTION EMPRESARIAL")
    private String professionName;

    /** The company code. */
    // Company code
    @Schema(description = "Company identifier", example = "15")
    @Min(1)
    private Integer companyCode;

    /** The company name. */
    // Company name
    @Schema(description = "Company name", example = "Santander Holdings, Inc")
    @Size(max = 100)
    private String companyName;

    /** The company address. */
    // Company address
    @Schema(description = "Company address", example = "Cantabria Av, Boadilla del Monte")
    @Size(max = 250)
    private String companyAddress;

    /** The activity code. */
    // Acivity code
    @Schema(description = "Activity identifier", example = "9")
    @Min(1)
    private Integer activityCode;

    /** The priority. */
    @Schema(description = "priority holder", example = "1")
    private String priority;

    /** The purpose account code. */
    @Schema(description = "Purpose account code", example = "1")
    private Integer purposeAccountCode;

}
