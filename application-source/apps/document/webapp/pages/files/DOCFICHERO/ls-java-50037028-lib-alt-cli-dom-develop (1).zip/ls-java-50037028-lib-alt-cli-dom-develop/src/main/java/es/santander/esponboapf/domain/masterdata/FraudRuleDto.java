package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FraudRuleDto.
 *
 * This is a master data entity.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Fraud rule information", 
example = "{\"ruleCode\":1,\"ruleName\":\"J10000I\","
        + "\"policyCode\":\"GF3\",\"severityCode\":1,\"cancel\":true}")
public class FraudRuleDto implements Serializable{

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -1383875116653107230L;

    /**
     * The rule code.
     *
     * Unique rule identifier.
     * E.g.: 1
     */
    @Schema(description = "Unique rule identifier", example = "1")
    private Integer ruleCode;

    /**
     * The rule name.
     *
     * E.g.: 'J10000I'
     */
    @Schema(maxLength = 20, description = "Rule name", example = "J10000I")
    private String ruleName;

    /**
     * The policy code.
     *
     * E.g.: 'GF3'
     */
    @Schema(maxLength = 20, description = "Policy code", example = "GF3")
    private String policyCode;

    /**
     * The severity code.
     *
     * E.g.: 1
     */
    @Schema(description = "The rule severity code", example = "1")
    private Integer severityCode;

    /**
     * The cancel.
     *
     * If the dossier has to be cancelled due to this rule
     * E.g.: true
     */
    @Schema(description = "If the dossier has to be cancelled due to this rule", example = "true")
    private Boolean cancel;

}
