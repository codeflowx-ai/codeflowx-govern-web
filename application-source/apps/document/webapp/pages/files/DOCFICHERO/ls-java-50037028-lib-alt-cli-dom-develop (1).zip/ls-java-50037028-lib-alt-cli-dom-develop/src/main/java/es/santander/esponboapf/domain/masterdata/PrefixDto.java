package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class Prefix.
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "International dialling number information", 
example = "{\"prefixNumber\":\"33\",\"countryCode\":\"FR\",\"countryName\":\"Francia\","
        + "\"flagFile\":\"united-states-of-america.svg\"}")
public class PrefixDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -2819671768674326665L;

    /**
     * The prefix number.
     *
     * E.g.: '33'
     */
    @Schema(maxLength = 5, description = "International telephone number prefix",
            example = "33")
    private String prefixNumber;

    /**
     * The country code.
     *
     * E.g.: 'FR'
     */
    @Schema(maxLength = 2, description = "code for the representation of names of countries and their subdivisions",
            example = "FR")
    private String countryCode;

    /**
     * The country name.
     *
     * E.g.: 'France'
     */
    @Schema(maxLength = 200,
            description = "The country name",
            example = "Francia")
    private String countryName;

    /**
     * The flag file name packed inside the front.
     *
     * E.g.: 'france.svg'
     */
    @Schema(maxLength = 200, description = "Country or region filename to show a flag in the front",
            example = "united-states-of-america.svg")
    private String flagFile;
}
