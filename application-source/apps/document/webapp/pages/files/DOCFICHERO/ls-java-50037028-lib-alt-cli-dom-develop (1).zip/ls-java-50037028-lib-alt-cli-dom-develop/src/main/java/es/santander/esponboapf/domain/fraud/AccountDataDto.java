package es.santander.esponboapf.domain.fraud;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccountDataDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class AccountDataDto {

    /** The company id. */
    // The company id.
    @Schema(description = "Company identify", example = "0049")
    @JsonProperty("companyId")
    @NotNull
    private String companyId;

    /** The expedient id. */
    // The expedient id.
    @Schema(description = "Date expedient identify", example = "250923")
    @JsonProperty("fExpedientId")
    @NotNull
    private String fExpedientId;

    /** The s expedient id. */
    // The s expedient id.
    @Schema(description = "Sequence expedient identify", example = "3")
    @JsonProperty("sExpedientId")
    @NotNull
    private Integer sExpedientId;

    /** The c company id. */
    // The c company id.
    @Schema(description = "Code company identify", example = "0049")
    @JsonProperty("cCompanyId")
    @NotNull
    private String cCompanyId;

    /** The center id. */
    // The center id.
    @Schema(description = "Account center identify", example = "0001")
    @JsonProperty("centerId")
    @NotNull
    private String centerId;

    /** The product id. */
    // The product id
    @Schema(description = "Account product id.", example = "300")
    @JsonProperty("productId")
    @NotNull
    private String productId;

    /** The contr C id. */
    // The contr C id.
    @Schema(description = "", example = "0004321")
    @JsonProperty("contrCId")
    @NotNull
    private String contrCId;

    /** The dias apert. */
    // The dias apert.
    @Schema(description = "Days aperture.", example = "13502")
    @JsonProperty("diasApert")
    private Integer diasApert;
}