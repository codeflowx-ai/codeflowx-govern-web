package es.santander.esponboapf.domain.api.services;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class FormalizationNoClientResponse.
 */
//Constructors
@NoArgsConstructor
@Data
@Schema(description = "Response from external service for formalization no client from consumpt.",
        example = "{\"returnCode\":\"00\"}")
@SuperBuilder
public class FormalizationNoClientResponse{
    
    /** The other cancel reason. */
    // ReturnCode
    @Schema(description = "Return Code", example = "01")
    private String returnCode;

}
