package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TransferLiquidationDataResponse
 *
 * The type Transfer liquidation data response.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferLiquidationDataResponse {

    /** The Amount settlement transfer currency. */
    private TransferAmountDataResponse amountSettlementTransferCurrency;

    /** The Amount settlement currency account. */
    private TransferAmountDataResponse amountSettlementCurrencyAccount;

}
