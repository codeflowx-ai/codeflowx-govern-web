package es.santander.esponboapf.domain.valcli;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new bdp add contact response dto.
 */
@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class BdpAddContactResponseDto {

    /** The codigops. */
    private List<String> codigops;

    /** The codperso. */
    private List<Integer> codperso;

    /** The retorno. */
    private String retorno;

    /** The retorno 2. */
    private List<String> retorno2;

    /** The rutina. */
    private List<String> rutina;

    /** The tipperso. */
    private List<String> tipperso;

}
