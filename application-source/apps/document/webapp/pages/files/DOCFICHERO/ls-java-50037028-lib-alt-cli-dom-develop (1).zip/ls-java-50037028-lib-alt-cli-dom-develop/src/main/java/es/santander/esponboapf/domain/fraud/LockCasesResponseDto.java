package es.santander.esponboapf.domain.fraud;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class LockCasesResponseDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class LockCasesResponseDto {

    /** The guid. */
    // guid
    private UUID guid;

    /** The request number. */
    @Schema(description = "Dossier Code", example = "123")
    // requestnumber
    private String requestNumber;

    /** The processing date. */
    @Schema(description = "The agent", example = "2023-08-14T14:10:22.412+02:00")
    // processingDate
    private String processingDate;

    /** The error code. */
    // errorCode
    @Schema(description = "Error code if have it", example = "1202")
    @JsonInclude(Include.NON_NULL)
    private String errorCode;

    /** The error message. */
    // errorMessage
    @Schema(description = "Error message if have it",
            example = "Error. El caso ya está bloqueado")
    @JsonInclude(Include.NON_NULL)
    private String errorMessage;

    /** The success. */
    // success
    @Schema(description = "Indicate if the request was success", example = "true")
    private Boolean success;
}
