package es.santander.esponboapf.domain.docmanager.s3;

import org.apache.commons.lang3.StringUtils;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;

/**
 * The Class HolderDocumentS3Request.
 */
//The class HolderDocumentS3Request
@Builder(toBuilder = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HolderDocumentS3Request {

    /**
     * The Holder information.
     */
    // The Holder information
    @Schema(description = "The holder information in our system")
    @Valid
    private HolderDocumentInformationS3Dto holderDocumentInformation;

    /**
     * The Document data.
     */
    // The Document data
    @Schema(description = "The document file data")
    @Valid
    private HolderDocumentDataDto documentData;

    /**
     * Generate file name
     *
     * @return the file name
     */
    public String generateFileName() {
        return this.holderDocumentInformation.getDocumentPrefix().concat("_")
                .concat(StringUtils.isNotEmpty(this.holderDocumentInformation.getPersonCode())
                        ? this.holderDocumentInformation.getPersonCode()
                        : this.holderDocumentInformation.getPriority())
                .concat("_")
                // TODO Corregir como funcionará este concat con el email adjunto que no tiene
                // tipo ni AR
                .concat(StringUtils.isNotEmpty(this.documentData.getDocumentAR()) ? this.documentData.getDocumentAR()
                        : this.holderDocumentInformation.getDocumentCode().toString())
                .concat(".").concat(this.documentData.getExtension());
    }

}
