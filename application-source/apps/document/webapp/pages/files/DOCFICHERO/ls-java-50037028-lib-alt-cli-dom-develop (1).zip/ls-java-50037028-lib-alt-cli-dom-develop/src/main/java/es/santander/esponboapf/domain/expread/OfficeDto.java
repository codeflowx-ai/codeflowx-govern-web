package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class OfficeDto.
 */

/**
 * Instantiates a new office dto.
 */
@NoArgsConstructor

/**
 * Instantiates a new office dto.
 *
 * @param officeCode       the office code
 * @param officeAddress    the office address
 * @param officePostalCode the office postal code
 * @param officeCity       the office city
 * @param officeLatitude   the office latitude
 * @param officeLongitude  the office longitude
 * @param officeDistance   the office distance
 */
@AllArgsConstructor

/**
 * To string.
 *
 * @return the java.lang. string
 */
@Data
@Schema(description = "Information about a bank office")
public class OfficeDto {

    /**
     * The office code.
     *
     * E.g.: '5000'
     */
    @Schema(description = "Office code identifier", example = "5000")
    private String officeCode;

    /**
     * The office address.
     *
     * E.g.: 'CL ORDOÑO II, 15'
     */
    @Schema(description = "Office address", example = "CL ORDOÑO II, 15")
    private String officeAddress;

    /**
     * The office postal code.
     *
     * E.g.: '24001'
     */
    @Schema(description = "Office postal code", example = "24001")
    private String officePostalCode;

    /**
     * The office city.
     *
     * E.g.: 'LEON'
     */
    @Schema(description = "Office city", example = "LEON")
    private String officeCity;

    /**
     * The office latitude.
     *
     * E.g.: 40.43094
     */
    @Schema(description = "Office latitude", example = "40.43094")
    private Double officeLatitude;

    /**
     * The office longitude.
     *
     * E.g.: -3.6952896
     */
    @Schema(description = "Office longitude", example = "-3.6952896")
    private Double officeLongitude;

    /**
     * The office distance.
     *
     * E.g.: 0.172717163
     */
    @Schema(description = "Office distance", example = "0.172717163")
    private Double officeDistance;
}
