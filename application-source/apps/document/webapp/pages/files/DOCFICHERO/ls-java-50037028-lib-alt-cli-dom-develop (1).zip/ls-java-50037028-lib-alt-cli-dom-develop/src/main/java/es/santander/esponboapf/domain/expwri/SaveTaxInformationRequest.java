package es.santander.esponboapf.domain.expwri;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new save tax information request.
 *
 * Request class to save a holder's tax information.
 */

@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Required information to save the current holder occupation.")
// Save tax information request
public class SaveTaxInformationRequest extends DossierParentDto {

    /**
     * The holder tax information.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     */
    @Schema(description = "Tax information for the current holder.")
    @Valid
    @NotNull
    private SaveTaxInformationHolderDto holderTaxInformation;
}
