package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new occupation type dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "Occupational information", 
example = "{\"occupationTypeCode\":1,\"occupationTypeName\":\"Autónomo\",\"order\":1}")
public class OccupationTypeDto implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 6413743022047583L;

    /**
     * The occupation type code.
     *
     * E.g.: 1
     */
    @Schema(description = "number identifying an occupation", example = "1")
    private Integer occupationTypeCode;

    /**
     * The occupation type name.
     *
     * E.g.: 'Freelance'
     */
    @Schema(maxLength = 50, description = "occupation description", example = "Autónomo")
    private String occupationTypeName;

    /**
     * The order.
     *
     * E.g.: 1
     */
    @Schema(description = "order of occupation", example = "1")
    private Integer order;

}
