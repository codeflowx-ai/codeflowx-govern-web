package es.santander.esponboapf.domain.docmanager.uploaddoc;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The Class UploadDocumentRequest.
 */
//The class UploadDocumentWrapperRequest
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
@Schema(description = "Basic holder data.",
example = "{\"frontBase64\":\"dGVzdGV4YW1wbGU=\",\"backBase64\":\"dGVzdGV4YW1wbGU=\"}")
public class UploadDocumentWrapperRequest extends UploadDocumentRequest {


    /** The front base 64. */
    //Front base 64
    @NotNull
    @Schema(description = "Front folder", example = "dGVzdGV4YW1wbGU=")
    private String frontBase64;

    /** The back base 64. */
    //Back base 64
    @NotBlank
    @Schema(description = "Destination folder", example = "dGVzdGV4YW1wbGU=")
    private String backBase64;

}
