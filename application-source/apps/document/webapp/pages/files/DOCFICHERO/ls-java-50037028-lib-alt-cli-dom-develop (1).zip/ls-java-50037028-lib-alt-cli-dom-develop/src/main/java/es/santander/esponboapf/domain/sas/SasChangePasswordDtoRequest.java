package es.santander.esponboapf.domain.sas;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Sas Change Password request.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class SasChangePasswordDtoRequest {

    /** The new password. */
    private String newPassword;

    /** The new password confirm. */
    private String newPasswordConfirm;

    /** The old password. */
    private String password;

    /** The realm. */
    private String realm;
}
