package es.santander.esponboapf.domain.util;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.jackson.JsonComponent;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

/**
 * StringTrimmerDeserializer
 *
 * The type String trimmer serializer.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@JsonComponent
public class StringTrimmerDeserializer extends JsonDeserializer<String> {

    /**
     * Deserialize.
     *
     * @param jsonParser             the json parser
     * @param deserializationContext the deserialization context
     * @return the string
     * @throws IOException Signals that an I/O exception has occurred.
     */
    @Override
    public String deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
            throws IOException {
        String text = jsonParser.getText();
        if (!StringUtils.isEmpty(text)) {
            text = text.trim();
        }
        if (StringUtils.isEmpty(text)) {
            text = null;
        }
        return text;
    }

}
