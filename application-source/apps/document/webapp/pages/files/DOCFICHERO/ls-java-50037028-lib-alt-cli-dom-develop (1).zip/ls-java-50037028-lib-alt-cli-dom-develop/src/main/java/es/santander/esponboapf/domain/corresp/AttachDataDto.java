package es.santander.esponboapf.domain.corresp;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new attach data dto.
 */
//The class AttachDataDto
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information attach data.")
public class AttachDataDto {

    /** The campo 1. */
    //campo1
    @Schema(description = "Field 1", example = "Prueba 1444444")
    @JsonProperty("CAMPO_1")
    @Builder.Default
    private String campo1 = "";

    /** The campo 2. */
    //campo2
    @Schema(description = "Field 2", example = "Campo 2")
    @JsonProperty("CAMPO_2")
    @Builder.Default
    private String campo2 = "";

    /** The campo 3. */
    @Schema(description = "Field 3", example = "Campo 3")
    @JsonProperty("CAMPO_3")
    @Builder.Default
    private String campo3 = "";

    /** The campo 4. */
    @Schema(description = "Field 4", example = "Campo 4")
    @JsonProperty("CAMPO_4")
    @Builder.Default
    private String campo4 = "";

    /** The campo 5. */
    @Schema(description = "Field 5", example = "Campo 5")
    @JsonProperty("CAMPO_5")
    @Builder.Default
    private String campo5 = "";

    /** The campo 6. */
    @Schema(description = "Field 6", example = "Campo 6")
    @JsonProperty("CAMPO_6")
    @Builder.Default
    private String campo6 = "";

    /** The campo 7. */
    @Schema(description = "Field 7", example = "Campo 7")
    @JsonProperty("CAMPO_7")
    @Builder.Default
    private String campo7 = "";

    /** The campo 8. */
    @Schema(description = "Field 8", example = "Campo 8")
    @JsonProperty("CAMPO_8")
    @Builder.Default
    private String campo8 = "";

    /** The campo 10. */
    @Schema(description = "Field 10", example = "Campo 10")
    @JsonProperty("CAMPO_10")
    @Builder.Default
    private String campo10 = "";

    /** The campo 11. */
    @Schema(description = "Field 1", example = "Campo 11")
    @JsonProperty("CAMPO_11")
    @Builder.Default
    private String campo11 = "";

    /** The campo 12. */
    @Schema(description = "Field 12", example = "Campo 12")
    @JsonProperty("CAMPO_12")
    @Builder.Default
    private String campo12 = "";

    /** The campo 13. */
    @Schema(description = "Field 13", example = "13")
    @JsonProperty("CAMPO_13")
    @Builder.Default
    private String campo13 = "";

    /** The campo 14. */
    @Schema(description = "Field 14", example = "Campo 14")
    @JsonProperty("CAMPO_14")
    @Builder.Default
    private String campo14 = "";

    /** The campo 15. */
    @Schema(description = "Field 15", example = "Campo 15")
    @JsonProperty("CAMPO_15")
    @Builder.Default
    private String campo15 = "";

    /** The campo 16. */
    @Schema(description = "Field 16", example = "16")
    @JsonProperty("CAMPO_16")
    @Builder.Default
    private String campo16 = "";

    /** The campo 17. */
    @Schema(description = "Field 17", example = "#rr")
    @JsonProperty("CAMPO_17")
    @Builder.Default
    private String campo17 = "";

    /** The prioridad mo. */
    @Schema(description = "Priority mo", example = "1")
    @JsonProperty("PRIORIDAD_MO")
    @Builder.Default
    private String prioridadMo = "";

    /** The campana. */
    @Schema(description = "Campaign", example = "1")
    @JsonProperty("CAMPANA")
    @NotNull
    private Integer campana;

    /** The nom campa. */
    @Schema(description = "Campaign name", example = "Campa prueba")
    @JsonProperty("NOMCAMPA")
    private String nomCampa;

    /** The id form. */
    @Schema(description = "Form id.", example = "12033")
    @JsonProperty("ID_FORMULARIO")
    @NotNull
    private String idForm;

    /** The ident formulario. */
    @Schema(description = "Form identify.", example = "6")
    @JsonProperty("IDENT_FORMULARIO")
    @Builder.Default
    private Integer identFormulario = 6;

    /** The nom formu. */
    @Schema(description = "Form name.", example = "Formulario Callme")
    @JsonProperty("NOMFORMU")
    @Builder.Default
    private String nomFormu = "";

    /** The tipo documento. */
    @Schema(description = "Document type.", example = "C")
    @JsonProperty("TIPODOCUMENTO")
    @Builder.Default
    private String tipoDocumento = "";

    /** The documento. */
    @Schema(description = "Document.", example = "B95102174")
    @JsonProperty("DOCUMENTO")
    @Builder.Default
    private String documento = "";

    /** The nombre pers. */
    @Schema(description = "Person name.", example = "MANOLITO JIMENEZ")
    @JsonProperty("NOMBREPERS")
    @Builder.Default
    private String nombrePers = "";

    /** The cod pers. */
    @Schema(description = "Person number.", example = "5454")
    @JsonProperty("CODPERS")
    @Builder.Default
    private String codPers = "";

    /** The tipo pers. */
    @Schema(description = "Person type.", example = "F")
    @JsonProperty("TIPOPERS")
    @Builder.Default
    private String tipoPers = "";
}
