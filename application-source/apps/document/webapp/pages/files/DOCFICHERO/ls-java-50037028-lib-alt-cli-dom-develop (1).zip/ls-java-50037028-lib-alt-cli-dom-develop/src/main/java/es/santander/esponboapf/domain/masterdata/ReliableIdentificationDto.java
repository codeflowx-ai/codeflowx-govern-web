package es.santander.esponboapf.domain.masterdata;

import java.io.Serial;
import java.io.Serializable;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ReliableIdentificationDto.
 */
// The Class ReliableIdentificationDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReliableIdentificationDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 6305030749128675051L;

    /** The identification code. */
    // The identification code
    @Schema(description = "The reliable identification code", example = "4")
    private Integer identificationCode;

    /** The identification name. */
    // The identification name
    @Schema(description = "The reliable identification name", example = "Identificación por IBAN")
    @Pattern(regexp = "[a-zA-ZÀ-ÿ ]+")
    private String identificationName;

    /** The pex. */
    @Schema(description = "Pex number of a document", example = "24G6E2TR")
    @Pattern(regexp = "[a-zA-Z0-9-_\\/ ]*")
    private String pex;

}
