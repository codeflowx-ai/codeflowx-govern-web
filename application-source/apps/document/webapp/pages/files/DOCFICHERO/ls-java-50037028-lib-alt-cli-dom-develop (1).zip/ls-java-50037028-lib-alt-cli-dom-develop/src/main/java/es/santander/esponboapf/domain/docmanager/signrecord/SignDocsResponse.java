package es.santander.esponboapf.domain.docmanager.signrecord;

import java.util.List;

import lombok.Data;

/**
 * The Class SignDocsResponse.
 */
@Data
public class SignDocsResponse {

	/**
	 * Result sign docs
	 */
	private List<ResultSignDoc> docs;

	/**
	 * PreContract signed. Posible values: S or N
	 */
	private String signDocsPreContract;
}
