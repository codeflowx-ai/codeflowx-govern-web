package es.santander.esponboapf.domain.expread.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Required holder document information dto.
 */
//The class RequiredHolderDocumentInformationDto
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RequiredHolderDocumentInformationDto {

    /**
     * The Nacionality.
     */
    private Integer nacionality;

    /**
     * The Documents.
     */
    private List<HolderDocumentTypeDto> documents;

    /**
     * The Code flow.
     */
    private String codeFlow;

}
