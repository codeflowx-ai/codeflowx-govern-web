package es.santander.esponboapf.domain.api.services;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AccountDataDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountDataDto {

    /** The account entity. */
    @Schema(description = "account entity indicator", example = "0049")
    private String accountEntity;

    /** The account branch. */
    @Schema(description = "account branch indicator", example = "5525")
    private String accountBranch;

    /** The old format product. */
    @Schema(description = "old format product indicator", example = "211")
    private String oldFormatProduct;

    /** The old format account. */
    @Schema(description = "old format account indicator", example = "0000597")
    private String oldFormatAccount;

    /** The account IBAN. */
    @Schema(description = "iban account indicator", example = "ES2600492594602515000446")
    private String accountIBAN;

    /** The account BBAN. */
    @Schema(description = "bban account indicator", example = "00492594602515000446")
    private String accountBBAN;
}

