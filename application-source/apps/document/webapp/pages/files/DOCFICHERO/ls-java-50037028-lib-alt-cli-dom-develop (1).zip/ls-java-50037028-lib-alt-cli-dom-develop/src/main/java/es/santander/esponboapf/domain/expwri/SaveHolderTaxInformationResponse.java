package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SaveHolderContactResponse.
 */

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
// Save holder contact response
public class SaveHolderTaxInformationResponse {

    /** The result. */
    @Schema(description = "Validation result", example = "true")
    private boolean result;
    
    /** The code. */
    @Schema(description = "Response code", example = "MU003")
    private String code;

}
