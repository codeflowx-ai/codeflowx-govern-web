package es.santander.esponboapf.domain.docmanager.signrecord;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new contract pdf dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder(toBuilder = true)
// Constract pdf
public class ContractPdfDto {

    /** The contract code. */
    // Constract code
    private Integer contractCode;

    /** The contractpdf base 64. */
    // Contract pdf base 64
    @JsonInclude(Include.NON_NULL)
    private String contractpdfBase64;

    /** The contract read. */
    private boolean contractRead;

    /** The contract name. */
    private String contractName;
}
