package es.santander.esponboapf.domain.api.services;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class InfoDossierStepsHolderStatesDto.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InfoDossierStepsHolderStatesDto {

    /** The dossier code. */
    private Long dossierCode;

    /** The state code. */
    private Integer stateCode;

    /** The sub state code. */
    private Integer subStateCode;

    /** The info holder steps. */
    private List<InfoHolderStepsDto> infoHolderSteps;

}
