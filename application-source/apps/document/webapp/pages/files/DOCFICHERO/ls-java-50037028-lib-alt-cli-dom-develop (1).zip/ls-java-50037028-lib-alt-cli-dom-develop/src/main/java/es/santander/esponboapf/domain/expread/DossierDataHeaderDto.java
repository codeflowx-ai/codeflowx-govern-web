package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new dossier data header dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information to display in the header of the dossier.",
example = "{\"dossierCode\":63, \"registerDate\":\"01/11/2021\","
        + "\"office\":\"0282\",\"stateCode\":1,\"campaignName\":\"Cuenta 123\",\"ipAddress\":\"123.876.345.09\","
        + "\"stateName\":\"Pendiente de documentación e ingreso\",\"sustateName\"Pendiente de documentación\","
        + "\"cancelReason\":\"Documentación fraudulenta\"}")
public class DossierDataHeaderDto {

    /** The dossier code. */
    @Schema(description = "Dossier code", example = "63")
    private Long dossierCode;

    /** The register date. */
    @Schema(description = "Date of registration of the dossier.", example = "01/11/2021")
    private String registerDate;

    /** The office. */
    @Schema(description = "Office code", example = "0282")
    private String office;

    /** The state code. */
    @Schema(description = "State code", example = "5")
    private Integer stateCode;

    /** The campaign. */
    @Schema(description = "Campaign in which the dossier is included.", example = "Cuenta 123")
    private String campaignName;

    /** The ip address. */
    @Schema(description = "IP address.", example = "123.876.345.09")
    private String ipAddress;

    /** The state. */
    @Schema(description = "Status of the dossier.", example = "Pendiente de documentación e ingreso")
    private String stateName;

    /** The substate. */
    @Schema(description = "Subtate of the dossier.", example = "Pendiente de documentación")
    private String substateName;

    /** The cancelReason. */
    @Schema(description = "Cancel reason of the dossier.", example = "Documentación fraudulenta")
    private String cancelReason;

}
