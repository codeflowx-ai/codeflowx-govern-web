package es.santander.esponboapf.domain.docmanager.signrecord;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.fasterxml.jackson.annotation.JsonTypeName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CreateSignExp.
 */
//The class SignDocsRequest
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
@JsonTypeName("signDocsRequest")
public class SignDocsRequest {

    /** Id del expediente. */
    private String idExpSec;

    /** Frame channel. ex. INT */
    private String channel;

    /** Signer person */
    private SignerPerson signer;

    /**
     * If filled, sign only this documents, in otherwise, sign all expedient
     */
    private List<DocSign> filteredDocsSign;

}
