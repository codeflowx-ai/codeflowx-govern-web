package es.santander.esponboapf.domain.fraud;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MulerosStatusRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MulerosStatusRequest {

    /** The waiting code. */
    private String waitingCode;

    /** The action code. */
    private String actionCode;

    /** The warning type. */
    private String warningType;

    /** The company id. */
    private String companyId;

    /** The expedient id. */
    private String expedientId;

    /** The description. */
    private String description;

    /** The email. */
    private String email;
}