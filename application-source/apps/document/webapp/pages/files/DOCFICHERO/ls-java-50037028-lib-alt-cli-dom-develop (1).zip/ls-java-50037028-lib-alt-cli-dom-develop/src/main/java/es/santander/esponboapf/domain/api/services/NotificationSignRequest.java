package es.santander.esponboapf.domain.api.services;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class NotificationSignRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationSignRequest {

    /** The id exp sec. */
    // The id exp sec.
    @NotNull
    private Long idExpSec;

    /** The status exp. */
    // The status exp.
    @NotNull
    private String statusExp;

    /** The signer. */
    // The signer.
    private SignerDto signer;
}
