package es.santander.esponboapf.domain.sign;

import java.util.List;

import es.santander.esponboapf.domain.onboarding.api.GetIdSignResponse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * HolderContractSignWacomDto
 *
 * The Class HolderContractSignWacomDto.
 *
 * We need to add more comment lines for Sonar.
 *
 * I hope these will be more than enough.
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@Schema(description = "The list of contract documents and whether they are signed. If a document is not signed, "
        + "the necessary information for wacom signature is returned", example = "{}")
public class HolderContractSignWacomDto {

    /** The contracts. */
    @Schema(description = "Information about holder contracts & if they are already signed.", example = "[]")
    private List<HolderContractSignDataDto> contracts;

    /** The id sign wacom dto. */
    @Schema(description = "Wacom petition & url", example = "{}")
    private GetIdSignResponse idSignWacomDto;

}
