package es.santander.esponboapf.domain.docmanager;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Download document response.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DownloadExternalDocumentResponse {

    /**
     * The Base 64.
     */
    // Base64
    private String base64;

}
