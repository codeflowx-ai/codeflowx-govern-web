package es.santander.esponboapf.domain.expwri.dossier.save;

/**
 * The enum Save document action.
 */
public enum CompareAction {

    /**
     * Rejected save document action.
     */
    REJECTED,
    /**
     * Created save document action.
     */
    CREATED,
    /**
     * Accepted save document action.
     */
    ACCEPTED,
    /**
     * Pending save document action.
     */
    PENDING

}
