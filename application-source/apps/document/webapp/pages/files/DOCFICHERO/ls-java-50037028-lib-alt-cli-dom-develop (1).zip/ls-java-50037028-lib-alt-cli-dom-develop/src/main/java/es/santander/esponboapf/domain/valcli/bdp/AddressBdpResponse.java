package es.santander.esponboapf.domain.valcli.bdp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class AddressBdpResponse.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AddressBdpResponse {

    /** The party id. */
    private String partyId;

    /** The address id. */
    private String addressId;
}
