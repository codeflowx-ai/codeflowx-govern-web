package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class IdentityType.
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
// IdentityTypeDictionaryDto
public class IdentityTypeDictionaryDto {


    /**
     * The Identity Type Code.
     *
     * E.g.: 1, 2
     */
    @Schema(description = "Identification type identifier", example = "1")
    private Integer identityTypeCode;

    /**
     * The Identity Type Name.
     *
     */
    @Schema(maxLength = 6,
            description = "Description of the type of identification",
            example = "LBDNI")
    private String identityTypeName;

    /** The dictionary value. */
    @Schema(maxLength = 6,
            description = "Description of the type of identification and the data to be displayed on the screen",
            example = "DNI")
    private String dictionaryValue;

}
