package es.santander.esponboapf.domain.fraud;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CaseMuleroDto.
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CaseMuleroDto {

    /** The case mulero. */
    private Boolean caseMulero;

    /** The state exp mulero. */
    private String stateExpMulero;

    /** The exp mulero. */
    private String expMulero;

}
