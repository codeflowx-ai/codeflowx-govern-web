package es.santander.esponboapf.domain.fraud;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ExpedientMulerosRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExpedientMulerosRequest {

    /** The holder code. */
    // The holder code
    @NotNull
    private Long holderCode;

    /** The expedient. */
    // The expedient
    @NotNull
    private String expedient;

}
