package es.santander.esponboapf.domain.docmanager.uploaddoc;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.List;
import java.util.UUID;

/**
 * The Class UploadDocumentRequest.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
@Schema(description = "Basic holder data.", 
    example = "\"holderId\":\"1abe4f7c-d843-477d-b1c8-d181410c1a47\","
        + "\"priority\":\"1\",\"documents\":[{\"priority\":\"1\","
        + "\"docTypeCode\":1,\"documentCode\":1,\"fileParam\":[param1]}\"]")
public class UploadDocumentRequest {

    /**
     * The holder id.
     * <p>
     * Unique holder's identifier.
     * E.g.: '1abe4f7c-d843-477d-b1c8-d181410c1a47'
     */
    @Schema(description = "Unique holder's identifier", example = "1abe4f7c-d843-477d-b1c8-d181410c1a47")
    @NotNull
    private UUID holderId;

    /**
     * The priority.
     * <p>
     * Number identifying the priority.
     * E.g.: '1'
     */
    @Schema(description = "Number identifying the priority", example = "1")
    @Pattern(regexp = "^[0-9]?$")
    private String priority;

    /**
     * The Documents.
     */
    @Schema(description = "List of documents", 
            example = "{\"priority\":\"1\",\"docTypeCode\":1,\"documentCode\":1,"
                    + "\"fileParam\":[param1]}")
    private List<UploadDocumentRequestDocument> documents;

}
