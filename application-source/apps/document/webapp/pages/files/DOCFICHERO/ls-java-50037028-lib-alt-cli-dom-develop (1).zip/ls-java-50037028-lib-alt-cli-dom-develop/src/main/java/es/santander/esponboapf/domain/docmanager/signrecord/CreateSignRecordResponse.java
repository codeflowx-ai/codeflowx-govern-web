package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.Data;

/**
 * The Class CreateSignResponse.
 */
@Data
public class CreateSignRecordResponse {

    /** The id exp sec. */
    private long idExpSec;

    /** The version. */
    private String version;
}
