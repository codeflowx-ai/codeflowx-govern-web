package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DocSign.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class DocSign {

	/**
	 * Code GDoc. ex. L6
	 */
	private String codgdoc;
	
	/**
	 * Código del firmante. ex. F124664238
	 */
	private String personNumberDoc;

	/**
	 * Tipo de intervención del firmante en la propia firma del documento. ex. 01 -> Titular, 08 -> Autorizado
	 */
	private String intervTypeDoc;

	/**
	 * Indica si hay sellado digital. ex. N
	 */
	private String indDigSealing;

}
