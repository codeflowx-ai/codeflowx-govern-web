package es.santander.esponboapf.domain.docmanager.signrecord;

import lombok.Data;

/**
 * The Class ResultSignDoc.
 */
@Data
public class ResultSignDoc {

    /**
     * Document code.
     */
    private String codgdoc;

    /**
     * Sign doc result. Posible values: OK or KO
     */
    private String result;
}
