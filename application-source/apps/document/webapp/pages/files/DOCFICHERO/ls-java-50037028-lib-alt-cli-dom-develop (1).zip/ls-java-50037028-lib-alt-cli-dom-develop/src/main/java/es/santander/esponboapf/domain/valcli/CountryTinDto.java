package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CountryTinDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CountryTinDto {

    /** The code. */
    private String code;

}
