package es.santander.esponboapf.domain.ocr;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * The Class SaveHolderOCRResponse.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
// Save holder OCR response
public class SaveHolderOCRResponse {

    /** The dossier id. */
    // Dossier id
    @Schema(maxLength = 100, description = "Unique holder identifier. The first time is null.",
            example = "70fd7423-5759-447b-a92f-6e88f514cc89")
    private UUID dossierId;

    /**
     * The ocr data.
     *
     * Information obtained after reading the OCR service
     */
    // Ocr data
    @Schema(description = "Information obtained after reading the OCR service")
    private OcrOutDto ocrData;

}
