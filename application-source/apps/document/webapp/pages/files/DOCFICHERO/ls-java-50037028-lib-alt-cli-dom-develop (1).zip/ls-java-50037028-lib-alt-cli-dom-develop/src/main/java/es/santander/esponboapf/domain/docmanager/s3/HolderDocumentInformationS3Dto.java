package es.santander.esponboapf.domain.docmanager.s3;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/**
 * The type Holder information s 3 dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HolderDocumentInformationS3Dto {

    /**
     * The Dossier code.
     */
// Dossier code
    @Schema(description = "Dossier identifier", example = "628")
    @NotNull
    private Long dossierCode;

    /**
     * The holder code.
     */
// Holder code
    @Schema(description = "Holder idenfifier", example = "1")
    private Long holderCode;

    /**
     * The document type.
     */
// Document type
    @Schema(description = "Document type identifier", example = "1")
    private Integer documentType;

    /**
     * The Folder.
     */
// Folder (TRABAJO, IDENTIFICACION, DOMICILIO)
    @Schema(description = "Dossier folder name", example = "IDENTIFICACION")
    @Pattern(regexp = "[\\w/]+")
    @NotBlank
    private String folder;

    /**
     * The Document prefix.
     */
// Document prefix
    @Schema(description = "Document Grado prefix", example = "TRAB")
    @Size(min = 2, max = 7)
    @NotBlank
    @Pattern(regexp = "[\\w]+")
    private String documentPrefix;

    /**
     * The Person code.
     */
// Person code
    @Schema(description = "Person identifier in bank system", example = "F12345678")
    @Size(min = 2, max = 20)
    @Pattern(regexp = "[F]?[0-9]{0,20}")
    private String personCode;

    /**
     * The Priority.
     */
// Priority
    @Schema(description = "Holder priority", example = "1")
    @Pattern(regexp = "[1-9]?")
    private String priority;

    /**
     * The Document code.
     */
// Document code
    @Schema(description = "Document code", example = "1")
    private Integer documentCode;

    /**
     * The document old file name
     */
    // Old file name
    @Schema(description = "Optional document old or current file name to be replaced", example = "DNI_F12345678.jpg")
    @Pattern(regexp = "[\\w.,]+")
    private String filename;

}
