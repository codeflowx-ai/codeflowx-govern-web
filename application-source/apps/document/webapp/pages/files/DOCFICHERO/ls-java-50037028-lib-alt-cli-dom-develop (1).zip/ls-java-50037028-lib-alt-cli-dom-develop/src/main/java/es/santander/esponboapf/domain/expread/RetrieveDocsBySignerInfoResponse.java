package es.santander.esponboapf.domain.expread;

import java.util.List;

import es.santander.esponboapf.domain.expwri.DocsBySignerInfoDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class RetrieveDocsBySignerResponse.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// RetrieveDocsBySignerResponse
public class RetrieveDocsBySignerInfoResponse {

    /** The list docs by signer. */
    // Docs by signer
    private List<DocsBySignerInfoDto> listDocsBySigner;

}
