package es.santander.esponboapf.domain.token;

import lombok.Builder;
import lombok.Getter;

/**
 * The Class GenerateTokenRequestPayloadBean.
 */
@Getter
@Builder
public class GenerateTokenRequestPayloadBean {

    /** The data. */
    private String data;

    /** The claim 2. */
    private String claim2;

    /** The iss. */
    private String iss;

    /** The sub. */
    private String sub;

}
