package es.santander.esponboapf.domain.valcli;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Branch locator office location.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchLocatorOfficeLocation {

    /** The Type. */
    private String type;

    /** The Coordinates. */
    private List<Double> coordinates;

    /** The Address. */
    private String address;

    /** The Zipcode. */
    private String zipcode;

    /** The City. */
    private String city;

    /** The Country. */
    private String country;

    /** The Location details. */
    private String locationDetails;

    /** The Parking. */
    private String parking;

    /** The Geo coords. */
    private BranchLocatorOfficeCoordinates geoCoords;

    /** The Url photo. */
    private String urlPhoto;

    /** The Description photo. */
    private String descriptionPhoto;

}
