package es.santander.esponboapf.domain.expread.process;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Dossier process details dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Dossier process details data object
public class DossierProcessDetailsDto {

    /**
     * The Account number.
     */
    private String accountNumber;

    /**
     * The Partenon contract.
     */
    private String partenonContract;

    /**
     * The Holder processes.
     */
    private List<HolderProcessDetailsDto> holders;

}
