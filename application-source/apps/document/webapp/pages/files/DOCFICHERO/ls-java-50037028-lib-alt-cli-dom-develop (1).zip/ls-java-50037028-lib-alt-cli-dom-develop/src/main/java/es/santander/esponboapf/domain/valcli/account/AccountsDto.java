package es.santander.esponboapf.domain.valcli.account;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class AccountsDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// AccountsDto
public class AccountsDto {

    /** The accounts. */
    // Balances
    @Schema(description = "Accounts balances", example = "")
    private AccountBalancesDto balances;

}
