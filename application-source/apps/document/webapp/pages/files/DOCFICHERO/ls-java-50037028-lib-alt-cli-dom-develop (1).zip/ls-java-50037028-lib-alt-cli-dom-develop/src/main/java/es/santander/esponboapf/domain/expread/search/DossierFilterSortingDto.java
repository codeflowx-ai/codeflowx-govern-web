package es.santander.esponboapf.domain.expread.search;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Sorting dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Sorting filter
public class DossierFilterSortingDto {

    /**
     * The Field.
     *
     * Field for sorting
     */
    // Field
    @Schema(description = "Field for sorting", example = "Field")
    @Pattern(regexp = "[a-zA-Z]+")
    private String field;

    /**
     * The Direction.
     *
     * Direction of sorting, asc or desc. Eg: asc
     */
    // Direction
    @Schema(description = "Direction of sorting, asc or desc", example = "asc")
    @Pattern(regexp = "asc|desc")
    private String direction;

}
