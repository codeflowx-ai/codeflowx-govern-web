package es.santander.esponboapf.domain.valcli.bdp;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpContactListDto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BdpContactListDto {

    /** The channel C. */
    private String channelC;

    /** The company. */
    private String company;

    /** The concerted change. */
    private Integer concertedChange;

    /** The device type repositioning. */
    private String deviceTypeRepositioning;

    /** The endorsement inclusion. */
    private List<String> endorsementInclusion;

    /** The inclusion rest. */
    private String inclusionRest;

    /** The occurrence rate. */
    private Integer occurrenceRate;

    /** The operational risk. */
    private String operationalRisk;

    /** The origin change auth. */
    private List<String> originChangeAuth;

    /** The related person code. */
    private Integer relatedPersonCode;

    /** The related type code. */
    private String relatedTypeCode;

    /** The sequential number. */
    private Integer sequentialNumber;

    /** The sequential number device. */
    private List<Integer> sequentialNumberDevice;

    /** The type client. */
    private String typeClient;

    /** The type of device. */
    private List<String> typeOfDevice;

    /** The update check online. */
    private List<String> updateCheckOnline;

}