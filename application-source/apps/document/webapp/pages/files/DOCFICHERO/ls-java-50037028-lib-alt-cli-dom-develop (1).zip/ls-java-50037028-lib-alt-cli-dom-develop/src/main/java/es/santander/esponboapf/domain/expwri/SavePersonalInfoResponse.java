package es.santander.esponboapf.domain.expwri;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * The Class SavePersonalInfoResponse.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Required information to save the current holder personal information.", 
    example = "{\"result\":true, \"message\":{\"code\":\"VC001\",\"groupCode\":\"VG600\","
        + "\"description\":\"Client is on a black list\","
        + "\"urlRedirect\":\"http://phoenixapp.isban.dev.corp/REGCLA_PHOENIX/static/index.html?sty=SNET\"}")
// Save personal info response
public class SavePersonalInfoResponse {

    // indica que los datos personales suministrados son válidos
    /** The result. */
    // Result
    @Schema( description = "Validation result.", example = "true")
    @NotNull
    private boolean result;

    /** The message. */
    // Message
    @Schema(maxLength = 100, description = "Information about a failed information validation. "
            + "Null if it did not fail and result is true", example = "{\"code\":\"VC001\",\"groupCode\":\"VG600\","
                    + "\"description\":\"Client is on a black list\","
                    + "\"urlRedirect\":\"http://phoenixapp.isban.dev.corp/REGCLA_PHOENIX/static/index.html?sty=SNET\"}")
    private SavePersonalInfoResponseMessage message;

}
