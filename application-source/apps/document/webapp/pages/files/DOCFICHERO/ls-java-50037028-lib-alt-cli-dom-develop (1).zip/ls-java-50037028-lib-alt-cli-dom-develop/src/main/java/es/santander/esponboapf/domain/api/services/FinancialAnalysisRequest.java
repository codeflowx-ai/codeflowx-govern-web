package es.santander.esponboapf.domain.api.services;

import java.util.UUID;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FinancialAnalysisRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// FinncialAnalysisRequest
public class FinancialAnalysisRequest {

    /** The dossier id. */
    // Dossier id
    @NotNull
    @Schema(description = "Unique dossier identifier.", example = "706db63f-1029-4e16-b163-915de88f70c5")
    private UUID dossierId;

    /** The holder id. */
    // Holder id
    @NotNull
    @Schema(description = "Unique holder identifier.", example = "706db63f-1029-4e16-b163-915de88f70c5")
    private UUID holderId;
}
