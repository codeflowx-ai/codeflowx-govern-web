package es.santander.esponboapf.domain.producttrans;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new user info dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "User information accessing the application", 
example = "{\"hasProfile\":true,\"fullName\":\"DON BAILONGO RODRIGUEZ PEREZ\","
        + "\"idProfile\":1,\"userProfile\":\"Administrador\"}")
public class UserInfoDto {

    /**
     * The has profile.
     * E.g. true
     * */
    @Schema(description = "Indicator to know if the user has an assigned profile", example = "true")
    private boolean hasProfile;

    /**
     * The full name.
     * E.g. DON BAILONGO RODRIGUEZ PEREZ
     *  */
    @Schema(description = "User's full name", example = "DON BAILONGO RODRIGUEZ PEREZ")
    private String fullName;

    /**
     * The id profile.
     * E.g. 1
     * */
    @Schema(description = "User profile id", example = "1")
    private Integer idProfile;

    /**
     * The user profile.
     * E.g. Administrador
     * */
    @Schema(description = "User profile name", example = "Administrador")
    private String userProfile;
}
