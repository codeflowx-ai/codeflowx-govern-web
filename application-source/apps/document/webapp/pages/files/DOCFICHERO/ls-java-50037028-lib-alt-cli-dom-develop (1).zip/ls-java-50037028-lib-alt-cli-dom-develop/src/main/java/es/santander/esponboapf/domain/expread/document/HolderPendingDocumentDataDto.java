package es.santander.esponboapf.domain.expread.document;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The pending document data dto.
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Schema(description = "Pending documents information.")
// Holder pending document data
public class HolderPendingDocumentDataDto extends HolderDocumentDataDto {

    /**
     * The Document state code.
     */
    // Document state code
    @Schema(description = "Document state code", example = "RNE")
    private String documentStateCode;

    /**
     * The Reject reason code.
     */
    // Reject reason name
    @Schema(description = "Reject reason code", example = "2")
    private Long rejectReasonCode;

    /**
     * The Reject reason name.
     */
    // Reject reason name
    @Schema(description = "Reject reason name", example = "Documento ilegible")
    private String rejectReasonName;

}
