package es.santander.esponboapf.domain.expread;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * The type Holder contract details dto.
 */
// Constructors
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
// Holder contracy details dto
public class HolderContractDetailsDto {

    /**
     * The Contracts.
     */
    // Contract list
    @Schema(description = "List of holder contracts")
    private List<HolderContractDocumentDto> contracts;

}
