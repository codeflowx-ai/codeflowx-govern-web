package es.santander.esponboapf.domain.expread;

import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Holder contract document dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// Holder contract document
public class HolderContractDocumentDto {

    /**
     * The Contract code.
     */
    // Contract code
    @Schema(description = "The contract identifier", example = "1")
    private Integer contractCode;

    /**
     * The Contract name.
     */
    // Contract name
    @Schema(description = "The contract description", example = "Condiciones particulares")
    @XssValid
    private String contractName;

    /**
     * The Mandatory.
     */
    // Mandatory
    @Schema(description = "The mandatory indicator", example = "true")
    private Boolean mandatory;

    /**
     * The Url.
     */
    // Url
    @Schema(description = "The contract url", example = "http://www.example.com/example.pdf")
    @XssValid
    private String url;
    
    @Schema(description = "Order block", example = "2")
    private Integer blockCode;

    /** The num order. */
    @Schema(description = "Order documents", example = "2")
    private Integer numOrder;

    /** The contract title. */
    @Schema(description = "Contract title", example = "Condiciones generales")
    private String contractTitle;
    
    /** The contract description. */
    @Schema(description = "Contract description", example = "Incluye la información...")
    private String contractDescription;

}
