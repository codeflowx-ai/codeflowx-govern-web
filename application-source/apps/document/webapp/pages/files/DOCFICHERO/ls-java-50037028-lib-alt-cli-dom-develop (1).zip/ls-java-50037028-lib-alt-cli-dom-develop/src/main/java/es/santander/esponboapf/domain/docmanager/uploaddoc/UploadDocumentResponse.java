package es.santander.esponboapf.domain.docmanager.uploaddoc;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class UploadDocumentResponse.
 */
// Constructors
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Response to the document uploading service.", 
example ="{\"allAttached\":true}")
// Upload document response
public class UploadDocumentResponse {

    /** The all attached. */
    // All attached flag
    @Schema(description = "Flag indicating if all documents needed from this holder are already attached",
            example = "true")
    private boolean allAttached;

}
