package es.santander.esponboapf.domain.ocr;

import es.santander.esponboapf.domain.expwri.DossierParentDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * Instantiates a new dossier ocr dto.
 *
 * OCR generated for a dossier generated in the onboarding process
 */
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "OCR generated for a dossier generated in the onboarding process",
example = "{\"ocr\":{\"holderId\":\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"priority\":1,"
        + "\"imageFormat\":\"png\",\"imageFrontBase64\":\"/8j/4AAQS8ZJRgAB3gAAAQABAAF\","
        + "\"imageBackBase64\":\"/8j/4AAQS8ZJRgAB3gAAAQABAAF\"}}")
// Dossier ocr data object
public class DossierOcrDto extends DossierParentDto {

    /**
     * The ocr information.
     *
     * Information related to a holder who is on the process of the digital
     * onboarding.
     * Information from images obtained from the reading of an identity document
     */
    @Valid
    @Schema(description = "Information from images obtained from the reading of an identity document",
    example = "{\"holderId\":\\\"80fd7423-5759-445b-a92f-6e88f514cc00\",\"priority\":1,"
            + "\"imageFormat\":\"png\",\"imageFrontBase64\":\"/8j/4AAQS8ZJRgAB3gAAAQABAAF\","
            + "\"imageBackBase64\":\"/8j/4AAQS8ZJRgAB3gAAAQABAAF\"}")
    @NotNull
    private OcrInDto ocr;

}
