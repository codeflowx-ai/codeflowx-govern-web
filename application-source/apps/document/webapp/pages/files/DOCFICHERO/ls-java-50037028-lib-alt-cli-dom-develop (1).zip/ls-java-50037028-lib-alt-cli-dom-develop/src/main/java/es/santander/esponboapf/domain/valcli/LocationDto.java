package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new location dto.
 */

@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Information about locations in Spain", 
example = "{\"provinceCode\":\"28\",\"provinceName\":\"Madrid\","
        + "\"location\":\"MADRID\"}")
public class LocationDto extends ProvinceDto {

    /**
     * The location.
     *
     * E.g.: 'MADRID'
     */
    @Schema(maxLength = 50, description = "city, town, village, etc...", example = "MADRID")
    private String location;

    /**
     * Instantiates a new location dto.
     *
     * @param provinceCode the province code
     * @param provinceName the province name
     * @param location     the location
     */
    public LocationDto(String provinceCode, String provinceName, String location) {
        super(provinceCode, provinceName);
        this.location = location;
    }
}
