package es.santander.esponboapf.domain.corresp;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MultiHolderPendingCommunicationDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MultiHolderPendingCommunicationDto {

    /**
     * The Dossier code.
     */
    private Long dossierCode;

    /**
     * The Dossier state.
     */
    private Integer dossierState;

    /** The holder info. */
    private List<HolderPendingCommunicationMultiDto> holderInfo;

    /** The account name. */
    private String accountName;

}
