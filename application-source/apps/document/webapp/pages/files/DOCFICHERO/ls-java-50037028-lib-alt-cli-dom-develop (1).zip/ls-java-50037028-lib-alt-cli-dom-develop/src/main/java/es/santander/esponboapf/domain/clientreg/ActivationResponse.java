package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activation response.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Final control response for account activation", example = "{ \"result\": \"true\"")
// Este Dto puede sufrir cambios debido a la ESPONBOAPF-181
// Activation response
public class ActivationResponse {

    /** The result. */
    @Schema(description = "validation indicator to activate an account", example = "true")
    // Result
    private boolean result;

    /** The code. */
    @Schema(description = "Activation error code to front", example = "AP666")
    // Code
    private String code;
}
