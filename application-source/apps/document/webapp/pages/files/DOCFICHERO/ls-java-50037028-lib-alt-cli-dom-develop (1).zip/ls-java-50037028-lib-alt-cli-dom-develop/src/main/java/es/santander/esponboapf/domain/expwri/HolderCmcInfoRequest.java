package es.santander.esponboapf.domain.expwri;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class HolderCmcInfo.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class HolderCmcInfoRequest {

    /** The holder code. */
    private Long holderCode;

    /** The contract. */
    private String contract;

    /** The signature. */
    private String signature;

}
