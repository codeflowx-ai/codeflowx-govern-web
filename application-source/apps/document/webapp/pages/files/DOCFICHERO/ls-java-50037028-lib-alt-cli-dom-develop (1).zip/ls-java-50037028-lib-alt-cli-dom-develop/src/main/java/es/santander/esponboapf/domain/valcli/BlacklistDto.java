package es.santander.esponboapf.domain.valcli;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new blacklist dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Information indicating if the blacklist validation passes", 
example = "{\"returnCode\":\"OK\",\"returnDesc\":\"Operacion Realizada Correctamente\"}")
public class BlacklistDto {

    /**
     * The return code.
     * 
     * E.g.: 'OK'
     */
    @Schema(description = "Status. OK if valid, KO if failed.", example = "OK")
    private String returnCode;

    /**
     * The return desc.
     * 
     * E.g.: 'Operacion Realizada Correctamente'
     */
    @Schema(description = "Information about operation.", example = "Operacion Realizada Correctamente")
    private String returnDesc;
}
