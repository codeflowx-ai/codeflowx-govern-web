package es.santander.esponboapf.domain.api.services;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class RetrieveDocsBySignerResponse.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// RetrieveDocsBySignerResponse
public class RetrieveDocsBySignerResponse {

    /** The list docs by signer. */
    // Docs by signer
    private List<DocsBySignerDto> listDocsBySigner;

}
