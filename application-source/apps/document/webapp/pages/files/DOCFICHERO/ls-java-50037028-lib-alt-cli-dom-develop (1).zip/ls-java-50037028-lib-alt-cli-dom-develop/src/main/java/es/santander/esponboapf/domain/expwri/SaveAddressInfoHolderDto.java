package es.santander.esponboapf.domain.expwri;

import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import es.santander.esponboapf.domain.util.OwaspValidatorsEnum;
import es.santander.esponboapf.domain.validation.annotations.XssValid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class SaveAddressInfoHolderDto.
 *
 * Information related to a holder who is on the process of the digital onboarding.
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Schema(description = "Holder's address information.")
public class SaveAddressInfoHolderDto {

    /**
     * The holder id.
     *
     * Holder's identifier.
     */
    // HolderId
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    @NotNull
    private UUID holderId;

    /** The office. */
    // Office
    // corresponde a la oficina mas cercana al cliente
    @Schema(maxLength = 4, description = "The code of the nearest bank office to the holder home.",
            example = "1234")
    @XssValid(pattern = OwaspValidatorsEnum.NUMBER)
    @Size(max = 4)
    private String office;

    /**
     * The holder address info.
     *
     * The holder's address.
     */
    // HolderAddressInfo
    @Schema(description = "Holder's address",
            example = "{\"roadTypeCode\":\"Cl\",\"roadName\":\"AC/DC\",\"num\":\"6\","
                    + "\"additionalInfo\":\"P1, Izqd, B\",\"postalCode\":\"28080\","
                    + "\"city\"\"Pescueza\",\"proviceCode\":\"28\",\"provinceName\":\"Cáceres\"}")
    @Valid
    @NotNull
    private AddressDto holderAddressInfo;

}
