package es.santander.esponboapf.domain.docmanager.signrecord;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

/**
 * Instantiates a new save holder consent dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
// Save holder consent
public class SaveHolderConsentDto {

    /** The holder id. */
    // Holder id
    @Schema( maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /** The consents. */
    // Consent list
    private List<ConsentInDto> consents;

}
