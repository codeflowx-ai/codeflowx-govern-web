package es.santander.esponboapf.domain.mictransferiden.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Transfer daily general operations fields response.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransferDailyGeneralOperationsFieldsResponse {

    /** The Company. */
    private String company;

    /** The Center. */
    private String center;

    /** The Terminal. */
    private String terminal;

    /** The Number. */
    private Long number;

    /** The Certification indicator. */
    private String certificationIndicator;

    /** The Certification. */
    private String certification;

}
