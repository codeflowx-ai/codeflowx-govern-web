package es.santander.esponboapf.domain.valcli.bdp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class BdpUpdateEmailPhoneRequest.
 */

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
// BdpUpdateEmailPhoneRequest
public class BdpUpdateEmailPhoneRequest {

    /** The customer id. */
    // Customer id
    private String customerId;

    /** The body bdp. */
    // Body bdp
    private BdpUpdateEmailPhoneDto bodyBdp;
}