package es.santander.esponboapf.domain.corresp;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class DossierPendingCommunicationDto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DossierPendingCommunicationDto {

    /**
     * The Dossier code.
     */
    private Long dossierCode;

    /**
     * The Dossier state.
     */
    private Integer dossierState;

    /**
     * The Holder code.
     */
    private Long holderCode;

    /**
     * The Holder id.
     */
    private String holderId;

    /**
     * The Holder name.
     */
    private String holderName;

    /**
     * The Holder surname 1.
     */
    private String holderSurname1;

    /**
     * The Holder surname 2.
     */
    private String holderSurname2;

    /**
     * The Email.
     */
    private String email;

    /** The priority. */
    private Integer priority;

    /**
     * The Steps.
     */
    private List<HolderPendingCommunicationStepDto> steps;

    /** The account name. */
    private String accountName;

}
