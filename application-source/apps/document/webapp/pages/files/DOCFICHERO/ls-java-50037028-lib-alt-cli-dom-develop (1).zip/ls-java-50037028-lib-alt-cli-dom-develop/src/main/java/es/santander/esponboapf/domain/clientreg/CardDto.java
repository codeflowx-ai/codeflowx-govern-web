package es.santander.esponboapf.domain.clientreg;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class CardDto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class CardDto {

    /** The employee number. */
    @Schema(description = "The employee number", example = "31156")
    private String employeeNumber;

    /** The mark card. */
    @Schema(description = "The mark card indicator", example = "1")
    private String markCard;

    /** The product type card. */
    @Schema(description = "The product type card indicator", example = "506")
    private String productTypeCard;

    /** The stamp code card. */
    @Schema(description = "The stamp code card indicator", example = "859")
    private String stampCodeCard;

    /** The sub type. */
    @Schema(description = "The sub type indicator", example = "634")
    private String subType;

    /** The type card. */
    @Schema(description = "The type card indicator", example = "66")
    private String typeCard;
}
