package es.santander.esponboapf.domain.clientreg.account;

import java.util.List;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new activation account request.
 */
//The class ActivationAccountRequest
@NoArgsConstructor
@AllArgsConstructor
@Data
@Schema(description = "Input object activation account request",
example = "{\"accountEntity\":\"0049\",\"accountBranch\":\"1234\",\"oldFormatProduct\":\"211\","
        + "\"oldFormatAccount\":\"0000597\",\"partenonProduct\":\"300\","
        + "\"partenonAccount\":\"0000033\",\"productType\":\"300\",\"subproductType\":\"402\","
        + "\"standardOfReference\":\"0000001\",\"holders\":[{\"personType\":\"F\", "
        + "\"personCode\":\"124661240\","
        + "\"order\":1,\"nimDomicilio\":\"12\"}]}")
public class ActivationAccountRequest {

    /** The accountEntity. */
    //accountEntity
    @NotNull
    @Schema(description = "account entity indicator", example = "0049")
    private String accountEntity;

    /** The accountBranch. */
    @NotNull
    @Schema(description = "account branch indicator", example = "1234")
    private String accountBranch;

    /** The oldFormatProduct. */
    @NotNull
    @Schema(description = "old format product indicator", example = "211")
    private String oldFormatProduct;

    /** The oldFormatAccount. */
    @NotNull
    @Schema(description = "old format account indicator", example = "0000597")
    private String oldFormatAccount;

    /** The partenonProduct. */
    @NotNull
    @Schema(description = "partenon product indicator", example = "300")
    private String partenonProduct;

    /** The partenonAccount. */
    @NotNull
    @Schema(description = "partenon account indicator", example = "0000033")
    private String partenonAccount;

    /** The productType. */
    @NotNull
    @Schema(description = "product type indicator", example = "300")
    private String productType;

    /** The subproductType. */
    @NotNull
    @Schema(description = "subproduct type indicator", example = "402")
    private String subproductType;

    /** The standardOfReference. */
    @NotNull
    @Schema(description = "standard of reference indicator", example = "0000001")
    private String standardOfReference;

    /** The holders. */
    @NotNull
    @Schema(description = "List of holders", example = "holder1")
    private List<Holder> holders;

}
