package es.santander.esponboapf.domain.corresp;

import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Communication dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
// Holder communication dto
public class HolderCommunicationDto {

    /**
     * The Dossier code.
     */
    private Long dossierCode;

    /** The dossier id. */
    private UUID dossierId;

    /**
     * The Holder code.
     */
    private Long holderCode;

    /** The holder id. */
    private UUID holderId;

    /**
     * The Communication code.
     */
    private Integer communicationCode;

    /**
     * The Email.
     */
    @Email
    private String email;

    /**
     * The Phone.
     */
    // Validated with optional prefix
    @Pattern(regexp = "[\\+]?[0-9]{9,14}")
    private String phoneNumber;

    /**
     * The Data.
     */
    @Valid
    private CommunicationDataDto data;
    

}
