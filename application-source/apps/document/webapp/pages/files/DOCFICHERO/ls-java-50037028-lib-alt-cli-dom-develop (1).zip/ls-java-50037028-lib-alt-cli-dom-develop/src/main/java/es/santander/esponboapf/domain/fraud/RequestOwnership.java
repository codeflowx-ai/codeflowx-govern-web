package es.santander.esponboapf.domain.fraud;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class RequestOwnership
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
// RequestOwnership
public class RequestOwnership {

    /** The country. */
    @Schema(description = "Country from a code BBAN", example = "ES")
    private String identityNumber;


    /** The digit control. */
    @Schema(description = "Digit control from a code BBAN", example = "30")
    private String completeNameHolder;

    
    /** The cod bban. */
    @Schema(description = "Code BBAN from a holder", example = "00490001552111874594")
    private IbanOwnershipDto ibanBeneficiary;

}
