package es.santander.esponboapf.domain.masterdata;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotNull;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type States dto.
 *
 * This is an output dto to the state listing service.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Schema(description = "State chosen in the onboarding process", 
example = "{\"stateCode\":2,\"stateName\":\"Alta de cliente\", "
        + "\"substate\":[\"sustateCode\":1,"
        + "\"substateName\":\"Identificación Pendiente de Validar\"]}")
public class StateDto implements Serializable {

    /**
     * The serialVersionUID
     */
    private static final long serialVersionUID = -6860815806640569182L;

    /**
     * The State code.
     *
     * E.g.: 2
     */
    @Schema( description = "Number identifying an state", example = "2")
    @NotNull
    private Integer stateCode;

    /**
     * The State name.
     *
     * E.g.: 'Alta de cliente'
     */
    @Schema( maxLength = 75, description = "Name of the state", example = "Alta de cliente")
    @NotNull
    private String stateName;

    /**
     * The SubstateDto.
     *
     * Substate list related to this state.
     */
    @Schema(description = "Substate list related to this state", 
            example = "[{\"substateCode\":1,\"substateName\":\"Identificación Pendiente de Validar\"}]")
    private List<SubstateDto> substate;

}
