package es.santander.esponboapf.domain.fraud;

import es.santander.esponboapf.domain.expread.HolderDetailDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Instantiates a new fraud reference dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
@Schema(description = "Fraud detection rule.", example = "{\"incomeRange\":\"30000\","
        + "\"occupationType\":\"11\",\"viaType\":\"11\",\"birthDate\":\"07/07/1975\"}")
// Fraud reference data object
public class FraudReferenceDto extends HolderDetailDto {

    /** The income range. */
    // Income range
    @Schema(description = "system reference confirms fraud for income range.", example = "30000")
    private String incomeRange;

    /** The occupation type. */
    // Occupation type
    @Schema(description = "system reference confirms fraud for occupation type.", example = "11")
    private String occupationType;

    /** The via type */
    // Via type
    @Schema(description = "system reference confirms fraud for via type.", example = "11")
    private String viaType;

}
