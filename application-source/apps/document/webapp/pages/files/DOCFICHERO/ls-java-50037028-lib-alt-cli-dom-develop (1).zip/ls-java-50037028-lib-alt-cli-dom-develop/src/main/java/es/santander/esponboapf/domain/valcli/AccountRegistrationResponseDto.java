package es.santander.esponboapf.domain.valcli;

import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Instantiates a new account registration response dto.
 */
@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class AccountRegistrationResponseDto {

    /**
     * The company account.
     *
     * company account code. Eg: 0049
     */
    @Pattern(regexp = "^[0-9]{4}$")
    private String companyAccount;

    /**
     * The branch account.
     *
     * brach account code. Eg: 0001
     */
    @Pattern(regexp = "^[0-9]{4}$")
    private String branchAccount;

    /**
     * The product new data.
     *
     * product for the account to be opened in new format (Partenón) Eg: 300
     */
    @Pattern(regexp = "^[0-9]{3}$")
    private String productNewData;

    /**
     * The account new data.
     *
     * number for the account to be opened in new format (Partenón) Eg: 0000008
     */
    @Pattern(regexp = "^[0-9]{7}$")
    private String accountNewData;

    /**
     * The product old data.
     *
     * product for the account to be opened in old format. Eg: 251
     *
     */
    @Pattern(regexp = "^[0-9]{3}$")
    private String productOldData;

    /**
     * The account old data.
     *
     * number for the account to be opened in old format. Eg: 0000007
     */
    @Pattern(regexp = "^[0-9]{7}$")
    private String accountOldData;

    /**
     * The account iban.
     *
     * account number in IBAN format. Eg: ES7800490001582915888832
     */
    @Pattern(regexp = "^[A-Z]{2}[0-9]{22}$")
    private String accountIBAN;

    /**
     * The account bban.
     *
     * account number in BBAN format. Eg: 00490001582915888832
     */
    @Pattern(regexp = "^[0-9]{20}$")
    private String accountBBAN;
}
