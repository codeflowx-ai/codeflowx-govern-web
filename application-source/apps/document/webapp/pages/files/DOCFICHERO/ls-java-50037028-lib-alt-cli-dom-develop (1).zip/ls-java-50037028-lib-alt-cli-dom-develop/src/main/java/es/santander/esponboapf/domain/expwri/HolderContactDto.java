package es.santander.esponboapf.domain.expwri;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Instantiates a new holder conctact dto.
 */
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Data
// Holder contact dto
public class HolderContactDto {

    /** The COUNTRYCODE. */
    // Country code
    @Schema(maxLength = 2, description = "Country code retrived from prefixes service call", example = "ES")
    @NotBlank
    @Size(max = 2)
    @Pattern(regexp = "[A-Z]*")
    private String countryCode;

    // para validar la persona que se está dando de alta, es necesario que facilite
    // su número de móvil
    /** The CELLPHONE. */
    // Cell phone
    @Schema(maxLength = 20, description = "Holder's cell phone", example = "699999999")
    @NotBlank
    @Size(max = 20)
    @Pattern(regexp = "^[0-9]{0,20}$")
    private String cellPhone;

    // al realizar onboarding digital, esta información es obligatoria
    /** The EMAIL. */
    // Email
    @Schema(maxLength = 100, description = "Holder's e-mail address", example = "example@example.com")
    @NotBlank
    @Size(max = 100)
    @Pattern(regexp = "^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$")
    private String email;

}
