package es.santander.esponboapf.domain.valcli;

import java.util.List;
import java.util.UUID;

import javax.validation.constraints.Pattern;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class FiocRequestDto.
 *
 * Information required to call external Fioc service.
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Schema(description = "Information required to call external Fioc service")
public class FiocRequestDto {

    /**
     * The holder id.
     *
     * Unique holder identifier.
     * E.g.: '80fd7423-5759-445b-a92f-6e88f514cc00'
     */
    @Schema(maxLength = 100, description = "Unique holder identifier.",
            example = "80fd7423-5759-445b-a92f-6e88f514cc00")
    private UUID holderId;

    /**
     * The person type.
     *
     * Legal person type
     * E.g.: 'F'
     */
    @Schema(maxLength = 1, description = "Legal person type", example = "F")
    @Pattern(regexp = "^[FJ]{1}$")
    private String personType;

    /**
     * The person code.
     *
     * Personal code in the company
     * E.g.: '1234'
     */
    @Schema(maxLength = 8, description = "Personal code in the company", example = "1234")
    @Pattern(regexp = "^[0-9]{9}$")
    private String personCode;

    /** The office. */
    @Schema( description = "Office code", example = "1234")
    @Pattern(regexp = "^[0-9]{4}$")
    private String office;

    /**
     * The concept list.
     *
     * List of concepts.
     */
    @Schema( description = "List of concepts",
            example = "{\"idConc\":\"001\",\"valorConc\":\"001\"}")
    private List<FiocConceptoDto> conceptList;

    /**
     * The comment list.
     *
     * List of comments.
     */
    @Schema( description = "List of comments",
            example = "{\"idCom\":\"001\",\"comentario\":\"test\"}")
    private List<FiocComentarioDto> commentList;

    /**
     * The simple list.
     *
     * List of simple notes.
     */
    @Schema( description = "List of simple notes",
            example = "{\"idSimple\":\"001\",\"valorSimple\":\"test\"}")
    private List<FiocSimpleDto> simpleList;

    /**
     * The numeric list.
     *
     * List of numerics
     */
    @Schema( description = "List of numerics", hidden = true, 
            example = "{\"idNum\":\"001\",\"numero\":\"25\"}")
    private List<FiocNumericosDto> numericList;

    /** The name. */
    @Schema( description = "Name customer", example = "LUCAS")
    private String name;

    /** The surname 1. */
    @Schema( description = "First surname customer", example = "SALINAS")
    private String surname1;

    /** The surname 2. */
    @Schema( description = "Second surname customer", example = "PEREZ")
    private String surname2;

    /** The already customer. */
    @Schema( description = "Indicated if exist on BDP", example = "true")
    private Boolean alreadyCustomer;
}
